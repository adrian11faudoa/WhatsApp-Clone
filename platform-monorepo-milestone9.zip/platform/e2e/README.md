# E2E Scenario Tests

Scenario-level tests against the full running stack, per
`architecture-phase1-vol3.md` Section 6.3 — deliberately few, high-value,
and written against real user-facing behavior (two browser sessions, not
mocked sockets). These are NOT a substitute for each service's own
unit/integration tests; they cover the one thing those can't: does the
system actually work end-to-end for a real user action.

## Running

```bash
# From the platform/ root:
./scripts/generate-shared-keys.sh
docker-compose up --build -d
cd e2e
npm install
npx playwright install chromium
npm test
```

## What's covered

- Real-time message delivery across two authenticated sessions (the
  scenario Volume 3 Section 6.3 names explicitly)
- Typing indicator propagation between sessions

## What's deliberately not covered here

Per Section 6.3's own guidance, this suite stays small. Offline/reconnect
delivery, media upload, and presence-status transitions are exactly the
kind of scenarios that belong here eventually but aren't written yet —
each would need either a way to simulate network loss in a browser
context (Playwright supports this via `context.setOffline()`, not yet
wired into a fixture) or the Media/Presence UI integration that's flagged
as unbuilt in `apps/web-client/README.md`.
