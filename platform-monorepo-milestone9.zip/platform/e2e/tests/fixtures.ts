import { APIRequestContext } from '@playwright/test';

const IDENTITY_URL = process.env.IDENTITY_SERVICE_URL ?? 'http://localhost:3001';
const MESSAGING_URL = process.env.MESSAGING_SERVICE_URL ?? 'http://localhost:3002';

export interface TestUser {
  username: string;
  email: string;
  password: string;
  displayName: string;
  userId: string;
  accessToken: string;
}

/**
 * Registers and logs in a throwaway user directly against the Identity
 * API (bypassing the UI — E2E scenarios should set up state as fast as
 * possible and spend their assertions on the actual scenario under test,
 * not re-prove that the registration form works; that's covered at the
 * unit/integration tier already).
 */
export async function createTestUser(request: APIRequestContext, label: string): Promise<TestUser> {
  const unique = `${label}_${Date.now()}_${Math.floor(Math.random() * 10_000)}`;
  const email = `${unique}@e2e.test`;
  const password = 'Str0ngPassw0rd!';
  const displayName = `E2E ${label}`;

  await request.post(`${IDENTITY_URL}/api/v1/auth/register`, {
    data: { username: unique, email, password, displayName },
  });

  // MVP milestone has no email-verification flow wired (identity-service
  // README's own "deliberately not in this milestone" note) — accounts
  // land in pending_verification but login is not gated on it, so this
  // works against the current backend. If verification gating ships
  // later, this fixture needs an admin/test-only bypass — flagged here
  // so that's not a silent breakage.
  const loginResponse = await request.post(`${IDENTITY_URL}/api/v1/auth/login`, {
    data: { email, password },
  });
  const tokens = await loginResponse.json();

  const meResponse = await request.get(`${IDENTITY_URL}/api/v1/users/me`, {
    headers: { Authorization: `Bearer ${tokens.accessToken}` },
  });
  const me = await meResponse.json();

  return { username: unique, email, password, displayName, userId: me.id, accessToken: tokens.accessToken };
}

export async function createDirectConversation(
  request: APIRequestContext,
  accessToken: string,
  otherUserId: string,
): Promise<string> {
  const response = await request.post(`${MESSAGING_URL}/api/v1/conversations`, {
    headers: { Authorization: `Bearer ${accessToken}` },
    data: { type: 'direct', participantIds: [otherUserId] },
  });
  const conversation = await response.json();
  return conversation.id;
}
