import { test, expect, Browser } from '@playwright/test';
import { createTestUser, createDirectConversation, TestUser } from './fixtures';

/**
 * The scenario architecture-phase1-vol3.md Section 6.3 names explicitly:
 * "user sends a message and recipient receives it in real time across
 * two authenticated sessions." Two separate browser contexts (not just
 * two tabs — separate contexts mean separate localStorage/cookies, so
 * this genuinely exercises two distinct client sessions, not one client
 * with two views) simulate two real users.
 */

async function signIn(browser: Browser, user: TestUser) {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto('/login');
  await page.getByLabel('Email').fill(user.email);
  await page.getByLabel('Password').fill(user.password);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.waitForURL('**/conversations');
  return { context, page };
}

test.describe('Real-time messaging between two sessions', () => {
  test('recipient sees a message within their conversation view moments after it is sent', async ({
    browser,
    request,
  }) => {
    const sender = await createTestUser(request, 'sender');
    const recipient = await createTestUser(request, 'recipient');
    const conversationId = await createDirectConversation(request, sender.accessToken, recipient.userId);

    const [senderSession, recipientSession] = await Promise.all([
      signIn(browser, sender),
      signIn(browser, recipient),
    ]);

    await Promise.all([
      senderSession.page.goto(`/conversations/${conversationId}`),
      recipientSession.page.goto(`/conversations/${conversationId}`),
    ]);

    const messageText = `Hello from E2E at ${Date.now()}`;

    const composer = senderSession.page.getByPlaceholder('Write a message');
    await composer.fill(messageText);
    await senderSession.page.getByRole('button', { name: 'Send' }).click();

    // Sender sees their own message immediately (optimistic send, Volume 2 Sec 4).
    await expect(senderSession.page.getByText(messageText)).toBeVisible({ timeout: 2000 });

    // Recipient receives it over the WS gateway without reloading —
    // this is the assertion that actually proves real-time delivery,
    // not just that the REST send endpoint works.
    await expect(recipientSession.page.getByText(messageText)).toBeVisible({ timeout: 5000 });

    await senderSession.context.close();
    await recipientSession.context.close();
  });

  test('typing indicator appears for the recipient while the sender is composing', async ({
    browser,
    request,
  }) => {
    const sender = await createTestUser(request, 'typing_sender');
    const recipient = await createTestUser(request, 'typing_recipient');
    const conversationId = await createDirectConversation(request, sender.accessToken, recipient.userId);

    const [senderSession, recipientSession] = await Promise.all([
      signIn(browser, sender),
      signIn(browser, recipient),
    ]);

    await Promise.all([
      senderSession.page.goto(`/conversations/${conversationId}`),
      recipientSession.page.goto(`/conversations/${conversationId}`),
    ]);

    await senderSession.page.getByPlaceholder('Write a message').fill('typing…');

    await expect(recipientSession.page.getByText('typing')).toBeVisible({ timeout: 3000 });

    await senderSession.context.close();
    await recipientSession.context.close();
  });
});
