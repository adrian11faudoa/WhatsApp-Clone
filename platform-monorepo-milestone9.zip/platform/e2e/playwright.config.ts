import { defineConfig, devices } from '@playwright/test';

/**
 * Scenario-level E2E, per architecture-phase1-vol3.md Section 6.3:
 * "deliberately few and high-value ... rather than attempting E2E
 * coverage of every permutation, which belongs at the integration tier
 * instead." Runs against the full stack brought up by the root
 * docker-compose.yml — these are NOT unit or integration tests; every
 * service's own test suite already covers those tiers independently.
 */
export default defineConfig({
  testDir: './tests',
  fullyParallel: false, // scenarios share backend state (real Postgres/Kafka/Redis) — run serially
  retries: 1,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL: process.env.WEB_CLIENT_URL ?? 'http://localhost:3000',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
});
