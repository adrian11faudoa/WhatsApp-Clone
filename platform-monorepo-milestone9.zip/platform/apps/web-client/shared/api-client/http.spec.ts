import { apiFetch, ApiError } from './http';

describe('apiFetch', () => {
  const originalFetch = global.fetch;

  afterEach(() => {
    global.fetch = originalFetch;
    jest.restoreAllMocks();
  });

  it('sends an Authorization header when accessToken is provided', async () => {
    const mockFetch = jest.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    });
    global.fetch = mockFetch as unknown as typeof fetch;

    await apiFetch('http://api.test', '/thing', { accessToken: 'tok123' });

    expect(mockFetch).toHaveBeenCalledWith(
      'http://api.test/thing',
      expect.objectContaining({
        headers: expect.objectContaining({ Authorization: 'Bearer tok123' }),
      }),
    );
  });

  it('returns undefined for a 204 No Content response without parsing a body', async () => {
    const mockFetch = jest.fn().mockResolvedValue({ ok: true, status: 204 });
    global.fetch = mockFetch as unknown as typeof fetch;

    const result = await apiFetch('http://api.test', '/thing', { method: 'DELETE' });
    expect(result).toBeUndefined();
  });

  it('throws ApiError with the RFC 7807 fields on a non-2xx response', async () => {
    const mockFetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
      json: async () => ({ detail: 'Invalid credentials', errorCode: 'invalid_credentials' }),
    });
    global.fetch = mockFetch as unknown as typeof fetch;

    await expect(apiFetch('http://api.test', '/thing')).rejects.toMatchObject({
      message: 'Invalid credentials',
      status: 401,
      errorCode: 'invalid_credentials',
    });
  });

  it('ApiError is an instance of Error with the correct name', async () => {
    const mockFetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 500,
      statusText: 'Internal Server Error',
      json: async () => null,
    });
    global.fetch = mockFetch as unknown as typeof fetch;

    try {
      await apiFetch('http://api.test', '/thing');
      fail('expected apiFetch to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(ApiError);
      expect((err as ApiError).name).toBe('ApiError');
    }
  });
});
