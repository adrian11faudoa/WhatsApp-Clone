/**
 * Thin fetch wrapper. Each backend service is called directly from the
 * browser (Volume 3 Sec 3.4: Next.js API routes are a BFF only for
 * cookie handling and multi-service aggregation, not a general proxy) —
 * this client just standardizes auth header injection, JSON handling,
 * and RFC 7807 Problem Details error parsing (Volume 2 Sec 3.1) so every
 * feature module gets consistent error shapes.
 */

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly errorCode: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  body?: unknown;
  accessToken?: string | null;
  idempotencyKey?: string;
}

export async function apiFetch<T>(baseUrl: string, path: string, options: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (options.accessToken) {
    headers.Authorization = `Bearer ${options.accessToken}`;
  }
  if (options.idempotencyKey) {
    headers['Idempotency-Key'] = options.idempotencyKey;
  }

  const response = await fetch(`${baseUrl}${path}`, {
    method: options.method ?? 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  if (response.status === 204) {
    return undefined as T;
  }

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new ApiError(
      (data?.detail as string) ?? response.statusText,
      response.status,
      (data?.errorCode as string) ?? 'unknown_error',
    );
  }

  return data as T;
}
