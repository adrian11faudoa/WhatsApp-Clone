'use client';

import Link from 'next/link';
import { Conversation } from '../../features/messaging/api';
import { Avatar } from './avatar';
import { PresenceDot } from './presence-dot';
import { usePresence } from '../../features/presence/hooks';

function conversationLabel(conversation: Conversation, currentUserId: string): string {
  if (conversation.type === 'direct') {
    const other = conversation.participants.find((p) => p.userId !== currentUserId);
    return other ? other.userId.slice(0, 8) : 'Direct message';
  }
  return `Group · ${conversation.participants.length} members`;
}

export function ConversationListItem({
  conversation,
  currentUserId,
  isActive,
}: {
  conversation: Conversation;
  currentUserId: string;
  isActive: boolean;
}) {
  const other = conversation.participants.find((p) => p.userId !== currentUserId);
  const presence = usePresence(other?.userId ?? '');
  const label = conversationLabel(conversation, currentUserId);

  return (
    <Link
      href={`/conversations/${conversation.id}`}
      className={`flex items-center gap-3 rounded-chat px-3 py-2.5 transition-colors ${
        isActive ? 'bg-ink-700' : 'hover:bg-ink-800'
      }`}
    >
      <div className="relative">
        <Avatar id={conversation.id} name={label} />
        {conversation.type === 'direct' && (
          <span className="absolute -bottom-0.5 -right-0.5">
            <PresenceDot status={presence?.status} />
          </span>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate font-body text-sm font-medium text-paper-50">{label}</p>
        <p className="truncate font-body text-xs text-paper-100/50">
          {conversation.type === 'direct' ? (presence?.status ?? 'offline') : 'group conversation'}
        </p>
      </div>
    </Link>
  );
}
