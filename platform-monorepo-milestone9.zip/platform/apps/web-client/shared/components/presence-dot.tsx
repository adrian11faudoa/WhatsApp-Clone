const COLORS: Record<string, string> = {
  online: 'bg-signal-500',
  away: 'bg-away',
  offline: 'bg-offline',
};

export function PresenceDot({ status }: { status?: 'online' | 'away' | 'offline' }) {
  const color = COLORS[status ?? 'offline'];
  return (
    <span
      className={`inline-block h-2.5 w-2.5 rounded-full ring-2 ring-ink-900 ${color}`}
      aria-label={`Status: ${status ?? 'offline'}`}
      role="status"
    />
  );
}
