import { Message } from '../../features/messaging/api';

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function MessageBubble({ message, isOwn }: { message: Message; isOwn: boolean }) {
  return (
    <div className={`flex w-full ${isOwn ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[70%] rounded-chat px-4 py-2.5 font-body text-[15px] leading-relaxed ${
          isOwn
            ? `bg-signal-500 text-white ${message.pending ? 'opacity-60' : ''}`
            : 'bg-ink-800 text-paper-100'
        }`}
      >
        <p className="whitespace-pre-wrap break-words">{message.content}</p>
        <span
          className={`mt-1 block text-right font-mono text-[10px] tracking-wide ${
            isOwn ? 'text-white/70' : 'text-paper-100/50'
          }`}
        >
          {message.pending ? 'sending…' : formatTime(message.createdAt)}
        </span>
      </div>
    </div>
  );
}
