import { ButtonHTMLAttributes } from 'react';

type Variant = 'primary' | 'ghost';

const VARIANT_CLASSES: Record<Variant, string> = {
  primary: 'bg-signal-500 text-white hover:bg-signal-600 disabled:bg-signal-500/40',
  ghost: 'bg-transparent text-ink-700 hover:bg-ink-800/5 disabled:text-ink-700/40',
};

export function Button({
  variant = 'primary',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      className={`rounded-chat px-4 py-2 font-body text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-signal-500 disabled:cursor-not-allowed ${VARIANT_CLASSES[variant]} ${className}`}
      {...props}
    />
  );
}
