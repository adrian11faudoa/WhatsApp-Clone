function initialsFrom(name: string): string {
  return name
    .split(' ')
    .map((part) => part[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

/** Deterministic hue from a string id so the same person always gets the same avatar color. */
function hueFrom(id: string): number {
  let hash = 0;
  for (let i = 0; i < id.length; i += 1) {
    hash = (hash * 31 + id.charCodeAt(i)) % 360;
  }
  return hash;
}

export function Avatar({ id, name, size = 36 }: { id: string; name: string; size?: number }) {
  const hue = hueFrom(id);
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-full font-display text-sm font-medium text-paper-50"
      style={{
        width: size,
        height: size,
        backgroundColor: `hsl(${hue} 45% 32%)`,
      }}
    >
      {initialsFrom(name || '?')}
    </div>
  );
}
