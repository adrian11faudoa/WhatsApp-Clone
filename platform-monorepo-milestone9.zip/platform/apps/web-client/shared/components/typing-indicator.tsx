export function TypingIndicator({ visible }: { visible: boolean }) {
  if (!visible) return <div className="h-5" aria-hidden />;
  return (
    <div className="flex h-5 items-center gap-1 pl-1 font-mono text-xs text-paper-100/50" aria-live="polite">
      <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-paper-100/50" />
      <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-paper-100/50 [animation-delay:150ms]" />
      <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-paper-100/50 [animation-delay:300ms]" />
      <span>typing</span>
    </div>
  );
}
