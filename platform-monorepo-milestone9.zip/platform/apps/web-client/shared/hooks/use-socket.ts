'use client';

import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

/**
 * Generic Socket.IO connection manager — one hook, parameterized by
 * base URL/namespace, reused by both the Messaging and Presence gateways
 * (Volume 3 Sec 3.1: shared/websocket is a single connection manager per
 * feature, not duplicated ad hoc). Auth token is sent via the `auth`
 * handshake payload, matching how both gateways verify it server-side
 * (identity-service/messaging-service/presence-service's
 * `extractToken()` all check `socket.handshake.auth.token` first).
 */
export function useSocket(baseUrl: string, namespace: string, accessToken: string | null): Socket | null {
  const [socket, setSocket] = useState<Socket | null>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!accessToken) {
      socketRef.current?.disconnect();
      socketRef.current = null;
      setSocket(null);
      return;
    }

    const instance = io(`${baseUrl}${namespace}`, {
      auth: { token: accessToken },
      transports: ['websocket'],
    });
    socketRef.current = instance;
    setSocket(instance);

    return () => {
      instance.disconnect();
      socketRef.current = null;
    };
  }, [baseUrl, namespace, accessToken]);

  return socket;
}
