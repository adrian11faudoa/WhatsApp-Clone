import type { Config } from 'tailwindcss';

/**
 * Design tokens for the messaging app shell — deliberately not the
 * generic cream/terracotta AI-default palette. This is a focused,
 * utility-first chat product: the signature choice is a deep ink
 * background for the sidebar against a warm paper canvas for the
 * conversation surface, with a single saturated accent (signal blue)
 * reserved for the user's own sent messages and unread indicators —
 * so it always means "this is yours / this needs you," never decoration.
 */
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './features/**/*.{ts,tsx}', './shared/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0B0E14',
          900: '#12161F',
          800: '#1B2029',
          700: '#262C38',
        },
        paper: {
          50: '#FAF9F6',
          100: '#F2F0EA',
        },
        signal: {
          500: '#3E63DD',
          600: '#3355C9',
        },
        away: '#D9A441',
        offline: '#6B7280',
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        body: ['"Inter"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        chat: '18px',
      },
    },
  },
  plugins: [],
};

export default config;
