/**
 * DEVIATION FROM VOLUME 3 FLAGGED EXPLICITLY: architecture-phase1-vol3.md
 * Section 3.4 specifies the web client's refresh token lives in an
 * httpOnly, Secure, SameSite=Strict cookie via a Next.js BFF route, with
 * a CSRF double-submit token on the refresh endpoint (Volume 2 Sec 6) —
 * that is the correct production posture. This milestone stores both
 * tokens in localStorage instead, which is simpler to stand up for an
 * MVP wiring exercise but is genuinely XSS-vulnerable in a way the
 * cookie approach is not. This is a real security trade-off, not a
 * detail — it must be replaced with the BFF cookie flow before this
 * client handles real user data. See README "Known gaps" section.
 */

const ACCESS_TOKEN_KEY = 'platform.accessToken';
const REFRESH_TOKEN_KEY = 'platform.refreshToken';

export interface StoredTokens {
  accessToken: string;
  refreshToken: string;
}

export const tokenStorage = {
  get(): StoredTokens | null {
    if (typeof window === 'undefined') return null;
    const accessToken = window.localStorage.getItem(ACCESS_TOKEN_KEY);
    const refreshToken = window.localStorage.getItem(REFRESH_TOKEN_KEY);
    if (!accessToken || !refreshToken) return null;
    return { accessToken, refreshToken };
  },

  set(tokens: StoredTokens): void {
    window.localStorage.setItem(ACCESS_TOKEN_KEY, tokens.accessToken);
    window.localStorage.setItem(REFRESH_TOKEN_KEY, tokens.refreshToken);
  },

  clear(): void {
    window.localStorage.removeItem(ACCESS_TOKEN_KEY);
    window.localStorage.removeItem(REFRESH_TOKEN_KEY);
  },
};
