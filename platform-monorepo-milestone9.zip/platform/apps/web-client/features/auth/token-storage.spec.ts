/**
 * @jest-environment jsdom
 */
import { tokenStorage } from './token-storage';

describe('tokenStorage', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('returns null when no tokens are stored', () => {
    expect(tokenStorage.get()).toBeNull();
  });

  it('stores and retrieves a token pair', () => {
    tokenStorage.set({ accessToken: 'access-1', refreshToken: 'refresh-1' });
    expect(tokenStorage.get()).toEqual({ accessToken: 'access-1', refreshToken: 'refresh-1' });
  });

  it('clears stored tokens', () => {
    tokenStorage.set({ accessToken: 'access-1', refreshToken: 'refresh-1' });
    tokenStorage.clear();
    expect(tokenStorage.get()).toBeNull();
  });

  it('returns null if only one of the two tokens is present', () => {
    window.localStorage.setItem('platform.accessToken', 'access-1');
    expect(tokenStorage.get()).toBeNull();
  });
});
