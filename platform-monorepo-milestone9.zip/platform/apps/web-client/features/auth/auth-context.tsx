'use client';

import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { authApi, CurrentUser } from './api';
import { tokenStorage } from './token-storage';

interface AuthContextValue {
  currentUser: CurrentUser | null;
  accessToken: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (input: { username: string; email: string; password: string; displayName: string }) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  const loadCurrentUser = useCallback(async (token: string) => {
    const user = await authApi.me(token);
    setCurrentUser(user);
  }, []);

  // On mount: try to restore a session from stored tokens, refreshing
  // the access token first since it's short-lived (15 min, Volume 2 Sec 6)
  // and likely stale by the time the browser reopens the app.
  useEffect(() => {
    let cancelled = false;

    async function restoreSession() {
      const stored = tokenStorage.get();
      if (!stored) {
        setIsLoading(false);
        return;
      }
      try {
        const refreshed = await authApi.refresh(stored.refreshToken);
        if (cancelled) return;
        tokenStorage.set(refreshed);
        setAccessToken(refreshed.accessToken);
        await loadCurrentUser(refreshed.accessToken);
      } catch {
        tokenStorage.clear();
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    restoreSession();
    return () => {
      cancelled = true;
    };
  }, [loadCurrentUser]);

  const login = useCallback(
    async (email: string, password: string) => {
      const tokens = await authApi.login({ email, password });
      tokenStorage.set(tokens);
      setAccessToken(tokens.accessToken);
      await loadCurrentUser(tokens.accessToken);
      router.push('/conversations');
    },
    [loadCurrentUser, router],
  );

  const register = useCallback(
    async (input: { username: string; email: string; password: string; displayName: string }) => {
      await authApi.register(input);
      // Registration leaves the account pending_verification (Volume 2 Sec 1.1) —
      // this milestone doesn't yet implement the verification flow, so we route
      // to login rather than pretending the user is immediately signed in.
      router.push('/login?registered=1');
    },
    [router],
  );

  const logout = useCallback(async () => {
    if (accessToken) {
      await authApi.logout(accessToken).catch(() => undefined);
    }
    tokenStorage.clear();
    setAccessToken(null);
    setCurrentUser(null);
    router.push('/login');
  }, [accessToken, router]);

  return (
    <AuthContext.Provider value={{ currentUser, accessToken, isLoading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
