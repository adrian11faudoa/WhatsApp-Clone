import { apiFetch } from '../../shared/api-client/http';

const IDENTITY_URL = process.env.NEXT_PUBLIC_IDENTITY_SERVICE_URL!;

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface CurrentUser {
  id: string;
  username: string;
  email?: string;
  displayName: string;
  status: string;
  createdAt: string;
}

export const authApi = {
  register: (input: { username: string; email: string; password: string; displayName: string }) =>
    apiFetch<{ userId: string }>(IDENTITY_URL, '/api/v1/auth/register', {
      method: 'POST',
      body: input,
    }),

  login: (input: { email: string; password: string }) =>
    apiFetch<AuthTokens>(IDENTITY_URL, '/api/v1/auth/login', { method: 'POST', body: input }),

  refresh: (refreshToken: string) =>
    apiFetch<AuthTokens>(IDENTITY_URL, '/api/v1/auth/token/refresh', {
      method: 'POST',
      body: { refreshToken },
    }),

  logout: (accessToken: string) =>
    apiFetch<void>(IDENTITY_URL, '/api/v1/auth/logout', { method: 'POST', accessToken }),

  me: (accessToken: string) =>
    apiFetch<CurrentUser>(IDENTITY_URL, '/api/v1/users/me', { accessToken }),
};
