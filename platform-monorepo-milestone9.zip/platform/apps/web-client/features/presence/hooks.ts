'use client';

import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '../auth/auth-context';
import { useSocket } from '../../shared/hooks/use-socket';
import { presenceApi, PresenceStatus } from './api';

const PRESENCE_URL = process.env.NEXT_PUBLIC_PRESENCE_SERVICE_URL!;

// Well under presence-service's default AWAY_AFTER_SECONDS (300s) so a
// genuinely-connected, actively-used session never flips to "away" —
// found via a cross-service contract audit: presence.gateway.ts defines
// an 'onHeartbeat' handler that nothing in this client was calling,
// meaning every session would incorrectly go "away" after 5 minutes
// regardless of real activity. This interval is the fix.
const HEARTBEAT_INTERVAL_MS = 60_000;

/**
 * Fetches initial status via REST, then subscribes over WS for live
 * updates — never polls (architecture-phase1-vol3.md Section 7's
 * explicit "no polling" rule for presence). Also sends the periodic
 * heartbeat presence-service's online/away derivation depends on.
 */
export function usePresence(userId: string): PresenceStatus | undefined {
  const { accessToken } = useAuth();
  const socket = useSocket(PRESENCE_URL, '/presence', accessToken);
  const [liveStatus, setLiveStatus] = useState<PresenceStatus | null>(null);

  const { data: initialStatus } = useQuery({
    queryKey: ['presence', userId],
    queryFn: () => presenceApi.getStatus(accessToken!, userId),
    enabled: !!accessToken && !!userId,
    staleTime: Infinity, // the WS subscription is the freshness mechanism from here on
  });

  useEffect(() => {
    if (!socket || !userId) return;

    socket.emit('presence:subscribe', { userId });

    const onUpdate = (status: PresenceStatus) => {
      if (status.userId === userId) setLiveStatus(status);
    };

    socket.on('presence:update', onUpdate);
    return () => {
      socket.off('presence:update', onUpdate);
    };
  }, [socket, userId]);

  // NOTE (found during the same audit as the heartbeat fix above): this
  // hook is called once per visible ConversationListItem, and useSocket
  // opens a NEW connection per call rather than sharing one — so a
  // sidebar with 10 direct conversations opens 10 real WS connections to
  // presence-service, each independently heartbeating. Functionally
  // harmless (each just adds/removes its own session id from the same
  // user's Redis session set) but genuinely wasteful. Fixing it properly
  // means turning useSocket into a shared, connection-pooled provider —
  // a real change, not a one-line fix, so it's flagged here rather than
  // done as a drive-by edit alongside the heartbeat bug.
  useEffect(() => {
    if (!socket) return;
    const interval = setInterval(() => socket.emit('heartbeat'), HEARTBEAT_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [socket]);

  return liveStatus ?? initialStatus;
}
