import { apiFetch } from '../../shared/api-client/http';

const PRESENCE_URL = process.env.NEXT_PUBLIC_PRESENCE_SERVICE_URL!;

export interface PresenceStatus {
  userId: string;
  status: 'online' | 'away' | 'offline';
  lastActivityAt: string | null;
}

export const presenceApi = {
  getStatus: (accessToken: string, userId: string) =>
    apiFetch<PresenceStatus>(PRESENCE_URL, `/api/v1/presence/${userId}`, { accessToken }),
};
