import { apiFetch } from '../../shared/api-client/http';

const MESSAGING_URL = process.env.NEXT_PUBLIC_MESSAGING_SERVICE_URL!;

export interface ConversationParticipant {
  userId: string;
  role: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group' | 'channel';
  participants: ConversationParticipant[];
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  contentType: string;
  content?: string;
  mediaId?: string;
  replyToId?: string;
  createdAt: string;
  editedAt?: string;
  /** Client-only field: not part of the server response, used to render optimistic sends distinctly. */
  pending?: boolean;
}

export interface PaginatedMessages {
  items: Message[];
  nextCursor: string | null;
}

export const messagingApi = {
  listConversations: (accessToken: string) =>
    apiFetch<Conversation[]>(MESSAGING_URL, '/api/v1/conversations', { accessToken }),

  createConversation: (accessToken: string, input: { type: 'direct' | 'group'; participantIds: string[] }) =>
    apiFetch<Conversation>(MESSAGING_URL, '/api/v1/conversations', {
      method: 'POST',
      accessToken,
      body: input,
    }),

  getHistory: (accessToken: string, conversationId: string, cursor?: string) =>
    apiFetch<PaginatedMessages>(
      MESSAGING_URL,
      `/api/v1/conversations/${conversationId}/messages${cursor ? `?cursor=${cursor}` : ''}`,
      { accessToken },
    ),

  sendMessage: (
    accessToken: string,
    conversationId: string,
    input: { clientMessageId: string; contentType: string; content?: string },
  ) =>
    apiFetch<Message>(MESSAGING_URL, `/api/v1/conversations/${conversationId}/messages`, {
      method: 'POST',
      accessToken,
      idempotencyKey: input.clientMessageId,
      body: input,
    }),

  sendReceipt: (accessToken: string, messageId: string, status: 'delivered' | 'read') =>
    apiFetch<void>(MESSAGING_URL, `/api/v1/messages/${messageId}/receipts`, {
      method: 'POST',
      accessToken,
      body: { status },
    }),
};
