'use client';

import { useCallback, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Socket } from 'socket.io-client';
import { useAuth } from '../auth/auth-context';
import { useSocket } from '../../shared/hooks/use-socket';
import { messagingApi, Message } from './api';

const MESSAGING_URL = process.env.NEXT_PUBLIC_MESSAGING_SERVICE_URL!;

export function useMessagingSocket(): Socket | null {
  const { accessToken } = useAuth();
  return useSocket(MESSAGING_URL, '/messaging', accessToken);
}

export function useConversationMessages(conversationId: string) {
  const { accessToken } = useAuth();
  return useQuery({
    queryKey: ['messages', conversationId],
    queryFn: () => messagingApi.getHistory(accessToken!, conversationId),
    enabled: !!accessToken && !!conversationId,
  });
}

export function useConversations() {
  const { accessToken } = useAuth();
  return useQuery({
    queryKey: ['conversations'],
    queryFn: () => messagingApi.listConversations(accessToken!),
    enabled: !!accessToken,
  });
}

export function useCreateConversation() {
  const { accessToken } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (input: { type: 'direct' | 'group'; participantIds: string[] }) =>
      messagingApi.createConversation(accessToken!, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

/**
 * Joins the conversation's WS room and wires incoming events directly
 * into the TanStack Query cache — per architecture-phase1-vol3.md
 * Section 3.2: "a new message arriving over the socket and a new message
 * returned from a REST fetch update the exact same cache entry," which
 * is what avoids two-sources-of-truth bugs for the same conversation.
 */
export function useJoinConversation(conversationId: string): void {
  const socket = useMessagingSocket();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!socket || !conversationId) return;

    socket.emit('conversation:join', { conversationId });

    const onNewMessage = (message: Message) => {
      if (message.conversationId !== conversationId) return;
      queryClient.setQueryData<{ items: Message[]; nextCursor: string | null }>(
        ['messages', conversationId],
        (old) => {
          if (!old) return { items: [message], nextCursor: null };
          // Reconcile: if this confirms a pending optimistic message with the
          // same content we sent, the optimistic entry is already present via
          // its clientMessageId-derived temp id, and the send mutation replaces
          // it directly — this branch only handles messages from OTHER senders.
          if (old.items.some((m) => m.id === message.id)) return old;
          return { ...old, items: [message, ...old.items] };
        },
      );
    };

    socket.on('message:new', onNewMessage);
    return () => {
      socket.off('message:new', onNewMessage);
    };
  }, [socket, conversationId, queryClient]);
}

export function useSendMessage(conversationId: string) {
  const { accessToken, currentUser } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (input: { content: string; clientMessageId: string }) =>
      messagingApi.sendMessage(accessToken!, conversationId, {
        clientMessageId: input.clientMessageId,
        contentType: 'text',
        content: input.content,
      }),

    onMutate: async (input) => {
      // Optimistic update keyed by clientMessageId (Volume 3 Sec 3.2) — the
      // real message, once it round-trips (REST response or WS echo), is
      // reconciled by clientMessageId in onSuccess below.
      const optimisticMessage: Message = {
        id: `pending-${input.clientMessageId}`,
        conversationId,
        senderId: currentUser!.id,
        contentType: 'text',
        content: input.content,
        createdAt: new Date().toISOString(),
        pending: true,
      };

      queryClient.setQueryData<{ items: Message[]; nextCursor: string | null }>(
        ['messages', conversationId],
        (old) => (old ? { ...old, items: [optimisticMessage, ...old.items] } : { items: [optimisticMessage], nextCursor: null }),
      );

      return { tempId: optimisticMessage.id };
    },

    onSuccess: (confirmedMessage, _input, context) => {
      queryClient.setQueryData<{ items: Message[]; nextCursor: string | null }>(
        ['messages', conversationId],
        (old) => {
          if (!old) return { items: [confirmedMessage], nextCursor: null };
          return {
            ...old,
            items: old.items.map((m) => (m.id === context?.tempId ? confirmedMessage : m)),
          };
        },
      );
    },

    onError: (_err, _input, context) => {
      // Leave the optimistic entry but mark it failed — a real UI would
      // show a retry affordance here; kept minimal for this milestone.
      queryClient.setQueryData<{ items: Message[]; nextCursor: string | null }>(
        ['messages', conversationId],
        (old) => {
          if (!old) return old;
          return {
            ...old,
            items: old.items.filter((m) => m.id !== context?.tempId),
          };
        },
      );
    },
  });
}

export function useTypingIndicator(conversationId: string) {
  const socket = useMessagingSocket();

  const startTyping = useCallback(() => {
    socket?.emit('typing:start', { conversationId });
  }, [socket, conversationId]);

  const stopTyping = useCallback(() => {
    socket?.emit('typing:stop', { conversationId });
  }, [socket, conversationId]);

  return { startTyping, stopTyping };
}
