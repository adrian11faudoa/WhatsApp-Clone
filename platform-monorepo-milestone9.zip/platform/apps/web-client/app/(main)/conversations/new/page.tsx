'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCreateConversation } from '../../../../features/messaging/hooks';
import { ApiError } from '../../../../shared/api-client/http';
import { Button } from '../../../../shared/components/button';

/**
 * Minimal "start a conversation" flow: paste the other user's id
 * directly. A real product needs a user search/directory (backed by the
 * Search service — Volume 1 Sec 4.1), which isn't built yet in this
 * milestone set. Flagged rather than faked with a mock search box.
 */
export default function NewConversationPage() {
  const router = useRouter();
  const createConversation = useCreateConversation();
  const [participantId, setParticipantId] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      const conversation = await createConversation.mutateAsync({
        type: 'direct',
        participantIds: [participantId.trim()],
      });
      router.push(`/conversations/${conversation.id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start conversation.');
    }
  }

  return (
    <div className="flex flex-1 items-center justify-center">
      <form onSubmit={onSubmit} className="w-full max-w-sm space-y-4 px-6">
        <h2 className="font-display text-xl text-paper-50">Start a conversation</h2>
        <p className="font-body text-xs text-paper-100/50">
          Enter the other person&apos;s user ID. (No directory/search yet — see README.)
        </p>
        <input
          value={participantId}
          onChange={(e) => setParticipantId(e.target.value)}
          placeholder="user-id"
          required
          className="w-full rounded-chat border border-ink-700 bg-ink-800 px-3 py-2 font-body text-sm text-paper-50 outline-none focus:border-signal-500"
        />
        {error && <p className="font-body text-sm text-red-400">{error}</p>}
        <Button type="submit" disabled={createConversation.isPending} className="w-full">
          {createConversation.isPending ? 'Starting…' : 'Start conversation'}
        </Button>
      </form>
    </div>
  );
}
