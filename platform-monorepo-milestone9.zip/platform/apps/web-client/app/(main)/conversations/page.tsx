export default function ConversationsIndexPage() {
  return (
    <div className="flex flex-1 items-center justify-center">
      <p className="font-body text-sm text-paper-100/40">Select a conversation, or start a new one.</p>
    </div>
  );
}
