'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';
import { useParams } from 'next/navigation';
import { useAuth } from '../../../../features/auth/auth-context';
import {
  useConversationMessages,
  useJoinConversation,
  useSendMessage,
  useTypingIndicator,
  useMessagingSocket,
} from '../../../../features/messaging/hooks';
import { MessageBubble } from '../../../../shared/components/message-bubble';
import { TypingIndicator } from '../../../../shared/components/typing-indicator';
import { Button } from '../../../../shared/components/button';

export default function ConversationPage() {
  const { id: conversationId } = useParams<{ id: string }>();
  const { currentUser } = useAuth();

  const { data, isLoading } = useConversationMessages(conversationId);
  useJoinConversation(conversationId);
  const sendMessage = useSendMessage(conversationId);
  const { startTyping, stopTyping } = useTypingIndicator(conversationId);
  const socket = useMessagingSocket();

  const [draft, setDraft] = useState('');
  const [othersTyping, setOthersTyping] = useState(false);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrollAnchorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!socket) return;
    const onTypingUpdate = (payload: { conversationId: string; userId: string; isTyping: boolean }) => {
      if (payload.conversationId !== conversationId || payload.userId === currentUser?.id) return;
      setOthersTyping(payload.isTyping);
    };
    socket.on('typing:update', onTypingUpdate);
    return () => {
      socket.off('typing:update', onTypingUpdate);
    };
  }, [socket, conversationId, currentUser?.id]);

  useEffect(() => {
    scrollAnchorRef.current?.scrollIntoView({ block: 'end' });
  }, [data?.items.length]);

  function handleDraftChange(value: string) {
    setDraft(value);
    startTyping();
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(stopTyping, 2000);
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const content = draft.trim();
    if (!content) return;
    sendMessage.mutate({ content, clientMessageId: crypto.randomUUID() });
    setDraft('');
    stopTyping();
  }

  if (isLoading) {
    return <div className="flex flex-1 items-center justify-center text-paper-100/40">Loading…</div>;
  }

  // Messages arrive newest-first from the API (Volume 2 Sec 3.2's cursor
  // pagination); reverse for top-to-bottom chat rendering.
  const messages = [...(data?.items ?? [])].reverse();

  return (
    <div className="flex flex-1 flex-col">
      <div className="flex-1 space-y-2 overflow-y-auto px-6 py-6">
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} isOwn={message.senderId === currentUser?.id} />
        ))}
        <div ref={scrollAnchorRef} />
      </div>

      <div className="px-6">
        <TypingIndicator visible={othersTyping} />
      </div>

      <form onSubmit={onSubmit} className="flex items-center gap-3 border-t border-ink-800 px-6 py-4">
        <input
          value={draft}
          onChange={(e) => handleDraftChange(e.target.value)}
          placeholder="Write a message"
          className="flex-1 rounded-chat border border-ink-700 bg-ink-800 px-4 py-2.5 font-body text-sm text-paper-50 outline-none focus:border-signal-500"
        />
        <Button type="submit" disabled={!draft.trim()}>
          Send
        </Button>
      </form>
    </div>
  );
}
