'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '../../features/auth/auth-context';
import { useConversations } from '../../features/messaging/hooks';
import { ConversationListItem } from '../../shared/components/conversation-list-item';
import { Avatar } from '../../shared/components/avatar';
import { Button } from '../../shared/components/button';

/**
 * App shell — sidebar (conversation list) + detail pane, matching the
 * three-pane desktop layout from architecture-phase1-vol3.md Section 3.5.
 * This milestone doesn't implement the mobile single-column collapse;
 * flagged in the web-client README rather than silently only working on
 * desktop widths.
 */
export default function MainLayout({ children }: { children: React.ReactNode }) {
  const { currentUser, isLoading, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const { data: conversations } = useConversations();

  useEffect(() => {
    if (!isLoading && !currentUser) {
      router.replace('/login');
    }
  }, [isLoading, currentUser, router]);

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center text-paper-100/50">Loading…</div>;
  }

  if (!currentUser) {
    return null; // redirect effect above will fire
  }

  return (
    <div className="flex h-screen bg-paper-50">
      <aside className="flex w-80 shrink-0 flex-col bg-ink-950 text-paper-50">
        <div className="flex items-center justify-between border-b border-ink-800 px-4 py-4">
          <div className="flex items-center gap-2">
            <Avatar id={currentUser.id} name={currentUser.displayName} size={32} />
            <span className="font-body text-sm font-medium">{currentUser.displayName}</span>
          </div>
          <Button variant="ghost" onClick={() => logout()} className="!px-2 !py-1 text-xs">
            Sign out
          </Button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto p-2">
          <Link
            href="/conversations/new"
            className="mb-1 block rounded-chat px-3 py-2 text-center font-body text-xs font-medium text-signal-500 hover:bg-ink-800"
          >
            + New conversation
          </Link>
          {conversations?.length === 0 && (
            <p className="px-3 py-6 text-center font-body text-sm text-paper-100/40">
              No conversations yet. Start one to see it here.
            </p>
          )}
          {conversations?.map((conversation) => (
            <ConversationListItem
              key={conversation.id}
              conversation={conversation}
              currentUserId={currentUser.id}
              isActive={pathname === `/conversations/${conversation.id}`}
            />
          ))}
        </nav>
      </aside>

      <main className="flex flex-1 flex-col bg-ink-900">{children}</main>
    </div>
  );
}
