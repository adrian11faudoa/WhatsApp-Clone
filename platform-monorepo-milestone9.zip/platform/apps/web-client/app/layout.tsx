import type { Metadata } from 'next';
import './globals.css';
import { AppQueryProvider } from '../lib/query-client';
import { AuthProvider } from '../features/auth/auth-context';

export const metadata: Metadata = {
  title: 'Platform',
  description: 'Real-time messaging',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-ink-950 font-body text-paper-50 antialiased">
        <AppQueryProvider>
          <AuthProvider>{children}</AuthProvider>
        </AppQueryProvider>
      </body>
    </html>
  );
}
