'use client';

import { FormEvent, Suspense, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '../../../features/auth/auth-context';
import { ApiError } from '../../../shared/api-client/http';
import { Button } from '../../../shared/components/button';

function LoginForm() {
  const { login } = useAuth();
  const searchParams = useSearchParams();
  const justRegistered = searchParams.get('registered') === '1';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);
    try {
      await login(email, password);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong. Try again.');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-1 font-display text-3xl font-medium text-paper-50">Welcome back</h1>
        <p className="mb-8 font-body text-sm text-paper-100/60">Sign in to keep the conversation going.</p>

        {justRegistered && (
          <p className="mb-6 rounded-chat bg-signal-500/10 px-3 py-2 font-body text-sm text-signal-500">
            Account created — check your email, then sign in.
          </p>
        )}

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="mb-1 block font-body text-xs text-paper-100/60">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-chat border border-ink-700 bg-ink-900 px-3 py-2 font-body text-sm text-paper-50 outline-none focus:border-signal-500"
            />
          </div>
          <div>
            <label htmlFor="password" className="mb-1 block font-body text-xs text-paper-100/60">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-chat border border-ink-700 bg-ink-900 px-3 py-2 font-body text-sm text-paper-50 outline-none focus:border-signal-500"
            />
          </div>

          {error && <p className="font-body text-sm text-red-400">{error}</p>}

          <Button type="submit" disabled={isSubmitting} className="w-full">
            {isSubmitting ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>

        <p className="mt-6 text-center font-body text-sm text-paper-100/60">
          No account?{' '}
          <Link href="/register" className="text-signal-500 hover:underline">
            Create one
          </Link>
        </p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
