'use client';

import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { useAuth } from '../../../features/auth/auth-context';
import { ApiError } from '../../../shared/api-client/http';
import { Button } from '../../../shared/components/button';

export default function RegisterPage() {
  const { register } = useAuth();
  const [form, setForm] = useState({ username: '', email: '', password: '', displayName: '' });
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);
    try {
      await register(form);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong. Try again.');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-1 font-display text-3xl font-medium text-paper-50">Create an account</h1>
        <p className="mb-8 font-body text-sm text-paper-100/60">Takes about a minute.</p>

        <form onSubmit={onSubmit} className="space-y-4">
          <Field label="Display name" value={form.displayName} onChange={(v) => update('displayName', v)} />
          <Field label="Username" value={form.username} onChange={(v) => update('username', v)} />
          <Field label="Email" type="email" value={form.email} onChange={(v) => update('email', v)} />
          <Field label="Password" type="password" value={form.password} onChange={(v) => update('password', v)} />

          {error && <p className="font-body text-sm text-red-400">{error}</p>}

          <Button type="submit" disabled={isSubmitting} className="w-full">
            {isSubmitting ? 'Creating account…' : 'Create account'}
          </Button>
        </form>

        <p className="mt-6 text-center font-body text-sm text-paper-100/60">
          Already have an account?{' '}
          <Link href="/login" className="text-signal-500 hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-1 block font-body text-xs text-paper-100/60">{label}</label>
      <input
        type={type}
        required
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-chat border border-ink-700 bg-ink-900 px-3 py-2 font-body text-sm text-paper-50 outline-none focus:border-signal-500"
      />
    </div>
  );
}
