'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '../features/auth/auth-context';

export default function RootPage() {
  const { currentUser, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (isLoading) return;
    router.replace(currentUser ? '/conversations' : '/login');
  }, [isLoading, currentUser, router]);

  return null;
}
