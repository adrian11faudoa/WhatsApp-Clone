# Web Client

Phase 2 Milestone 5 — Next.js web client wired against the four backend
deployables (`identity-service`, `messaging-service`, `media-service` [not
yet wired — see below], `presence-service`), per the build order in
`architecture-phase1-mvp-addendum.md`.

## What works end-to-end

- Register → sign in → session restore on reload (via refresh-token rotation)
- Start a direct conversation, send/receive messages in real time over
  the Messaging WS gateway, with optimistic send + `clientMessageId`
  reconciliation exactly matching the idempotency contract from
  `architecture-phase1-vol2.md` Section 4
- Typing indicators (WS-only, no Kafka — matches the backend's design)
- Live presence dots on direct-conversation list items (WS `/presence`
  namespace, REST fallback for initial load, zero polling)

## Architecture layering

Matches `architecture-phase1-vol3.md` Section 3.1's feature-first
structure, mirroring the backend's own bounded contexts:

```
features/auth/        # AuthProvider context, token storage, API client
features/messaging/    # REST + WS hooks, TanStack Query cache wiring
features/presence/     # REST + WS hook for live status
shared/api-client/     # Generic fetch wrapper (Problem Details parsing)
shared/hooks/           # useSocket — one connection manager, reused by
                          both messaging and presence gateways
shared/components/      # Design-system-level pieces (Avatar, Button, ...)
```

## Deliberate deviations and gaps — read before treating this as production-ready

1. **Auth tokens live in `localStorage`, not an httpOnly cookie.**
   `architecture-phase1-vol3.md` Section 3.4 specifies a Next.js BFF route
   handling the refresh token as an httpOnly/Secure/SameSite=Strict
   cookie. This milestone uses `localStorage` instead — simpler to wire
   for an MVP integration exercise, but genuinely XSS-vulnerable in a way
   the cookie approach isn't. See the comment block in
   `features/auth/token-storage.ts`. **Must be replaced before this
   client handles real user data.**
2. **No user search/directory.** Starting a conversation requires pasting
   the other user's raw id (`app/(main)/conversations/new/page.tsx`) — the
   Search service that would back a real "find people" flow isn't built
   in this milestone set. Flagged in that page's own comment rather than
   mocked with fake search results.
3. **Media isn't wired.** The Media service (Milestone 3) has no UI
   integration here — no image/file upload in the composer. The
   `media-service` API is ready for it; this is purely a client-side gap.
4. **No mobile-responsive collapse.** The three-pane desktop layout from
   Volume 3 Section 3.5 doesn't yet collapse to single-column on narrow
   viewports — works on desktop widths only.
5. **Reconnection/offline handling is minimal.** If the WS connection
   drops, Socket.IO's default reconnect logic applies, but there's no
   explicit "you're reconnecting" UI state, and no replay-on-reconnect
   (that's the Sync Service's job — Volume 3 Section 4.2 — which isn't
   built yet).

None of these are silent — each is called out here and, where relevant,
in the code itself, so the next milestone knows exactly what to pick up.

## Local development

Requires all backend services running (see each service's own
`docker-compose.yml`, or run them together — a root-level compose file
tying all four together is a reasonable next step, not yet built).

```bash
cp .env.local.example .env.local
npm install
npm run dev
```

## Testing

```bash
npm test        # unit — http client (mocked fetch) + token storage (jsdom)
npm run test:cov
```

Full end-to-end coverage (real two-browser-session message exchange) is
a Playwright suite against a running stack — per
`architecture-phase1-vol3.md` Section 6.3, that's its own deliverable,
not yet built.

## Contract references

- Frontend architecture: `architecture-phase1-vol3.md` Section 3
- Delivery/idempotency contract the optimistic-send logic implements:
  `architecture-phase1-vol2.md` Section 4
