import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

/**
 * Redis is used here for two purposes distinct enough to call out:
 * (1) Presence lookups (which devices/sessions are online for a user) —
 *     read by DeliveryPolicy to decide online vs. offline-queue fan-out.
 * (2) An idempotency guard for the WS "message:send" path — REST already
 *     gets idempotency for free from the DB unique constraint on
 *     (conversation_id, client_message_id), but the low-latency WS path
 *     checks Redis first to reject an obvious duplicate before hitting
 *     Postgres at all.
 */
@Injectable()
export class RedisService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(RedisService.name);
  public client!: Redis;

  constructor(private readonly configService: ConfigService) {}

  onModuleInit(): void {
    this.client = new Redis(this.configService.get<string>('redis.url')!, {
      lazyConnect: false,
      maxRetriesPerRequest: 3,
    });
    this.client.on('error', (err) => this.logger.error('Redis error', err));
  }

  async onModuleDestroy(): Promise<void> {
    await this.client.quit();
  }

  /** Returns true if this is the first time we've seen this idempotency key within the TTL window. */
  async claimIdempotencyKey(key: string, ttlSeconds = 60): Promise<boolean> {
    const result = await this.client.set(`idem:${key}`, '1', 'EX', ttlSeconds, 'NX');
    return result === 'OK';
  }

  async getOnlineSessionIds(userId: string): Promise<string[]> {
    return this.client.smembers(`presence:${userId}:sessions`);
  }
}
