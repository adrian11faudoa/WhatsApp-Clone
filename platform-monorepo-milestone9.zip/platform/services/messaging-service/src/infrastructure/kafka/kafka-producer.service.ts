import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Kafka, Producer } from 'kafkajs';
import { randomUUID } from 'crypto';

export interface DomainEventInput<T> {
  eventType: string;
  payload: T;
  schemaVersion: number;
  key?: string;
  traceId?: string;
  correlationId?: string;
  causationId?: string;
}

/**
 * Publishes domain events per the catalogue in architecture-phase1-vol2.md
 * Section 2.3 (messaging.message.sent/.edited/.deleted, etc). Partition key
 * is always conversationId where applicable — this is what gives the
 * per-conversation ordering guarantee described in Volume 2 Section 4.
 */
@Injectable()
export class KafkaProducerService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(KafkaProducerService.name);
  private readonly kafka: Kafka;
  private producer: Producer;

  constructor(private readonly configService: ConfigService) {
    this.kafka = new Kafka({
      clientId: this.configService.get<string>('kafka.clientId')!,
      brokers: this.configService.get<string[]>('kafka.brokers')!,
      retry: { retries: 8, initialRetryTime: 300 },
    });
    this.producer = this.kafka.producer({ idempotent: true });
  }

  async onModuleInit(): Promise<void> {
    await this.producer.connect();
    this.logger.log('Kafka producer connected');
  }

  async onModuleDestroy(): Promise<void> {
    await this.producer.disconnect();
  }

  async publish<T>(topic: string, event: DomainEventInput<T>): Promise<void> {
    const traceId = event.traceId ?? randomUUID();
    const correlationId = event.correlationId ?? traceId;

    await this.producer.send({
      topic,
      messages: [
        {
          key: event.key,
          value: JSON.stringify({
            eventType: event.eventType,
            payload: event.payload,
            schemaVersion: event.schemaVersion,
          }),
          headers: {
            trace_id: traceId,
            correlation_id: correlationId,
            causation_id: event.causationId ?? '',
            occurred_at: new Date().toISOString(),
          },
        },
      ],
    });
  }
}
