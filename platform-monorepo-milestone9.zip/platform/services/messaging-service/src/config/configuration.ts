export interface AppConfig {
  nodeEnv: string;
  port: number;
  database: { url: string };
  jwt: { publicKeyPath: string };
  kafka: { brokers: string[]; clientId: string; consumerGroup: string };
  redis: { url: string };
  rateLimit: { ttlSeconds: number; max: number };
  messageEditWindowMinutes: number;
}

export default (): AppConfig => ({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: parseInt(process.env.PORT ?? '3002', 10),
  database: { url: process.env.DATABASE_URL ?? '' },
  jwt: { publicKeyPath: process.env.JWT_PUBLIC_KEY_PATH ?? './keys/jwt-public.pem' },
  kafka: {
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    clientId: process.env.KAFKA_CLIENT_ID ?? 'messaging-service',
    consumerGroup: process.env.KAFKA_CONSUMER_GROUP ?? 'messaging-service-group',
  },
  redis: { url: process.env.REDIS_URL ?? 'redis://localhost:6379' },
  rateLimit: {
    ttlSeconds: parseInt(process.env.RATE_LIMIT_TTL_SECONDS ?? '60', 10),
    max: parseInt(process.env.RATE_LIMIT_MAX ?? '100', 10),
  },
  messageEditWindowMinutes: parseInt(process.env.MESSAGE_EDIT_WINDOW_MINUTES ?? '15', 10),
});
