import { NestFactory } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { Logger, ValidationPipe, VersioningType } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { IoAdapter } from '@nestjs/platform-socket.io';
import helmet from 'helmet';
import Redis from 'ioredis';
import { createAdapter } from '@socket.io/redis-adapter';

import { AppModule } from './app.module';
import { PrismaService } from './infrastructure/prisma/prisma.service';

/**
 * Redis-backed Socket.IO adapter — required for horizontal scaling of the
 * Messaging gateway across multiple pods, per architecture-phase1-vol3.md
 * Section 5.1: room state (who's in which conversation) must be shared
 * across all gateway instances, not held in a single pod's memory.
 */
class RedisIoAdapter extends IoAdapter {
  private adapterConstructor: ReturnType<typeof createAdapter> | undefined;

  async connectToRedis(redisUrl: string): Promise<void> {
    const pubClient = new Redis(redisUrl);
    const subClient = pubClient.duplicate();
    this.adapterConstructor = createAdapter(pubClient, subClient);
  }

  createIOServer(port: number, options?: Record<string, unknown>) {
    const server = super.createIOServer(port, options);
    if (this.adapterConstructor) {
      server.adapter(this.adapterConstructor);
    }
    return server;
  }
}

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  const logger = new Logger('Bootstrap');
  const configService = app.get(ConfigService);

  app.use(helmet());
  app.enableCors({
    origin:
      configService.get<string>('nodeEnv') === 'production'
        ? ['https://app.platform.example']
        : true,
    credentials: true,
  });
  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });

  app.useGlobalPipes(
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }),
  );

  const redisIoAdapter = new RedisIoAdapter(app);
  await redisIoAdapter.connectToRedis(configService.get<string>('redis.url')!);
  app.useWebSocketAdapter(redisIoAdapter);

  const prismaService = app.get(PrismaService);
  await prismaService.enableShutdownHooks(app);

  const swaggerConfig = new DocumentBuilder()
    .setTitle('Messaging Service')
    .setDescription(
      'Messaging, Conversation, Delivery, Receipts, Typing bounded context. ' +
        'Contract conventions per architecture-phase1-vol2.md Section 3.1.',
    )
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('api/docs', app, document);

  const port = configService.get<number>('port')!;
  await app.listen(port);
  logger.log(`Messaging Service listening on port ${port} (HTTP + WS /messaging)`);
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Fatal error during bootstrap', err);
  process.exit(1);
});
