import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { readFileSync } from 'fs';

export interface JwtAccessPayload {
  sub: string;
  username: string;
  accountType: string;
  sessionId: string;
}

/**
 * Verifies access tokens issued by the Identity service. Only the RS256
 * public key is needed — per architecture-phase1-vol1.md Section 1, this
 * is what keeps token verification off the hot path with no cross-service
 * call to Identity required for every request.
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(configService: ConfigService) {
    const publicKeyPath = configService.get<string>('jwt.publicKeyPath')!;
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: readFileSync(publicKeyPath, 'utf-8'),
      algorithms: ['RS256'],
    });
  }

  validate(payload: JwtAccessPayload): JwtAccessPayload {
    return payload;
  }
}
