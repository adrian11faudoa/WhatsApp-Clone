import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { RedisService } from '../infrastructure/redis/redis.service';
import { ConversationsService } from './conversations.service';
import { CanSendMessageSpecification } from '../domain/can-send-message.specification';
import { SendMessageDto } from './dto/send-message.dto';
import { EditMessageDto } from './dto/edit-message.dto';
import { ReceiptStatusDto } from './dto/receipt.dto';

const SEND_RATE_LIMIT_PER_MINUTE = 30;

/**
 * Application Service for the message send/edit/delete/history/receipt
 * use cases (Volume 1 Sec 2.3's SendMessageUseCase etc, consolidated into
 * one class for this milestone's scope — splitting into one class per use
 * case is a mechanical refactor, not an architecture decision, deferred
 * until the file would otherwise become unwieldy).
 */
@Injectable()
export class MessagingService {
  private readonly logger = new Logger(MessagingService.name);
  private readonly editWindowMs: number;

  constructor(
    private readonly prisma: PrismaService,
    private readonly kafkaProducer: KafkaProducerService,
    private readonly redis: RedisService,
    private readonly conversations: ConversationsService,
    configService: ConfigService,
  ) {
    this.editWindowMs = configService.get<number>('messageEditWindowMinutes')! * 60_000;
  }

  async sendMessage(conversationId: string, senderId: string, dto: SendMessageDto) {
    const conversation = await this.conversations.loadAggregate(conversationId);

    const isRateLimited = await this.isRateLimited(senderId);
    const check = CanSendMessageSpecification.evaluate(
      conversation,
      senderId,
      isRateLimited,
    );
    if (!check.allowed) {
      throw new ForbiddenException({
        message: `Cannot send message: ${check.reason}`,
        errorCode: `send_blocked_${check.reason}`,
      });
    }

    if (!dto.content && !dto.mediaId) {
      throw new BadRequestException({
        message: 'Message must include content or mediaId',
        errorCode: 'empty_message',
      });
    }

    let message;
    try {
      message = await this.prisma.message.create({
        data: {
          conversationId,
          senderId,
          clientMessageId: dto.clientMessageId,
          contentType: dto.contentType,
          contentPlain: dto.content,
          mediaId: dto.mediaId,
          replyToId: dto.replyToId,
        },
      });
    } catch (err) {
      // Unique constraint on (conversationId, clientMessageId) — the client
      // retried a send we already processed. Idempotent: return the
      // existing message rather than erroring, per Volume 2 Sec 4.
      const existing = await this.prisma.message.findUnique({
        where: {
          conversationId_clientMessageId: {
            conversationId,
            clientMessageId: dto.clientMessageId,
          },
        },
      });
      if (existing) return existing;
      throw new ConflictException({
        message: 'Failed to create message',
        errorCode: 'message_create_conflict',
      });
    }

    await this.kafkaProducer.publish('messaging.message.sent', {
      eventType: 'messaging.message.sent',
      key: conversationId, // partition key = conversationId -> per-conversation ordering (Vol.2 Sec.4)
      schemaVersion: 2, // v2: added recipientUserIds — additive, backward compatible (Vol.2 Sec.2's versioning rule)
      payload: {
        messageId: message.id,
        conversationId,
        senderId,
        contentType: message.contentType,
        createdAt: message.createdAt.toISOString(),
        // Denormalized at publish time so consumers (e.g. Notification
        // Service, Milestone 8) don't need a synchronous callback to
        // Messaging just to know who to notify — the alternative
        // (consumer calls back to fetch participants) adds a runtime
        // dependency for every event processed; this trades a slightly
        // larger event for removing that dependency entirely.
        recipientUserIds: conversation
          .activeParticipants()
          .map((p) => p.userId)
          .filter((id) => id !== senderId),
      },
    });

    return message;
  }

  async editMessage(messageId: string, requesterId: string, dto: EditMessageDto) {
    const message = await this.getMessageOrThrow(messageId);

    if (message.senderId !== requesterId) {
      throw new ForbiddenException({
        message: 'Only the sender can edit this message',
        errorCode: 'not_sender',
      });
    }
    if (Date.now() - message.createdAt.getTime() > this.editWindowMs) {
      throw new ForbiddenException({
        message: 'Edit window has expired',
        errorCode: 'edit_window_expired',
      });
    }

    const updated = await this.prisma.message.update({
      where: { id: messageId },
      data: { contentPlain: dto.content, editedAt: new Date() },
    });

    await this.kafkaProducer.publish('messaging.message.edited', {
      eventType: 'messaging.message.edited',
      key: message.conversationId,
      schemaVersion: 1,
      payload: { messageId, editedAt: updated.editedAt!.toISOString() },
    });

    return updated;
  }

  async deleteMessage(
    messageId: string,
    requesterId: string,
    isModeratorOrAbove: boolean,
  ) {
    const message = await this.getMessageOrThrow(messageId);

    if (message.senderId !== requesterId && !isModeratorOrAbove) {
      throw new ForbiddenException({
        message: 'Not authorized to delete this message',
        errorCode: 'not_authorized',
      });
    }

    await this.prisma.message.update({
      where: { id: messageId },
      data: { deletedAt: new Date() },
    });

    await this.kafkaProducer.publish('messaging.message.deleted', {
      eventType: 'messaging.message.deleted',
      key: message.conversationId,
      schemaVersion: 1,
      payload: { messageId, deletedBy: requesterId },
    });
  }

  async recordReceipt(messageId: string, userId: string, status: ReceiptStatusDto) {
    const message = await this.getMessageOrThrow(messageId);

    await this.prisma.messageReceipt.upsert({
      where: { messageId_userId_status: { messageId, userId, status } },
      create: { messageId, userId, status },
      update: { occurredAt: new Date() },
    });

    await this.kafkaProducer.publish(
      status === 'read' ? 'messaging.message.read' : 'messaging.message.delivered',
      {
        eventType:
          status === 'read' ? 'messaging.message.read' : 'messaging.message.delivered',
        key: message.conversationId,
        schemaVersion: 1,
        payload: { messageId, userId, occurredAt: new Date().toISOString() },
      },
    );
  }

  /**
   * Cursor-paginated history — never offset-based on this table, per
   * architecture-phase1-vol2.md Section 3.1's explicit ban on offset
   * pagination for the partitioned `messages` table.
   */
  async getHistory(
    conversationId: string,
    requesterId: string,
    cursor?: string,
    limit = 50,
  ) {
    const conversation = await this.conversations.loadAggregate(conversationId);
    if (!conversation.isMember(requesterId)) {
      throw new ForbiddenException({
        message: 'Not a participant in this conversation',
        errorCode: 'not_a_member',
      });
    }

    const items = await this.prisma.message.findMany({
      where: { conversationId, deletedAt: null },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      take: limit + 1,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    });

    const hasMore = items.length > limit;
    const page = hasMore ? items.slice(0, limit) : items;

    return {
      items: page,
      nextCursor: hasMore ? page[page.length - 1].id : null,
    };
  }

  private async getMessageOrThrow(messageId: string) {
    const message = await this.prisma.message.findUnique({ where: { id: messageId } });
    if (!message || message.deletedAt) {
      throw new NotFoundException({
        message: 'Message not found',
        errorCode: 'message_not_found',
      });
    }
    return message;
  }

  private async isRateLimited(userId: string): Promise<boolean> {
    const key = `ratelimit:send:${userId}:${Math.floor(Date.now() / 60_000)}`;
    const count = await this.redis.client.incr(key);
    if (count === 1) {
      await this.redis.client.expire(key, 60);
    }
    return count > SEND_RATE_LIMIT_PER_MINUTE;
  }
}
