import { Injectable, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { Conversation } from '../domain/conversation.aggregate';
import { CreateConversationDto } from './dto/create-conversation.dto';

/**
 * Application Service — orchestrates: build/validate the Conversation
 * aggregate (domain rules), persist, publish event. No business rules live
 * here (Volume 1 Sec 5.3) — the participant-count invariant, for example,
 * is enforced inside Conversation.create(), not here.
 */
@Injectable()
export class ConversationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly kafkaProducer: KafkaProducerService,
  ) {}

  async create(creatorId: string, dto: CreateConversationDto) {
    const participantIds = Array.from(new Set([creatorId, ...dto.participantIds]));

    // Domain validation happens before any I/O — a DirectConversationParticipantCountError
    // thrown here never touches the database, per the Domain/Application boundary.
    Conversation.create(
      randomUUID(),
      dto.type,
      participantIds.map((userId) => ({
        userId,
        role: userId === creatorId ? 'owner' : 'member',
        mutedUntil: null,
        leftAt: null,
      })),
    );

    const created = await this.prisma.conversation.create({
      data: {
        type: dto.type,
        cellId: 0, // MVP posture: single cell (architecture-phase1-mvp-addendum.md)
        participants: {
          create: participantIds.map((userId) => ({
            userId,
            role: userId === creatorId ? 'owner' : 'member',
          })),
        },
      },
      include: { participants: true },
    });

    await this.kafkaProducer.publish('messaging.conversation.created', {
      eventType: 'messaging.conversation.created',
      key: created.id,
      schemaVersion: 1,
      payload: {
        conversationId: created.id,
        type: created.type,
        participantIds,
      },
    });

    return created;
  }

  async loadAggregate(conversationId: string): Promise<Conversation> {
    const record = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      include: { participants: true },
    });
    if (!record) {
      throw new NotFoundException({
        message: 'Conversation not found',
        errorCode: 'conversation_not_found',
      });
    }
    return Conversation.reconstitute(
      record.id,
      record.type,
      record.participants.map(
        (p: {
          userId: string;
          role: 'member' | 'moderator' | 'owner';
          mutedUntil: Date | null;
          leftAt: Date | null;
        }) => ({
          userId: p.userId,
          role: p.role,
          mutedUntil: p.mutedUntil,
          leftAt: p.leftAt,
        }),
      ),
    );
  }

  /**
   * Lists conversations the user is an active (non-left) participant in,
   * most-recently-created first. Added during Milestone 5 (web client)
   * wiring — Milestone 2 shipped create + fetch-by-id but never a list
   * endpoint, which is a real gap for any client to have hit, not a
   * deferred feature. Ordered by conversation creation for now; ordering
   * by most-recent-message would need a denormalized `last_message_at`
   * column on `conversations` to avoid an expensive join per row at
   * scale — noted as a follow-up rather than done here.
   */
  async listForUser(userId: string) {
    return this.prisma.conversation.findMany({
      where: {
        participants: {
          some: { userId, leftAt: null },
        },
      },
      include: { participants: true },
      orderBy: { createdAt: 'desc' },
    });
  }
}
