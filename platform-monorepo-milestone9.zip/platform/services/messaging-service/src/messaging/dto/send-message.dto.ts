import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export enum ContentTypeDto {
  text = 'text',
  image = 'image',
  video = 'video',
  audio = 'audio',
  file = 'file',
}

export class SendMessageDto {
  @ApiProperty({
    description: 'Client-generated UUID for idempotent send (Volume 2 Sec 4)',
  })
  @IsUUID()
  clientMessageId!: string;

  @ApiProperty({ enum: ContentTypeDto })
  @IsEnum(ContentTypeDto)
  contentType!: ContentTypeDto;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @MaxLength(8000)
  content?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsUUID()
  mediaId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsUUID()
  replyToId?: string;
}
