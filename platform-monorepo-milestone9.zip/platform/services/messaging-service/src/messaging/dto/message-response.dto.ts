import { ApiProperty } from '@nestjs/swagger';

export class MessageResponseDto {
  @ApiProperty() id!: string;
  @ApiProperty() conversationId!: string;
  @ApiProperty() senderId!: string;
  @ApiProperty() contentType!: string;
  @ApiProperty({ required: false }) content?: string;
  @ApiProperty({ required: false }) mediaId?: string;
  @ApiProperty({ required: false }) replyToId?: string;
  @ApiProperty() createdAt!: string;
  @ApiProperty({ required: false }) editedAt?: string;
}

export class PaginatedMessagesResponseDto {
  @ApiProperty({ type: [MessageResponseDto] })
  items!: MessageResponseDto[];

  @ApiProperty({ nullable: true })
  nextCursor!: string | null;
}
