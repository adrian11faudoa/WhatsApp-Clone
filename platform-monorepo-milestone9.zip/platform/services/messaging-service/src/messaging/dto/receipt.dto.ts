import { ApiProperty } from '@nestjs/swagger';
import { IsEnum } from 'class-validator';

export enum ReceiptStatusDto {
  delivered = 'delivered',
  read = 'read',
}

export class ReceiptDto {
  @ApiProperty({ enum: ReceiptStatusDto })
  @IsEnum(ReceiptStatusDto)
  status!: ReceiptStatusDto;
}
