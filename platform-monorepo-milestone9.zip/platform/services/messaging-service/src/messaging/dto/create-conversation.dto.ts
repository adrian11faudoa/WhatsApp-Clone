import { ApiProperty } from '@nestjs/swagger';
import { ArrayMinSize, IsArray, IsEnum, IsUUID } from 'class-validator';

export enum ConversationTypeDto {
  direct = 'direct',
  group = 'group',
}

export class CreateConversationDto {
  @ApiProperty({ enum: ConversationTypeDto })
  @IsEnum(ConversationTypeDto)
  type!: ConversationTypeDto;

  @ApiProperty({ type: [String] })
  @IsArray()
  @ArrayMinSize(1)
  @IsUUID('4', { each: true })
  participantIds!: string[];
}
