import { Body, Controller, Get, Post } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAccessPayload } from '../auth/strategies/jwt.strategy';
import { ConversationsService } from './conversations.service';
import { CreateConversationDto } from './dto/create-conversation.dto';

@ApiTags('conversations')
@Controller('api/v1/conversations')
export class ConversationsController {
  constructor(private readonly conversationsService: ConversationsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a direct or group conversation' })
  async create(
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: CreateConversationDto,
  ) {
    return this.conversationsService.create(user.sub, dto);
  }

  @Get()
  @ApiOperation({
    summary: "List the current user's active conversations, most recent first",
  })
  async list(@CurrentUser() user: JwtAccessPayload) {
    return this.conversationsService.listForUser(user.sub);
  }
}
