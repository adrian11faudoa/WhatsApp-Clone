import { Logger, UsePipes, ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { readFileSync } from 'fs';

import { MessagingService } from './messaging.service';
import { RedisService } from '../infrastructure/redis/redis.service';
import { SendMessageDto } from './dto/send-message.dto';

interface AuthenticatedSocket extends Socket {
  data: { userId: string; sessionId: string };
}

/**
 * Socket.IO namespace /messaging, per architecture-phase1-vol2.md Section
 * 3.2's WS Gateway event contract. Handles the low-latency send path and
 * typing indicators (typing indicators are explicitly NOT published to
 * Kafka — see Volume 2 Section 2.3 — they're too high-frequency/ephemeral
 * for the durable event log, so they're routed directly here, room-scoped
 * to the conversation).
 *
 * Redis-backed Socket.IO adapter for horizontal scaling (multiple gateway
 * pods sharing room state) is wired at bootstrap in main.ts, not in this
 * file — this class is adapter-agnostic.
 */
@WebSocketGateway({ namespace: '/messaging', cors: { origin: true, credentials: true } })
export class MessagingGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(MessagingGateway.name);
  private readonly jwtPublicKey: string;

  constructor(
    private readonly messagingService: MessagingService,
    private readonly redis: RedisService,
    private readonly jwtService: JwtService,
    configService: ConfigService,
  ) {
    this.jwtPublicKey = readFileSync(
      configService.get<string>('jwt.publicKeyPath')!,
      'utf-8',
    );
  }

  async handleConnection(socket: AuthenticatedSocket): Promise<void> {
    const token = this.extractToken(socket);
    if (!token) {
      socket.disconnect(true);
      return;
    }

    try {
      const payload = this.jwtService.verify<{ sub: string; sessionId: string }>(token, {
        publicKey: this.jwtPublicKey,
        algorithms: ['RS256'],
      });
      socket.data.userId = payload.sub;
      socket.data.sessionId = payload.sessionId;

      await this.redis.client.sadd(`presence:${payload.sub}:sessions`, socket.id);
      this.logger.log(`Socket connected: user=${payload.sub} socket=${socket.id}`);
    } catch (err) {
      this.logger.warn(`WS auth failed: ${(err as Error).message}`);
      socket.disconnect(true);
    }
  }

  async handleDisconnect(socket: AuthenticatedSocket): Promise<void> {
    if (socket.data?.userId) {
      await this.redis.client.srem(`presence:${socket.data.userId}:sessions`, socket.id);
    }
  }

  @SubscribeMessage('conversation:join')
  async onJoin(
    @ConnectedSocket() socket: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string },
  ): Promise<void> {
    // Room membership is not itself an authorization check — the underlying
    // send/history use cases re-verify membership via CanSendMessageSpecification
    // and Conversation.isMember(). This join is purely a fan-out optimization.
    await socket.join(this.roomName(data.conversationId));
  }

  @SubscribeMessage('message:send')
  @UsePipes(new ValidationPipe({ whitelist: true, transform: true }))
  async onSendMessage(
    @ConnectedSocket() socket: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string } & SendMessageDto,
  ): Promise<void> {
    const idempotencyRedisKey = `ws-idem:${socket.data.userId}:${data.clientMessageId}`;
    const isFirstAttempt = await this.redis.claimIdempotencyKey(idempotencyRedisKey, 120);
    if (!isFirstAttempt) {
      this.logger.debug(`Duplicate WS send suppressed: ${data.clientMessageId}`);
      return;
    }

    const message = await this.messagingService.sendMessage(
      data.conversationId,
      socket.data.userId,
      data,
    );

    this.server.to(this.roomName(data.conversationId)).emit('message:new', {
      id: message.id,
      conversationId: message.conversationId,
      senderId: message.senderId,
      contentType: message.contentType,
      content: message.contentPlain,
      createdAt: message.createdAt.toISOString(),
    });
  }

  @SubscribeMessage('typing:start')
  onTypingStart(
    @ConnectedSocket() socket: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string },
  ): void {
    socket.to(this.roomName(data.conversationId)).emit('typing:update', {
      conversationId: data.conversationId,
      userId: socket.data.userId,
      isTyping: true,
    });
  }

  @SubscribeMessage('typing:stop')
  onTypingStop(
    @ConnectedSocket() socket: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string },
  ): void {
    socket.to(this.roomName(data.conversationId)).emit('typing:update', {
      conversationId: data.conversationId,
      userId: socket.data.userId,
      isTyping: false,
    });
  }

  private roomName(conversationId: string): string {
    return `conversation:${conversationId}`;
  }

  private extractToken(socket: Socket): string | null {
    const authHeader = socket.handshake.auth?.token as string | undefined;
    if (authHeader) return authHeader;
    const headerToken = socket.handshake.headers.authorization?.replace('Bearer ', '');
    return headerToken ?? null;
  }
}
