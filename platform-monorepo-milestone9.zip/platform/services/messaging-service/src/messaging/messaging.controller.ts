import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { Headers } from '@nestjs/common';

import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAccessPayload } from '../auth/strategies/jwt.strategy';
import { MessagingService } from './messaging.service';
import { SendMessageDto } from './dto/send-message.dto';
import { EditMessageDto } from './dto/edit-message.dto';
import { ReceiptDto } from './dto/receipt.dto';
import { PaginatedMessagesResponseDto } from './dto/message-response.dto';

/**
 * Endpoint shapes match architecture-phase1-vol2.md Section 3.2 exactly —
 * this is the REST mirror of the low-latency WS "message:send" path in
 * messaging.gateway.ts; both call into the same MessagingService so there
 * is exactly one implementation of the send/edit/delete/receipt use cases.
 */
@ApiTags('messages')
@Controller('api/v1')
export class MessagingController {
  constructor(private readonly messagingService: MessagingService) {}

  @Post('conversations/:conversationId/messages')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    summary: 'Send a message (Idempotency-Key / clientMessageId enforced)',
  })
  async send(
    @Param('conversationId') conversationId: string,
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: SendMessageDto,
    @Headers('idempotency-key') _idempotencyKey?: string,
  ) {
    return this.messagingService.sendMessage(conversationId, user.sub, dto);
  }

  @Get('conversations/:conversationId/messages')
  @ApiOperation({ summary: 'Cursor-paginated message history' })
  async history(
    @Param('conversationId') conversationId: string,
    @CurrentUser() user: JwtAccessPayload,
    @Query('cursor') cursor?: string,
    @Query('limit') limit?: string,
  ): Promise<PaginatedMessagesResponseDto> {
    const result = await this.messagingService.getHistory(
      conversationId,
      user.sub,
      cursor,
      limit ? Math.min(parseInt(limit, 10), 100) : 50,
    );
    return {
      items: result.items.map(
        (m: {
          id: string;
          conversationId: string;
          senderId: string;
          contentType: string;
          contentPlain: string | null;
          mediaId: string | null;
          replyToId: string | null;
          createdAt: Date;
          editedAt: Date | null;
        }) => ({
          id: m.id,
          conversationId: m.conversationId,
          senderId: m.senderId,
          contentType: m.contentType,
          content: m.contentPlain ?? undefined,
          mediaId: m.mediaId ?? undefined,
          replyToId: m.replyToId ?? undefined,
          createdAt: m.createdAt.toISOString(),
          editedAt: m.editedAt?.toISOString(),
        }),
      ),
      nextCursor: result.nextCursor,
    };
  }

  @Patch('messages/:messageId')
  @ApiOperation({ summary: 'Edit own message within the edit window' })
  async edit(
    @Param('messageId') messageId: string,
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: EditMessageDto,
  ) {
    return this.messagingService.editMessage(messageId, user.sub, dto);
  }

  @Delete('messages/:messageId')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete own message, or any message if moderator+' })
  async remove(
    @Param('messageId') messageId: string,
    @CurrentUser() user: JwtAccessPayload,
  ) {
    // isModeratorOrAbove: MVP milestone has no RBAC/policy-engine integration
    // yet (Volume 1 Sec 4.1's Authorization Service is a separate deployable,
    // not yet built) — defaults to false, meaning only the sender can delete
    // in this milestone. Flagging explicitly rather than silently stubbing
    // moderator permission as always-true, which would be a security bug.
    await this.messagingService.deleteMessage(messageId, user.sub, false);
  }

  @Post('messages/:messageId/receipts')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Record a delivered/read receipt' })
  async receipt(
    @Param('messageId') messageId: string,
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: ReceiptDto,
  ) {
    await this.messagingService.recordReceipt(messageId, user.sub, dto.status);
  }
}
