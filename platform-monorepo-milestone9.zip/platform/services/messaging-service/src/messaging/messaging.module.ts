import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';

import { MessagingController } from './messaging.controller';
import { ConversationsController } from './conversations.controller';
import { MessagingService } from './messaging.service';
import { ConversationsService } from './conversations.service';
import { MessagingGateway } from './messaging.gateway';

@Module({
  imports: [JwtModule.register({})],
  controllers: [MessagingController, ConversationsController],
  providers: [MessagingService, ConversationsService, MessagingGateway],
})
export class MessagingModule {}
