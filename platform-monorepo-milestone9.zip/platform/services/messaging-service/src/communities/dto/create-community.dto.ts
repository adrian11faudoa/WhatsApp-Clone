import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsString, MaxLength, MinLength } from 'class-validator';

export enum CommunityVisibilityDto {
  public = 'public',
  private = 'private',
}

export class CreateCommunityDto {
  @ApiProperty()
  @IsString()
  @MinLength(1)
  @MaxLength(100)
  name!: string;

  @ApiProperty({ enum: CommunityVisibilityDto, default: CommunityVisibilityDto.private })
  @IsEnum(CommunityVisibilityDto)
  visibility!: CommunityVisibilityDto;
}
