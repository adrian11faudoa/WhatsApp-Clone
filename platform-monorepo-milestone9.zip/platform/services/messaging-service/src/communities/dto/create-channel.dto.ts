import { ApiProperty } from '@nestjs/swagger';
import { IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class CreateChannelDto {
  @ApiProperty()
  @IsString()
  @MinLength(1)
  @MaxLength(100)
  name!: string;

  @ApiProperty({ enum: ['text', 'announcement'], required: false, default: 'text' })
  @IsOptional()
  @IsIn(['text', 'announcement'])
  type?: 'text' | 'announcement';
}
