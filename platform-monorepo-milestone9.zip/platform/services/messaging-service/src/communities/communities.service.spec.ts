import { Test, TestingModule } from '@nestjs/testing';
import { ForbiddenException } from '@nestjs/common';
import { CommunitiesService } from './communities.service';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { CommunityVisibilityDto } from './dto/create-community.dto';

describe('CommunitiesService', () => {
  let service: CommunitiesService;
  let prisma: {
    community: { create: jest.Mock; findMany: jest.Mock; findUnique: jest.Mock };
    communityMember: { create: jest.Mock; findUnique: jest.Mock; findMany: jest.Mock };
    channel: { create: jest.Mock; findMany: jest.Mock };
  };
  let kafkaProducer: { publish: jest.Mock };

  beforeEach(async () => {
    prisma = {
      community: { create: jest.fn(), findMany: jest.fn(), findUnique: jest.fn() },
      communityMember: { create: jest.fn(), findUnique: jest.fn(), findMany: jest.fn() },
      channel: { create: jest.fn(), findMany: jest.fn() },
    };
    kafkaProducer = { publish: jest.fn().mockResolvedValue(undefined) };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CommunitiesService,
        { provide: PrismaService, useValue: prisma },
        { provide: KafkaProducerService, useValue: kafkaProducer },
      ],
    }).compile();

    service = module.get<CommunitiesService>(CommunitiesService);
  });

  describe('create', () => {
    it('creates a community with the creator as owner and publishes an event', async () => {
      prisma.community.create.mockResolvedValue({
        id: 'community-1',
        visibility: 'private',
        members: [{ userId: 'user-1', role: 'owner' }],
      });

      const result = await service.create('user-1', {
        name: 'Test Community',
        visibility: CommunityVisibilityDto.private,
      });

      expect(result.id).toBe('community-1');
      expect(prisma.community.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            ownerId: 'user-1',
            members: { create: { userId: 'user-1', role: 'owner' } },
          }),
        }),
      );
      expect(kafkaProducer.publish).toHaveBeenCalledWith(
        'groups.community.created',
        expect.objectContaining({ eventType: 'groups.community.created' }),
      );
    });
  });

  describe('join', () => {
    it('rejects joining a private community when not already a member', async () => {
      prisma.community.findUnique.mockResolvedValue({
        id: 'community-1',
        visibility: 'private',
      });
      prisma.communityMember.findUnique.mockResolvedValue(null);

      await expect(service.join('community-1', 'user-2')).rejects.toThrow(
        ForbiddenException,
      );
      expect(prisma.communityMember.create).not.toHaveBeenCalled();
    });

    it('allows joining a public community when not already a member', async () => {
      prisma.community.findUnique.mockResolvedValue({
        id: 'community-1',
        visibility: 'public',
      });
      prisma.communityMember.findUnique.mockResolvedValue(null);
      prisma.communityMember.create.mockResolvedValue({
        communityId: 'community-1',
        userId: 'user-2',
        role: 'member',
      });

      const result = await service.join('community-1', 'user-2');

      expect(result.role).toBe('member');
      expect(kafkaProducer.publish).toHaveBeenCalledWith(
        'groups.community.member_joined',
        expect.objectContaining({ eventType: 'groups.community.member_joined' }),
      );
    });
  });

  describe('createChannel', () => {
    it('rejects channel creation from a plain member', async () => {
      prisma.community.findUnique.mockResolvedValue({
        id: 'community-1',
        visibility: 'public',
      });
      prisma.communityMember.findUnique.mockResolvedValue({ role: 'member' });

      await expect(
        service.createChannel('community-1', 'user-2', { name: 'general' }),
      ).rejects.toThrow(ForbiddenException);
      expect(prisma.channel.create).not.toHaveBeenCalled();
    });

    it('rejects channel creation from a non-member', async () => {
      prisma.community.findUnique.mockResolvedValue({
        id: 'community-1',
        visibility: 'public',
      });
      prisma.communityMember.findUnique.mockResolvedValue(null);

      await expect(
        service.createChannel('community-1', 'stranger', { name: 'general' }),
      ).rejects.toThrow(ForbiddenException);
    });

    it('allows channel creation from an owner and publishes an event', async () => {
      prisma.community.findUnique.mockResolvedValue({
        id: 'community-1',
        visibility: 'public',
      });
      prisma.communityMember.findUnique.mockResolvedValue({ role: 'owner' });
      prisma.communityMember.findMany.mockResolvedValue([{ userId: 'user-1' }]);
      prisma.channel.create.mockResolvedValue({
        id: 'channel-1',
        communityId: 'community-1',
        conversationId: 'conversation-1',
      });

      const result = await service.createChannel('community-1', 'user-1', {
        name: 'general',
      });

      expect(result.id).toBe('channel-1');
      expect(kafkaProducer.publish).toHaveBeenCalledWith(
        'messaging.channel.created',
        expect.objectContaining({ eventType: 'messaging.channel.created' }),
      );
    });
  });
});
