import {
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import {
  CommunityMembershipPolicy,
  CommunityRole,
} from '../domain/community-membership.policy';
import { CreateCommunityDto } from './dto/create-community.dto';
import { CreateChannelDto } from './dto/create-channel.dto';

/**
 * Application Service for Communities + Channels (Milestone 7). No
 * business rules here — CommunityMembershipPolicy owns the join/
 * channel-creation authorization decisions (Volume 1 Sec 5.3).
 */
@Injectable()
export class CommunitiesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly kafkaProducer: KafkaProducerService,
  ) {}

  async create(creatorId: string, dto: CreateCommunityDto) {
    const community = await this.prisma.community.create({
      data: {
        name: dto.name,
        ownerId: creatorId,
        visibility: dto.visibility,
        members: { create: { userId: creatorId, role: 'owner' } },
      },
      include: { members: true },
    });

    await this.kafkaProducer.publish('groups.community.created', {
      eventType: 'groups.community.created',
      key: community.id,
      schemaVersion: 1,
      payload: {
        communityId: community.id,
        ownerId: creatorId,
        visibility: community.visibility,
      },
    });

    return community;
  }

  async listForUser(userId: string) {
    return this.prisma.community.findMany({
      where: { members: { some: { userId } } },
      include: { members: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async join(communityId: string, userId: string) {
    const community = await this.getCommunityOrThrow(communityId);
    const existingMembership = await this.getMembership(communityId, userId);

    const check = CommunityMembershipPolicy.canJoin(
      community.visibility as 'public' | 'private',
      existingMembership,
    );
    if (!check.allowed) {
      throw new ForbiddenException({
        message: `Cannot join community: ${check.reason}`,
        errorCode: `join_blocked_${check.reason}`,
      });
    }

    const membership = await this.prisma.communityMember.create({
      data: { communityId, userId, role: 'member' },
    });

    await this.kafkaProducer.publish('groups.community.member_joined', {
      eventType: 'groups.community.member_joined',
      key: communityId,
      schemaVersion: 1,
      payload: { communityId, userId },
    });

    return membership;
  }

  async createChannel(communityId: string, creatorId: string, dto: CreateChannelDto) {
    await this.getCommunityOrThrow(communityId);
    const membership = await this.getMembership(communityId, creatorId);

    const check = CommunityMembershipPolicy.canCreateChannel(membership);
    if (!check.allowed) {
      throw new ForbiddenException({
        message: `Cannot create channel: ${check.reason}`,
        errorCode: `channel_create_blocked_${check.reason}`,
      });
    }

    try {
      // Every channel is backed by exactly one conversation (Volume 1
      // Sec 5.2's composition pattern: Channel wraps a Conversation
      // rather than reimplementing message storage). Community members
      // become conversation participants at channel-creation time; a
      // member who joins the community LATER is not automatically added
      // to every existing channel's conversation — that reconciliation
      // is not built in this milestone, flagged in the README rather
      // than silently assumed.
      const memberIds = (
        await this.prisma.communityMember.findMany({
          where: { communityId },
          select: { userId: true },
        })
      ).map((m: { userId: string }) => m.userId);

      const channel = await this.prisma.channel.create({
        data: {
          communityId,
          name: dto.name,
          type: dto.type ?? 'text',
          conversation: {
            create: {
              type: 'channel',
              communityId,
              participants: {
                create: memberIds.map((userId: string) => ({ userId, role: 'member' })),
              },
            },
          },
        },
        include: { conversation: true },
      });

      await this.kafkaProducer.publish('messaging.channel.created', {
        eventType: 'messaging.channel.created',
        key: communityId,
        schemaVersion: 1,
        payload: {
          channelId: channel.id,
          communityId,
          conversationId: channel.conversationId,
        },
      });

      return channel;
    } catch (err) {
      throw new ConflictException({
        message: 'A channel with this name already exists in this community',
        errorCode: 'channel_name_conflict',
      });
    }
  }

  async listChannels(communityId: string, requesterId: string) {
    await this.getCommunityOrThrow(communityId);
    const membership = await this.getMembership(communityId, requesterId);
    if (!membership) {
      throw new ForbiddenException({
        message: 'Not a member of this community',
        errorCode: 'not_a_member',
      });
    }
    return this.prisma.channel.findMany({
      where: { communityId },
      orderBy: { position: 'asc' },
    });
  }

  private async getCommunityOrThrow(communityId: string) {
    const community = await this.prisma.community.findUnique({
      where: { id: communityId },
    });
    if (!community) {
      throw new NotFoundException({
        message: 'Community not found',
        errorCode: 'community_not_found',
      });
    }
    return community;
  }

  private async getMembership(
    communityId: string,
    userId: string,
  ): Promise<{ role: CommunityRole } | null> {
    const membership = await this.prisma.communityMember.findUnique({
      where: { communityId_userId: { communityId, userId } },
    });
    return membership ? { role: membership.role as CommunityRole } : null;
  }
}
