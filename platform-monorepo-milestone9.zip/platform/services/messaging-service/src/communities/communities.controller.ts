import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAccessPayload } from '../auth/strategies/jwt.strategy';
import { CommunitiesService } from './communities.service';
import { CreateCommunityDto } from './dto/create-community.dto';
import { CreateChannelDto } from './dto/create-channel.dto';

@ApiTags('communities')
@Controller('api/v1/communities')
export class CommunitiesController {
  constructor(private readonly communitiesService: CommunitiesService) {}

  @Post()
  @ApiOperation({ summary: 'Create a community (creator becomes owner)' })
  async create(@CurrentUser() user: JwtAccessPayload, @Body() dto: CreateCommunityDto) {
    return this.communitiesService.create(user.sub, dto);
  }

  @Get()
  @ApiOperation({ summary: 'List communities the current user belongs to' })
  async list(@CurrentUser() user: JwtAccessPayload) {
    return this.communitiesService.listForUser(user.sub);
  }

  @Post(':communityId/join')
  @ApiOperation({
    summary:
      'Join a public community (private communities require an invite — not yet built)',
  })
  async join(
    @Param('communityId') communityId: string,
    @CurrentUser() user: JwtAccessPayload,
  ) {
    return this.communitiesService.join(communityId, user.sub);
  }

  @Post(':communityId/channels')
  @ApiOperation({ summary: 'Create a channel (requires moderator or owner role)' })
  async createChannel(
    @Param('communityId') communityId: string,
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: CreateChannelDto,
  ) {
    return this.communitiesService.createChannel(communityId, user.sub, dto);
  }

  @Get(':communityId/channels')
  @ApiOperation({ summary: 'List channels in a community (requires membership)' })
  async listChannels(
    @Param('communityId') communityId: string,
    @CurrentUser() user: JwtAccessPayload,
  ) {
    return this.communitiesService.listChannels(communityId, user.sub);
  }
}
