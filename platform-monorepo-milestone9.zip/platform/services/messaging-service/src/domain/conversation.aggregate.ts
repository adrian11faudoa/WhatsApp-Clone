/**
 * Conversation — Aggregate Root, per architecture-phase1-vol1.md Section 5.2.
 * Owns participant/permission invariants. Message is deliberately NOT nested
 * inside this aggregate (would make it unboundedly large) — Message is its
 * own aggregate root that merely references conversationId.
 *
 * Pure domain object: no Prisma import, no I/O. The Application layer
 * (ConversationsService) is responsible for loading/persisting this shape
 * and calling these methods to enforce invariants before writing.
 */

export type ConversationType = 'direct' | 'group' | 'channel';
export type ParticipantRole = 'member' | 'moderator' | 'owner';

export interface Participant {
  userId: string;
  role: ParticipantRole;
  mutedUntil: Date | null;
  leftAt: Date | null;
}

export class DirectConversationParticipantCountError extends Error {
  constructor() {
    super('Direct conversations must have exactly 2 participants');
    this.name = 'DirectConversationParticipantCountError';
  }
}

export class LastOwnerRemovalError extends Error {
  constructor() {
    super('Cannot remove the last owner of a group without transferring ownership first');
    this.name = 'LastOwnerRemovalError';
  }
}

export class Conversation {
  private constructor(
    public readonly id: string,
    public readonly type: ConversationType,
    private participants: Participant[],
  ) {}

  static create(
    id: string,
    type: ConversationType,
    participants: Participant[],
  ): Conversation {
    if (type === 'direct' && participants.length !== 2) {
      throw new DirectConversationParticipantCountError();
    }
    return new Conversation(id, type, participants);
  }

  static reconstitute(
    id: string,
    type: ConversationType,
    participants: Participant[],
  ): Conversation {
    // Same invariant checks apply when rehydrating from persistence —
    // a corrupted row should fail loudly, not silently propagate.
    return Conversation.create(id, type, participants);
  }

  activeParticipants(): Participant[] {
    return this.participants.filter((p) => p.leftAt === null);
  }

  isMember(userId: string): boolean {
    return this.activeParticipants().some((p) => p.userId === userId);
  }

  isMuted(userId: string, now: Date = new Date()): boolean {
    const participant = this.activeParticipants().find((p) => p.userId === userId);
    return !!participant?.mutedUntil && participant.mutedUntil.getTime() > now.getTime();
  }

  /**
   * Removing the last owner of a group/channel without an explicit
   * ownership transfer is disallowed — this is a domain invariant, not
   * an application-layer permission check, per Volume 1 Section 5.2.
   */
  removeParticipant(userId: string, now: Date = new Date()): void {
    const target = this.participants.find(
      (p) => p.userId === userId && p.leftAt === null,
    );
    if (!target) return;

    if (target.role === 'owner' && this.type !== 'direct') {
      const remainingOwners = this.activeParticipants().filter(
        (p) => p.role === 'owner' && p.userId !== userId,
      );
      if (remainingOwners.length === 0) {
        throw new LastOwnerRemovalError();
      }
    }

    target.leftAt = now;
  }

  addParticipant(userId: string, role: ParticipantRole = 'member'): void {
    if (this.type === 'direct') {
      throw new DirectConversationParticipantCountError();
    }
    this.participants.push({ userId, role, mutedUntil: null, leftAt: null });
  }
}
