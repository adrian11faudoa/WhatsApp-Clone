import { DeliveryPolicy } from './delivery-policy.service';

describe('DeliveryPolicy', () => {
  it('excludes the sender from delivery targets', () => {
    const plan = DeliveryPolicy.plan(
      [{ userId: 'sender', onlineSessionIds: ['s1'], blockedSender: false }],
      'sender',
    );
    expect(plan.onlineTargets).toHaveLength(0);
    expect(plan.offlineUserIds).toHaveLength(0);
  });

  it('excludes recipients who have blocked the sender', () => {
    const plan = DeliveryPolicy.plan(
      [{ userId: 'blocker', onlineSessionIds: ['s1'], blockedSender: true }],
      'sender',
    );
    expect(plan.onlineTargets).toHaveLength(0);
    expect(plan.offlineUserIds).toHaveLength(0);
  });

  it('routes a recipient with active sessions to onlineTargets', () => {
    const plan = DeliveryPolicy.plan(
      [{ userId: 'recipient', onlineSessionIds: ['s1', 's2'], blockedSender: false }],
      'sender',
    );
    expect(plan.onlineTargets).toEqual([
      { userId: 'recipient', onlineSessionIds: ['s1', 's2'] },
    ]);
    expect(plan.offlineUserIds).toHaveLength(0);
  });

  it('routes a recipient with no active sessions to offlineUserIds', () => {
    const plan = DeliveryPolicy.plan(
      [{ userId: 'recipient', onlineSessionIds: [], blockedSender: false }],
      'sender',
    );
    expect(plan.onlineTargets).toHaveLength(0);
    expect(plan.offlineUserIds).toEqual(['recipient']);
  });

  it('handles a mixed set of online, offline, blocked, and sender entries correctly', () => {
    const plan = DeliveryPolicy.plan(
      [
        { userId: 'sender', onlineSessionIds: ['s0'], blockedSender: false },
        { userId: 'online-friend', onlineSessionIds: ['s1'], blockedSender: false },
        { userId: 'offline-friend', onlineSessionIds: [], blockedSender: false },
        { userId: 'blocker', onlineSessionIds: ['s2'], blockedSender: true },
      ],
      'sender',
    );
    expect(plan.onlineTargets.map((t) => t.userId)).toEqual(['online-friend']);
    expect(plan.offlineUserIds).toEqual(['offline-friend']);
  });
});
