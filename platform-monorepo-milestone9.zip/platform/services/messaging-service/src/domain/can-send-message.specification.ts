import { Conversation } from './conversation.aggregate';

export type CanSendMessageFailureReason = 'not_a_member' | 'muted' | 'rate_limited';

export interface CanSendMessageResult {
  allowed: boolean;
  reason?: CanSendMessageFailureReason;
}

/**
 * Specification (DDD pattern): composes the conditions under which a user
 * may send a message into a single, independently-testable rule set — per
 * architecture-phase1-vol1.md Section 5.2. Used identically by both the
 * synchronous REST/WS guard (reject before write) and any async re-check
 * (e.g. a spam-detection re-evaluation), so the two enforcement points can
 * never drift out of sync with each other.
 *
 * Rate limiting itself is evaluated by the caller (it requires I/O — a
 * Redis counter — which this pure specification deliberately does not
 * perform) and passed in as `isRateLimited`.
 */
export class CanSendMessageSpecification {
  static evaluate(
    conversation: Conversation,
    userId: string,
    isRateLimited: boolean,
    now: Date = new Date(),
  ): CanSendMessageResult {
    if (!conversation.isMember(userId)) {
      return { allowed: false, reason: 'not_a_member' };
    }
    if (conversation.isMuted(userId, now)) {
      return { allowed: false, reason: 'muted' };
    }
    if (isRateLimited) {
      return { allowed: false, reason: 'rate_limited' };
    }
    return { allowed: true };
  }
}
