export interface DeliveryTarget {
  userId: string;
  onlineSessionIds: string[];
}

export interface DeliveryPlan {
  onlineTargets: DeliveryTarget[]; // push over WS now
  offlineUserIds: string[]; // enqueue + push-notify
}

/**
 * DeliveryPolicy — Domain Service, per architecture-phase1-vol1.md Section
 * 5.2: spans Conversation + Presence + Contacts/Blocks concerns, so it
 * doesn't naturally belong on a single entity. Pure function over data the
 * Application layer (MessagingService) has already loaded — this class
 * performs no I/O itself, which is what keeps it unit-testable without
 * mocking Presence/Redis.
 */
export class DeliveryPolicy {
  static plan(
    recipients: Array<{
      userId: string;
      onlineSessionIds: string[];
      blockedSender: boolean;
    }>,
    senderId: string,
  ): DeliveryPlan {
    const eligible = recipients.filter((r) => r.userId !== senderId && !r.blockedSender);

    const onlineTargets = eligible
      .filter((r) => r.onlineSessionIds.length > 0)
      .map((r) => ({ userId: r.userId, onlineSessionIds: r.onlineSessionIds }));

    const offlineUserIds = eligible
      .filter((r) => r.onlineSessionIds.length === 0)
      .map((r) => r.userId);

    return { onlineTargets, offlineUserIds };
  }
}
