export type CommunityRole = 'member' | 'moderator' | 'owner';
export type CommunityVisibility = 'public' | 'private';

export type ChannelCreationRejectionReason = 'not_a_member' | 'insufficient_role';
export type JoinRejectionReason = 'already_a_member' | 'community_is_private';

/**
 * Domain Service: community-scoped authorization rules. Pure — no
 * Prisma import — per architecture-phase1-vol1.md Section 5.3. Mirrors
 * the same pattern as CanSendMessageSpecification: one place these rules
 * live, so the controller-level guard and any future async re-check
 * (e.g. an admin audit tool) can't drift apart.
 */
export class CommunityMembershipPolicy {
  static canCreateChannel(membership: { role: CommunityRole } | null): {
    allowed: boolean;
    reason?: ChannelCreationRejectionReason;
  } {
    if (!membership) {
      return { allowed: false, reason: 'not_a_member' };
    }
    if (membership.role === 'member') {
      return { allowed: false, reason: 'insufficient_role' };
    }
    return { allowed: true };
  }

  static canJoin(
    visibility: CommunityVisibility,
    existingMembership: { role: CommunityRole } | null,
  ): { allowed: boolean; reason?: JoinRejectionReason } {
    if (existingMembership) {
      return { allowed: false, reason: 'already_a_member' };
    }
    if (visibility === 'private') {
      // Private communities require an explicit invite from an
      // owner/moderator — not implemented in this milestone (no invite
      // endpoint exists yet). Self-service join is correctly rejected
      // here rather than silently allowed, which would be a real access
      // control bug, not a missing feature.
      return { allowed: false, reason: 'community_is_private' };
    }
    return { allowed: true };
  }
}
