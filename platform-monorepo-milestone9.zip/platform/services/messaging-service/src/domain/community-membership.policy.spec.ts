import { CommunityMembershipPolicy } from './community-membership.policy';

describe('CommunityMembershipPolicy', () => {
  describe('canCreateChannel', () => {
    it('rejects a non-member', () => {
      const result = CommunityMembershipPolicy.canCreateChannel(null);
      expect(result).toEqual({ allowed: false, reason: 'not_a_member' });
    });

    it('rejects a plain member', () => {
      const result = CommunityMembershipPolicy.canCreateChannel({ role: 'member' });
      expect(result).toEqual({ allowed: false, reason: 'insufficient_role' });
    });

    it('allows a moderator', () => {
      const result = CommunityMembershipPolicy.canCreateChannel({ role: 'moderator' });
      expect(result).toEqual({ allowed: true });
    });

    it('allows an owner', () => {
      const result = CommunityMembershipPolicy.canCreateChannel({ role: 'owner' });
      expect(result).toEqual({ allowed: true });
    });
  });

  describe('canJoin', () => {
    it('allows joining a public community when not already a member', () => {
      const result = CommunityMembershipPolicy.canJoin('public', null);
      expect(result).toEqual({ allowed: true });
    });

    it('rejects joining a public community when already a member', () => {
      const result = CommunityMembershipPolicy.canJoin('public', { role: 'member' });
      expect(result).toEqual({ allowed: false, reason: 'already_a_member' });
    });

    it('rejects self-service join on a private community', () => {
      const result = CommunityMembershipPolicy.canJoin('private', null);
      expect(result).toEqual({ allowed: false, reason: 'community_is_private' });
    });

    it('checks existing membership before visibility (already-a-member takes precedence)', () => {
      const result = CommunityMembershipPolicy.canJoin('private', { role: 'owner' });
      expect(result.reason).toBe('already_a_member');
    });
  });
});
