import {
  Conversation,
  DirectConversationParticipantCountError,
  LastOwnerRemovalError,
} from './conversation.aggregate';

describe('Conversation aggregate', () => {
  describe('create', () => {
    it('allows a direct conversation with exactly 2 participants', () => {
      const conversation = Conversation.create('conv-1', 'direct', [
        { userId: 'u1', role: 'member', mutedUntil: null, leftAt: null },
        { userId: 'u2', role: 'member', mutedUntil: null, leftAt: null },
      ]);
      expect(conversation.activeParticipants()).toHaveLength(2);
    });

    it('rejects a direct conversation without exactly 2 participants', () => {
      expect(() =>
        Conversation.create('conv-1', 'direct', [
          { userId: 'u1', role: 'member', mutedUntil: null, leftAt: null },
        ]),
      ).toThrow(DirectConversationParticipantCountError);
    });

    it('allows a group conversation with any participant count >= 1', () => {
      const conversation = Conversation.create('conv-1', 'group', [
        { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
      ]);
      expect(conversation.activeParticipants()).toHaveLength(1);
    });
  });

  describe('isMember / isMuted', () => {
    const conversation = Conversation.create('conv-1', 'group', [
      { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
      {
        userId: 'u2',
        role: 'member',
        mutedUntil: new Date(Date.now() + 60_000),
        leftAt: null,
      },
    ]);

    it('returns true for an active member', () => {
      expect(conversation.isMember('u1')).toBe(true);
    });

    it('returns false for a non-member', () => {
      expect(conversation.isMember('stranger')).toBe(false);
    });

    it('returns true for a currently-muted member', () => {
      expect(conversation.isMuted('u2')).toBe(true);
    });

    it('returns false for an unmuted member', () => {
      expect(conversation.isMuted('u1')).toBe(false);
    });
  });

  describe('removeParticipant', () => {
    it('prevents removing the last owner of a group', () => {
      const conversation = Conversation.create('conv-1', 'group', [
        { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
        { userId: 'u2', role: 'member', mutedUntil: null, leftAt: null },
      ]);
      expect(() => conversation.removeParticipant('u1')).toThrow(LastOwnerRemovalError);
    });

    it('allows removing an owner when another owner remains', () => {
      const conversation = Conversation.create('conv-1', 'group', [
        { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
        { userId: 'u2', role: 'owner', mutedUntil: null, leftAt: null },
      ]);
      conversation.removeParticipant('u1');
      expect(conversation.isMember('u1')).toBe(false);
    });

    it('allows removing a regular member freely', () => {
      const conversation = Conversation.create('conv-1', 'group', [
        { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
        { userId: 'u2', role: 'member', mutedUntil: null, leftAt: null },
      ]);
      conversation.removeParticipant('u2');
      expect(conversation.isMember('u2')).toBe(false);
    });
  });

  describe('addParticipant', () => {
    it('rejects adding a participant to a direct conversation', () => {
      const conversation = Conversation.create('conv-1', 'direct', [
        { userId: 'u1', role: 'member', mutedUntil: null, leftAt: null },
        { userId: 'u2', role: 'member', mutedUntil: null, leftAt: null },
      ]);
      expect(() => conversation.addParticipant('u3')).toThrow(
        DirectConversationParticipantCountError,
      );
    });

    it('allows adding a participant to a group conversation', () => {
      const conversation = Conversation.create('conv-1', 'group', [
        { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
      ]);
      conversation.addParticipant('u2');
      expect(conversation.isMember('u2')).toBe(true);
    });
  });
});
