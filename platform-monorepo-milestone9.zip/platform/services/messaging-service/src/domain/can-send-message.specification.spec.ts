import { CanSendMessageSpecification } from './can-send-message.specification';
import { Conversation } from './conversation.aggregate';

describe('CanSendMessageSpecification', () => {
  const conversation = Conversation.create('conv-1', 'group', [
    { userId: 'u1', role: 'owner', mutedUntil: null, leftAt: null },
    {
      userId: 'u2',
      role: 'member',
      mutedUntil: new Date(Date.now() + 60_000),
      leftAt: null,
    },
  ]);

  it('allows a non-muted member who is not rate-limited', () => {
    const result = CanSendMessageSpecification.evaluate(conversation, 'u1', false);
    expect(result).toEqual({ allowed: true });
  });

  it('rejects a non-member', () => {
    const result = CanSendMessageSpecification.evaluate(conversation, 'stranger', false);
    expect(result).toEqual({ allowed: false, reason: 'not_a_member' });
  });

  it('rejects a muted member', () => {
    const result = CanSendMessageSpecification.evaluate(conversation, 'u2', false);
    expect(result).toEqual({ allowed: false, reason: 'muted' });
  });

  it('rejects a rate-limited member', () => {
    const result = CanSendMessageSpecification.evaluate(conversation, 'u1', true);
    expect(result).toEqual({ allowed: false, reason: 'rate_limited' });
  });

  it('checks membership before muted status', () => {
    // A non-member who happens to also not be muted should fail on membership, not muted.
    const result = CanSendMessageSpecification.evaluate(conversation, 'stranger', false);
    expect(result.reason).toBe('not_a_member');
  });
});
