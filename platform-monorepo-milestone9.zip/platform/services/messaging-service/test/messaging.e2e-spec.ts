import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';

/**
 * Real integration tests run against real Postgres/Redis/Kafka in CI
 * (see .github/workflows/ci.yml), per architecture-phase1-vol3.md Section
 * 6.2. This spec exercises the auth-gate and validation behavior that
 * doesn't require a pre-seeded conversation/user fixture — the full
 * "two authenticated sessions exchange a message in real time" scenario
 * belongs at the E2E (Playwright, Section 6.3) tier against staging, not here.
 */
describe('Messaging endpoints (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('POST /api/v1/conversations returns 401 without a token', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/v1/conversations')
      .send({ type: 'direct', participantIds: ['00000000-0000-4000-8000-000000000001'] });
    expect(response.status).toBe(401);
  });

  it('GET /api/v1/conversations returns 401 without a token', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/conversations');
    expect(response.status).toBe(401);
  });

  it('POST /api/v1/communities returns 401 without a token', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/v1/communities')
      .send({ name: 'Test Community', visibility: 'public' });
    expect(response.status).toBe(401);
  });

  it('GET /api/v1/conversations/:id/messages returns 401 without a token', async () => {
    const response = await request(app.getHttpServer()).get(
      '/api/v1/conversations/00000000-0000-4000-8000-000000000001/messages',
    );
    expect(response.status).toBe(401);
  });

  it('GET /health/live returns 200 without auth', async () => {
    const response = await request(app.getHttpServer()).get('/health/live');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ status: 'ok' });
  });
});
