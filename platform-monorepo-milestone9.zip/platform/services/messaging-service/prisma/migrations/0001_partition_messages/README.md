# Why this migration is hand-written

Prisma Migrate generates `schema.prisma`'s `Message` model as an ordinary
(non-partitioned) table. Postgres declarative partitioning at the scale
specified in `architecture-phase1-vol1.md` Section 6.2 (HASH by
`conversation_id`, 4096 partitions, monthly RANGE sub-partitions) is not
expressible in Prisma's schema language as of Prisma 5.x.

This migration runs immediately after Prisma's initial migration and
converts the plain table into the partitioned structure. Going forward,
schema changes to `Message` fields still go through normal `prisma migrate
dev` (Prisma diffs column changes fine); only the *initial* partitioning
structure needed to be hand-authored.

**Operational note for Milestone 2+:** monthly partition provisioning
(creating next month's RANGE partition inside each of the 4096 hash
buckets before it's needed) must run as a scheduled job — not included in
this milestone since it's an operational concern, not a schema concern.
Flagging it here so it isn't forgotten before this goes to a real production
cell.
