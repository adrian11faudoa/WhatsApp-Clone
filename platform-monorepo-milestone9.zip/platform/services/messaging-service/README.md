# Messaging Service

Owns the **Messaging, Conversation, Delivery, Receipts, Typing** bounded
context — Phase 2 Milestone 2, per `architecture-phase1-mvp-addendum.md`'s
build order (Identity+Auth → **Messaging** → Media → Presence).

## What this service does

- Direct + group conversations
- Communities and Channels (Milestone 7): create a community, join
  public communities, create channels (moderator/owner only), each
  channel backed by its own conversation — the same message send/
  receive/history/receipt endpoints work against a channel's
  `conversationId` with no changes needed
- Message send (REST + low-latency WS path, both idempotent on
  `clientMessageId`), edit (within a configurable window), soft-delete
- Delivery/read receipts, typing indicators (WS-only, never on Kafka —
  Volume 2 Section 2.3)
- Publishes `messaging.*` and `groups.*` domain events to Kafka for
  Search/Analytics/Notification/Delivery consumers (not all of which
  exist yet — this service doesn't need them to; it just needs to
  publish correctly)

## Architecture layering

Same discipline as `identity-service`:

```
src/domain/       # Conversation aggregate, CanSendMessageSpecification,
                   DeliveryPolicy — zero I/O, zero framework imports.
src/messaging/     # Application layer + HTTP/WS/DTO layer. No business rules —
                     see architecture-phase1-vol1.md Section 5.3's boundary rule.
src/infrastructure/# Prisma, Kafka, Redis adapters.
```

## A note on the `messages` table

`prisma/schema.prisma` defines the logical shape; the actual HASH+RANGE
partitioning (architecture-phase1-vol1.md Section 6.2 — 4096 partitions by
`conversation_id`, monthly sub-partitions) is **not expressible in Prisma's
schema language**, so it's a hand-written raw-SQL migration at
`prisma/migrations/0001_partition_messages/migration.sql`. Read that
migration's own README before touching the `Message` model — schema field
changes go through normal `prisma migrate dev`, but the partitioning
structure itself does not regenerate automatically.

## Local development

```bash
cp .env.example .env
# Reuse the Identity service's dev keypair so tokens issued by Identity
# verify here (Messaging never issues tokens, only verifies them — Volume 1 Sec 1):
mkdir -p keys && cp ../identity-service/keys/jwt-public.pem keys/
docker-compose up --build
npx prisma migrate dev   # applies schema.prisma, then the partition migration
```

HTTP + Swagger on `:3002` (`/api/docs`). WebSocket namespace `/messaging`
on the same port. Health checks at `/health/live`, `/health/ready`.

### Trying the WS path

```js
const socket = io('http://localhost:3002/messaging', { auth: { token: '<access token>' } });
socket.emit('conversation:join', { conversationId: '<id>' });
socket.emit('message:send', { conversationId: '<id>', clientMessageId: crypto.randomUUID(), contentType: 'text', content: 'hi' });
socket.on('message:new', console.log);
```

## Testing

```bash
npm test          # unit — domain layer (Conversation, CanSendMessageSpecification, DeliveryPolicy) runs with zero mocks
npm run test:cov
npm run test:e2e  # HTTP-level tests against a real Nest app instance
```

## What's deliberately NOT in this milestone

- Threads (Volume 2 Section 1.4's `threads` table) — channels ship first;
  threads are a natural follow-on since they're the same
  Channel-wraps-a-Conversation composition pattern applied one level
  deeper
- The general policy-engine `roles`/`role_bindings` tables — Milestone 7
  uses a simplified three-value `CommunityRole` enum
  (member/moderator/owner) directly on `community_members` instead. This
  covers what's actually enforced (channel creation needs
  moderator+); the full per-community-customizable role system from
  Volume 2 is a real feature gap, not implemented here
- Private-community invites — `POST /communities/:id/join` correctly
  *rejects* self-service joins to private communities (this is a
  deliberate access-control decision, not a missing happy path) but
  there's no invite-issuing endpoint yet, so a private community is
  currently only reachable by its creator until that's built
- Auto-adding new community members to existing channels' conversations
  — a member who joins after a channel already exists does not
  retroactively become a participant in that channel's conversation.
  Flagged in `CommunitiesService.createChannel`'s own comment
- Moderator-permission checks on message delete inside channels — the
  existing `isModeratorOrAbove: false` hardcode from Milestone 2 applies
  here too, since it isn't wired to `CommunityMember.role` yet

## Contract references

- Data model: `architecture-phase1-vol2.md` Section 1.3
- Events published: `architecture-phase1-vol2.md` Section 2.3
- API + WS conventions: `architecture-phase1-vol2.md` Section 3.2
- Delivery guarantee model: `architecture-phase1-vol2.md` Section 4
- Domain model (Conversation aggregate, DeliveryPolicy): `architecture-phase1-vol1.md` Section 5.2
