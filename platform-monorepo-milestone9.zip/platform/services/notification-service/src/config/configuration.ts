export interface AppConfig {
  nodeEnv: string;
  port: number;
  database: { url: string };
  jwt: { publicKeyPath: string };
  kafka: { brokers: string[]; clientId: string; consumerGroup: string };
  rateLimit: { ttlSeconds: number; max: number };
}

export default (): AppConfig => ({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: parseInt(process.env.PORT ?? '3005', 10),
  database: { url: process.env.DATABASE_URL ?? '' },
  jwt: { publicKeyPath: process.env.JWT_PUBLIC_KEY_PATH ?? './keys/jwt-public.pem' },
  kafka: {
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    clientId: process.env.KAFKA_CLIENT_ID ?? 'notification-service',
    consumerGroup: process.env.KAFKA_CONSUMER_GROUP ?? 'notification-service-group',
  },
  rateLimit: {
    ttlSeconds: parseInt(process.env.RATE_LIMIT_TTL_SECONDS ?? '60', 10),
    max: parseInt(process.env.RATE_LIMIT_MAX ?? '100', 10),
  },
});
