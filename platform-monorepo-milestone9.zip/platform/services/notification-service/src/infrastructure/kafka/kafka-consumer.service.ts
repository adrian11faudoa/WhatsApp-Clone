import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Consumer, EachMessagePayload, Kafka } from 'kafkajs';

export interface ConsumedEvent<T = Record<string, unknown>> {
  eventType: string;
  payload: T;
  schemaVersion: number;
}

export type EventHandler = (event: ConsumedEvent) => Promise<void>;

/** Same generic consumer pattern as presence-service's KafkaConsumerService. */
@Injectable()
export class KafkaConsumerService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(KafkaConsumerService.name);
  private readonly kafka: Kafka;
  private consumer: Consumer;
  private readonly handlers = new Map<string, EventHandler>();
  private readonly topics: string[] = [];

  constructor(private readonly configService: ConfigService) {
    this.kafka = new Kafka({
      clientId: this.configService.get<string>('kafka.clientId')!,
      brokers: this.configService.get<string[]>('kafka.brokers')!,
      retry: { retries: 8, initialRetryTime: 300 },
    });
    this.consumer = this.kafka.consumer({
      groupId: this.configService.get<string>('kafka.consumerGroup')!,
    });
  }

  registerHandler(topic: string, handler: EventHandler): void {
    this.handlers.set(topic, handler);
    this.topics.push(topic);
  }

  async onModuleInit(): Promise<void> {
    await this.consumer.connect();
    if (this.topics.length > 0) {
      await this.consumer.subscribe({ topics: this.topics, fromBeginning: false });
    }
    await this.consumer.run({
      eachMessage: async (payload: EachMessagePayload) => this.dispatch(payload),
    });
    this.logger.log(
      `Kafka consumer connected, subscribed to: ${this.topics.join(', ') || '(none)'}`,
    );
  }

  async onModuleDestroy(): Promise<void> {
    await this.consumer.disconnect();
  }

  private async dispatch(payload: EachMessagePayload): Promise<void> {
    const { topic, message } = payload;
    const handler = this.handlers.get(topic);
    if (!handler || !message.value) return;

    try {
      const event = JSON.parse(message.value.toString()) as ConsumedEvent;
      await handler(event);
    } catch (err) {
      this.logger.error(`Failed to process message on topic ${topic}`, err as Error);
    }
  }
}
