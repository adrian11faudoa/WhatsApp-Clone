import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

export interface PushPayload {
  title: string;
  body: string;
  data: Record<string, string>;
}

/**
 * UPDATED Milestone 9: the token-source gap flagged in Milestone 8 is
 * now closed — device tokens are looked up from the local `device_tokens`
 * read-model (synced via DeviceEventsConsumer from identity-service's
 * new `identity.device.push_token_registered` event).
 *
 * SCOPE NOTE — what's still NOT real: actually calling FCM/APNs. This
 * adapter now does the full real lookup (a device with zero tokens is
 * genuinely distinguishable from a device with tokens that just aren't
 * being delivered to), but the final "make an HTTP call to Google/Apple"
 * leg is still a logging stub — that needs real FCM/APNs credentials and
 * SDKs this environment doesn't have. The gap has moved from "we don't
 * know who to send to" (Milestone 8's problem) to "we know who, we're
 * just not really sending" (a normal, contained, credentials-only gap),
 * which is real progress worth stating precisely rather than declaring
 * this simply "done."
 */
@Injectable()
export class PushAdapterService {
  private readonly logger = new Logger(PushAdapterService.name);

  constructor(private readonly prisma: PrismaService) {}

  async send(userId: string, payload: PushPayload): Promise<void> {
    const tokens = await this.prisma.deviceToken.findMany({ where: { userId } });

    if (tokens.length === 0) {
      this.logger.debug(
        `No registered device tokens for user ${userId} — nothing to push`,
      );
      return;
    }

    for (const token of tokens) {
      this.logger.log(
        `[push-adapter stub] Would send to ${token.platform} device ${token.deviceId}: "${payload.title}" — ` +
          `real token found, but FCM/APNs SDK call itself is not implemented (see class-level comment).`,
      );
    }
  }
}
