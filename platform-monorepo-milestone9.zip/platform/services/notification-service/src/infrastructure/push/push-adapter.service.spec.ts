import { Test, TestingModule } from '@nestjs/testing';
import { PushAdapterService } from './push-adapter.service';
import { PrismaService } from '../prisma/prisma.service';

describe('PushAdapterService', () => {
  let service: PushAdapterService;
  let prisma: { deviceToken: { findMany: jest.Mock } };

  beforeEach(async () => {
    prisma = { deviceToken: { findMany: jest.fn() } };

    const module: TestingModule = await Test.createTestingModule({
      providers: [PushAdapterService, { provide: PrismaService, useValue: prisma }],
    }).compile();

    service = module.get<PushAdapterService>(PushAdapterService);
  });

  it('looks up device tokens by userId and does nothing further when none are registered', async () => {
    prisma.deviceToken.findMany.mockResolvedValue([]);

    await service.send('user-1', { title: 'Test', body: 'Body', data: {} });

    expect(prisma.deviceToken.findMany).toHaveBeenCalledWith({
      where: { userId: 'user-1' },
    });
  });

  it('processes every registered token for the user without throwing', async () => {
    prisma.deviceToken.findMany.mockResolvedValue([
      { deviceId: 'device-1', userId: 'user-1', platform: 'ios', pushToken: 'tok-1' },
      { deviceId: 'device-2', userId: 'user-1', platform: 'android', pushToken: 'tok-2' },
    ]);

    await expect(
      service.send('user-1', { title: 'Test', body: 'Body', data: {} }),
    ).resolves.not.toThrow();
  });
});
