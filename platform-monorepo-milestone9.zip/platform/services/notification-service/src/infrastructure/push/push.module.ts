import { Global, Module } from '@nestjs/common';
import { PushAdapterService } from './push-adapter.service';

@Global()
@Module({ providers: [PushAdapterService], exports: [PushAdapterService] })
export class PushModule {}
