import { NotificationDecisionPolicy } from './notification-decision.policy';

describe('NotificationDecisionPolicy', () => {
  it('notifies a recipient with no preference record (default: not muted)', () => {
    const result = NotificationDecisionPolicy.evaluate('user-2', 'user-1', null);
    expect(result).toEqual({ shouldNotify: true });
  });

  it('notifies a recipient who has not muted notifications', () => {
    const result = NotificationDecisionPolicy.evaluate('user-2', 'user-1', {
      muteAll: false,
    });
    expect(result).toEqual({ shouldNotify: true });
  });

  it('suppresses notification for a recipient who has muted all', () => {
    const result = NotificationDecisionPolicy.evaluate('user-2', 'user-1', {
      muteAll: true,
    });
    expect(result).toEqual({ shouldNotify: false, reason: 'muted' });
  });

  it('never notifies the sender about their own message', () => {
    const result = NotificationDecisionPolicy.evaluate('user-1', 'user-1', {
      muteAll: false,
    });
    expect(result).toEqual({ shouldNotify: false, reason: 'is_sender' });
  });

  it('checks sender identity before mute status', () => {
    const result = NotificationDecisionPolicy.evaluate('user-1', 'user-1', {
      muteAll: true,
    });
    expect(result.reason).toBe('is_sender');
  });
});
