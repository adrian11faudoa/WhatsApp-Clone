export type NotificationSuppressionReason = 'muted' | 'is_sender';

export interface NotificationDecision {
  shouldNotify: boolean;
  reason?: NotificationSuppressionReason;
}

/**
 * Domain Service: decides whether a given recipient should receive a
 * notification for a given event. Pure — no Prisma import. Deliberately
 * minimal for this milestone: a single per-user mute-all flag is the
 * only preference modeled (see README for what's deferred — per-
 * conversation mute, quiet hours, digest batching are all real Volume 1
 * concepts not implemented here).
 */
export class NotificationDecisionPolicy {
  static evaluate(
    recipientUserId: string,
    senderId: string,
    preference: { muteAll: boolean } | null,
  ): NotificationDecision {
    if (recipientUserId === senderId) {
      return { shouldNotify: false, reason: 'is_sender' };
    }
    if (preference?.muteAll) {
      return { shouldNotify: false, reason: 'muted' };
    }
    return { shouldNotify: true };
  }
}
