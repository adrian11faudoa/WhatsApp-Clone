import { Test, TestingModule } from '@nestjs/testing';
import { NotificationsService } from './notifications.service';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { PushAdapterService } from '../infrastructure/push/push-adapter.service';

describe('NotificationsService', () => {
  let service: NotificationsService;
  let prisma: {
    notificationPreference: { findUnique: jest.Mock; upsert: jest.Mock };
    notification: { create: jest.Mock; findMany: jest.Mock; updateMany: jest.Mock };
  };
  let pushAdapter: { send: jest.Mock };

  beforeEach(async () => {
    prisma = {
      notificationPreference: { findUnique: jest.fn(), upsert: jest.fn() },
      notification: { create: jest.fn(), findMany: jest.fn(), updateMany: jest.fn() },
    };
    pushAdapter = { send: jest.fn().mockResolvedValue(undefined) };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        NotificationsService,
        { provide: PrismaService, useValue: prisma },
        { provide: PushAdapterService, useValue: pushAdapter },
      ],
    }).compile();

    service = module.get<NotificationsService>(NotificationsService);
  });

  describe('handleMessageSent', () => {
    it('creates a notification and sends a push for each eligible recipient', async () => {
      prisma.notificationPreference.findUnique.mockResolvedValue(null);
      prisma.notification.create.mockResolvedValue({});

      await service.handleMessageSent({
        messageId: 'msg-1',
        conversationId: 'conv-1',
        senderId: 'sender-1',
        contentType: 'text',
        createdAt: new Date().toISOString(),
        recipientUserIds: ['recipient-1', 'recipient-2'],
      });

      expect(prisma.notification.create).toHaveBeenCalledTimes(2);
      expect(pushAdapter.send).toHaveBeenCalledTimes(2);
      expect(pushAdapter.send).toHaveBeenCalledWith(
        'recipient-1',
        expect.objectContaining({
          data: { conversationId: 'conv-1', messageId: 'msg-1' },
        }),
      );
    });

    it('skips a recipient who has muted all notifications', async () => {
      prisma.notificationPreference.findUnique.mockImplementation(
        ({ where }: { where: { userId: string } }) =>
          Promise.resolve(
            where.userId === 'muted-user'
              ? { userId: 'muted-user', muteAll: true }
              : null,
          ),
      );
      prisma.notification.create.mockResolvedValue({});

      await service.handleMessageSent({
        messageId: 'msg-1',
        conversationId: 'conv-1',
        senderId: 'sender-1',
        contentType: 'text',
        createdAt: new Date().toISOString(),
        recipientUserIds: ['muted-user', 'normal-user'],
      });

      expect(prisma.notification.create).toHaveBeenCalledTimes(1);
      expect(prisma.notification.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ userId: 'normal-user' }),
        }),
      );
      expect(pushAdapter.send).toHaveBeenCalledTimes(1);
    });

    it('does nothing when recipientUserIds is empty', async () => {
      await service.handleMessageSent({
        messageId: 'msg-1',
        conversationId: 'conv-1',
        senderId: 'sender-1',
        contentType: 'text',
        createdAt: new Date().toISOString(),
        recipientUserIds: [],
      });

      expect(prisma.notification.create).not.toHaveBeenCalled();
      expect(pushAdapter.send).not.toHaveBeenCalled();
    });
  });

  describe('markRead', () => {
    it('scopes the update to the notification id AND the requesting user', async () => {
      await service.markRead('notif-1', 'user-1');
      expect(prisma.notification.updateMany).toHaveBeenCalledWith({
        where: { id: 'notif-1', userId: 'user-1' },
        data: { readAt: expect.any(Date) },
      });
    });
  });

  describe('updatePreferences', () => {
    it('upserts the mute-all preference', async () => {
      prisma.notificationPreference.upsert.mockResolvedValue({
        userId: 'user-1',
        muteAll: true,
      });

      const result = await service.updatePreferences('user-1', { muteAll: true });

      expect(result.muteAll).toBe(true);
      expect(prisma.notificationPreference.upsert).toHaveBeenCalledWith({
        where: { userId: 'user-1' },
        create: { userId: 'user-1', muteAll: true },
        update: { muteAll: true },
      });
    });
  });
});
