import { ApiProperty } from '@nestjs/swagger';

export class NotificationResponseDto {
  @ApiProperty() id!: string;
  @ApiProperty() type!: string;
  @ApiProperty() payload!: Record<string, unknown>;
  @ApiProperty({ required: false, nullable: true }) readAt!: string | null;
  @ApiProperty() createdAt!: string;
}

export class PaginatedNotificationsResponseDto {
  @ApiProperty({ type: [NotificationResponseDto] })
  items!: NotificationResponseDto[];

  @ApiProperty({ nullable: true })
  nextCursor!: string | null;
}
