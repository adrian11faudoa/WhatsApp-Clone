import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import {
  KafkaConsumerService,
  ConsumedEvent,
} from '../infrastructure/kafka/kafka-consumer.service';
import { PrismaService } from '../infrastructure/prisma/prisma.service';

interface PushTokenRegisteredPayload {
  userId: string;
  deviceId: string;
  platform: string;
  pushToken: string;
}

/**
 * Keeps the local `device_tokens` read-model in sync with Identity's
 * `identity.device.push_token_registered` event (added in
 * identity-service Milestone 9 specifically to close this gap). This is
 * the consumer half of that fix.
 */
@Injectable()
export class DeviceEventsConsumer implements OnModuleInit {
  private readonly logger = new Logger(DeviceEventsConsumer.name);

  constructor(
    private readonly kafkaConsumer: KafkaConsumerService,
    private readonly prisma: PrismaService,
  ) {}

  onModuleInit(): void {
    this.kafkaConsumer.registerHandler(
      'identity.device.push_token_registered',
      async (event: ConsumedEvent) => {
        const payload = event.payload as unknown as PushTokenRegisteredPayload;
        await this.prisma.deviceToken.upsert({
          where: { deviceId: payload.deviceId },
          create: {
            deviceId: payload.deviceId,
            userId: payload.userId,
            platform: payload.platform,
            pushToken: payload.pushToken,
          },
          update: { platform: payload.platform, pushToken: payload.pushToken },
        });
        this.logger.log(
          `Synced push token for device ${payload.deviceId} (user ${payload.userId})`,
        );
      },
    );
  }
}
