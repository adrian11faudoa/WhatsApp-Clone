import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { PushAdapterService } from '../infrastructure/push/push-adapter.service';
import { NotificationDecisionPolicy } from '../domain/notification-decision.policy';
import { UpdatePreferencesDto } from './dto/update-preferences.dto';

export interface MessageSentEventPayload {
  messageId: string;
  conversationId: string;
  senderId: string;
  contentType: string;
  createdAt: string;
  recipientUserIds: string[];
}

/**
 * Application Service. No business rules here — NotificationDecisionPolicy
 * owns the should-this-user-be-notified decision (Volume 1 Sec 5.3).
 */
@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly pushAdapter: PushAdapterService,
  ) {}

  /**
   * Handles messaging.message.sent (v2 — carries recipientUserIds,
   * see messaging-service's amendment note in its own event-publish
   * code). Creates an in-app Notification row per eligible recipient
   * and calls the (currently stubbed) push adapter.
   */
  async handleMessageSent(payload: MessageSentEventPayload): Promise<void> {
    for (const recipientUserId of payload.recipientUserIds) {
      const preference = await this.prisma.notificationPreference.findUnique({
        where: { userId: recipientUserId },
      });

      const decision = NotificationDecisionPolicy.evaluate(
        recipientUserId,
        payload.senderId,
        preference,
      );

      if (!decision.shouldNotify) {
        continue;
      }

      await this.prisma.notification.create({
        data: {
          userId: recipientUserId,
          type: 'new_message',
          payload: {
            messageId: payload.messageId,
            conversationId: payload.conversationId,
            senderId: payload.senderId,
          },
        },
      });

      await this.pushAdapter.send(recipientUserId, {
        title: 'New message',
        body:
          payload.contentType === 'text'
            ? 'You have a new message'
            : 'Sent you a message',
        data: { conversationId: payload.conversationId, messageId: payload.messageId },
      });
    }
  }

  async list(userId: string, cursor?: string, limit = 50) {
    const items = await this.prisma.notification.findMany({
      where: { userId },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      take: limit + 1,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    });

    const hasMore = items.length > limit;
    const page = hasMore ? items.slice(0, limit) : items;

    return { items: page, nextCursor: hasMore ? page[page.length - 1].id : null };
  }

  async markRead(notificationId: string, userId: string): Promise<void> {
    // updateMany + userId filter, not update-by-id-alone: prevents a
    // user from marking another user's notification read by guessing an
    // id — the WHERE clause enforces ownership at the query level rather
    // than a separate existence+ownership check followed by a second
    // write (also just fewer round trips).
    await this.prisma.notification.updateMany({
      where: { id: notificationId, userId },
      data: { readAt: new Date() },
    });
  }

  async updatePreferences(userId: string, dto: UpdatePreferencesDto) {
    return this.prisma.notificationPreference.upsert({
      where: { userId },
      create: { userId, muteAll: dto.muteAll },
      update: { muteAll: dto.muteAll },
    });
  }
}
