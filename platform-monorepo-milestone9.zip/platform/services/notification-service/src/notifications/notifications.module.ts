import { Module } from '@nestjs/common';
import { NotificationsController } from './notifications.controller';
import { NotificationsService } from './notifications.service';
import { MessageEventsConsumer } from './message-events.consumer';
import { DeviceEventsConsumer } from './device-events.consumer';

@Module({
  controllers: [NotificationsController],
  providers: [NotificationsService, MessageEventsConsumer, DeviceEventsConsumer],
})
export class NotificationsModule {}
