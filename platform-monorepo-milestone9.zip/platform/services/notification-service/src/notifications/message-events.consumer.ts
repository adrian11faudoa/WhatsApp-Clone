import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import {
  KafkaConsumerService,
  ConsumedEvent,
} from '../infrastructure/kafka/kafka-consumer.service';
import { NotificationsService, MessageSentEventPayload } from './notifications.service';

@Injectable()
export class MessageEventsConsumer implements OnModuleInit {
  private readonly logger = new Logger(MessageEventsConsumer.name);

  constructor(
    private readonly kafkaConsumer: KafkaConsumerService,
    private readonly notificationsService: NotificationsService,
  ) {}

  onModuleInit(): void {
    this.kafkaConsumer.registerHandler(
      'messaging.message.sent',
      async (event: ConsumedEvent) => {
        const payload = event.payload as unknown as MessageSentEventPayload;
        if (!payload.recipientUserIds) {
          // A v1 event (pre-amendment) reached us — no recipient list to
          // work with. Log and skip rather than guessing, since guessing
          // wrong here means either spamming everyone or notifying no one.
          this.logger.warn(
            `messaging.message.sent event for message ${payload.messageId} has no recipientUserIds (schemaVersion=${event.schemaVersion}) — skipping`,
          );
          return;
        }
        await this.notificationsService.handleMessageSent(payload);
      },
    );
  }
}
