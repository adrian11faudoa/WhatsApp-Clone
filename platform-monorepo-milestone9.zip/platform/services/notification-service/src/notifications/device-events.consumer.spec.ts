import { Test, TestingModule } from '@nestjs/testing';
import { DeviceEventsConsumer } from './device-events.consumer';
import { KafkaConsumerService } from '../infrastructure/kafka/kafka-consumer.service';
import { PrismaService } from '../infrastructure/prisma/prisma.service';

describe('DeviceEventsConsumer', () => {
  let consumer: DeviceEventsConsumer;
  let prisma: { deviceToken: { upsert: jest.Mock } };
  let registeredHandler: (event: unknown) => Promise<void>;

  beforeEach(async () => {
    prisma = { deviceToken: { upsert: jest.fn().mockResolvedValue({}) } };
    const kafkaConsumer = {
      registerHandler: jest.fn(
        (_topic: string, handler: (event: unknown) => Promise<void>) => {
          registeredHandler = handler;
        },
      ),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DeviceEventsConsumer,
        { provide: KafkaConsumerService, useValue: kafkaConsumer },
        { provide: PrismaService, useValue: prisma },
      ],
    }).compile();

    consumer = module.get<DeviceEventsConsumer>(DeviceEventsConsumer);
    consumer.onModuleInit();
  });

  it('registers a handler for identity.device.push_token_registered', () => {
    expect(registeredHandler).toBeDefined();
  });

  it('upserts the device token into the local read-model on event', async () => {
    await registeredHandler({
      eventType: 'identity.device.push_token_registered',
      schemaVersion: 1,
      payload: {
        userId: 'user-1',
        deviceId: 'device-1',
        platform: 'ios',
        pushToken: 'tok-1',
      },
    });

    expect(prisma.deviceToken.upsert).toHaveBeenCalledWith({
      where: { deviceId: 'device-1' },
      create: {
        deviceId: 'device-1',
        userId: 'user-1',
        platform: 'ios',
        pushToken: 'tok-1',
      },
      update: { platform: 'ios', pushToken: 'tok-1' },
    });
  });
});
