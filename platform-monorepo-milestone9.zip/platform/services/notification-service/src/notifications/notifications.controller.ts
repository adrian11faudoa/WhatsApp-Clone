import { Body, Controller, Get, Param, Patch, Put, Query } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAccessPayload } from '../auth/strategies/jwt.strategy';
import { NotificationsService } from './notifications.service';
import { UpdatePreferencesDto } from './dto/update-preferences.dto';
import { PaginatedNotificationsResponseDto } from './dto/notification-response.dto';

@ApiTags('notifications')
@Controller('api/v1/notifications')
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Get()
  @ApiOperation({ summary: 'Cursor-paginated notification feed for the current user' })
  async list(
    @CurrentUser() user: JwtAccessPayload,
    @Query('cursor') cursor?: string,
    @Query('limit') limit?: string,
  ): Promise<PaginatedNotificationsResponseDto> {
    const result = await this.notificationsService.list(
      user.sub,
      cursor,
      limit ? Math.min(parseInt(limit, 10), 100) : 50,
    );
    return {
      items: result.items.map(
        (n: {
          id: string;
          type: string;
          payload: unknown;
          readAt: Date | null;
          createdAt: Date;
        }) => ({
          id: n.id,
          type: n.type,
          payload: n.payload as Record<string, unknown>,
          readAt: n.readAt?.toISOString() ?? null,
          createdAt: n.createdAt.toISOString(),
        }),
      ),
      nextCursor: result.nextCursor,
    };
  }

  @Patch(':notificationId/read')
  @ApiOperation({ summary: 'Mark a notification as read' })
  async markRead(
    @Param('notificationId') notificationId: string,
    @CurrentUser() user: JwtAccessPayload,
  ) {
    await this.notificationsService.markRead(notificationId, user.sub);
  }

  @Put('preferences')
  @ApiOperation({
    summary: 'Update notification preferences (mute-all only, in this milestone)',
  })
  async updatePreferences(
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: UpdatePreferencesDto,
  ) {
    return this.notificationsService.updatePreferences(user.sub, dto);
  }
}
