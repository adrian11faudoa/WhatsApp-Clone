# Notification Service

Owns the **Notification and Push Notification** bounded context —
Milestone 8. Built specifically to close a gap flagged twice already
(in `messaging-service`'s README, Milestones 2 and 7): an offline
recipient previously got nothing until they happened to check message
history. This service is that fix's in-app half.

## What this service does

- Consumes `messaging.message.sent` (v2 — see below) from Kafka, creates
  an in-app `Notification` row for every recipient except the sender,
  unless they've muted all notifications
- `GET /api/v1/notifications` — cursor-paginated feed
- `PATCH /api/v1/notifications/{id}/read`
- `PUT /api/v1/notifications/preferences` — mute-all toggle only (see
  gaps below)

## A cross-service amendment this milestone required

Consuming `messaging.message.sent` usefully requires knowing *who* to
notify. The event as originally published (Milestone 2) didn't carry
recipient information — nothing needed it until this service existed.
Fixed at the source: `messaging-service`'s `MessagingService.sendMessage`
now publishes `recipientUserIds` (schemaVersion bumped 1→2, additive per
Volume 2 Section 2's versioning rule — old consumers reading only the
fields they already knew about are unaffected). This is the third time
building the next layer up has surfaced a real gap in an earlier
milestone — see `presence-service` and `web-client`'s READMEs for the
first two. Worth treating as an expected pattern of this kind of
incremental build, not a series of mistakes.

## The push-token gap — closed in Milestone 9, one leg remains

**Update:** the gap described below is now closed on the identity side.
`identity-service` gained `PUT /api/v1/devices/me/push-token`
(Milestone 9), which publishes `identity.device.push_token_registered`;
this service now consumes that event (`DeviceEventsConsumer`) into a
local `device_tokens` read-model, and `PushAdapterService.send()` does a
real lookup against it instead of being a blanket no-op. What's *still*
not real: the actual FCM/APNs SDK call — that needs real push-provider
credentials this environment doesn't have. The gap moved from "we don't
know who to send to" to "we know who, we're just not really sending,"
which is a normal, contained, credentials-only gap — see the class-level
comment in `push-adapter.service.ts` for the precise line.

`PushAdapterService.send()` was previously a logging no-op regardless of
input. Not because FCM/APNs integration is hard to write, but because
there was no source of device push tokens to send to. `identity-service`
owns the `devices` table (`push_token` column) but exposed no API or
event for it — nothing needed that data until this service existed.

## What's deliberately NOT in this milestone

- Per-conversation mute (only global mute-all exists)
- Quiet hours / digest batching (Volume 1's Notification Service
  responsibilities include both; neither is modeled)
- Consuming any event besides `messaging.message.sent` — no call/mention/
  moderation-action notifications yet, since Calls and full Moderation
  aren't built

## Local development

```bash
cp .env.example .env
mkdir -p keys && cp ../identity-service/keys/jwt-public.pem keys/
docker-compose up --build
npx prisma migrate dev
```

## Testing

```bash
npm test          # unit — NotificationDecisionPolicy (zero mocks) + NotificationsService (mocked Prisma)
npm run test:cov
npm run test:e2e
```

## Contract references

- Notification/Push service responsibilities: `architecture-phase1-vol1.md` Section 4.1
- API surface: `architecture-phase1-vol3.md` Section 7
