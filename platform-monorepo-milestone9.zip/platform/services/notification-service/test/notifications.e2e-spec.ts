import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';

describe('Notifications endpoints (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('GET /api/v1/notifications returns 401 without a token', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/notifications');
    expect(response.status).toBe(401);
  });

  it('PUT /api/v1/notifications/preferences returns 401 without a token', async () => {
    const response = await request(app.getHttpServer())
      .put('/api/v1/notifications/preferences')
      .send({ muteAll: true });
    expect(response.status).toBe(401);
  });

  it('GET /health/live returns 200 without auth', async () => {
    const response = await request(app.getHttpServer()).get('/health/live');
    expect(response.status).toBe(200);
  });
});
