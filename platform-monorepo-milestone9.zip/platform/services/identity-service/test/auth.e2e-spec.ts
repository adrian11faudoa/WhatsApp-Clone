import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';

/**
 * End-to-end test against a full Nest application instance.
 * Per architecture-phase1-vol3.md Section 6.2, real integration tests
 * run against real infrastructure (Postgres/Kafka via testcontainers)
 * in CI — this spec assumes DATABASE_URL/KAFKA_BROKERS point at such
 * ephemeral infra when run in the pipeline (see .github/workflows).
 */
describe('Auth flows (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('POST /api/v1/auth/register rejects a weak password with 400', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/v1/auth/register')
      .send({
        username: 'e2e_test_user',
        email: 'e2e@example.com',
        password: 'short',
        displayName: 'E2E Test',
      });

    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('errorCode');
  });

  it('POST /api/v1/auth/login returns 401 Problem Details for unknown user', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: 'nobody@example.com', password: 'whatever12' });

    expect(response.status).toBe(401);
    expect(response.body).toMatchObject({
      status: 401,
      errorCode: 'invalid_credentials',
    });
  });

  it('GET /api/v1/users/me returns 401 without a token', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/users/me');
    expect(response.status).toBe(401);
  });

  it('PUT /api/v1/devices/me/push-token returns 401 without a token', async () => {
    const response = await request(app.getHttpServer())
      .put('/api/v1/devices/me/push-token')
      .send({ platform: 'ios', pushToken: 'tok-1' });
    expect(response.status).toBe(401);
  });

  it('GET /health/live returns 200 without auth', async () => {
    const response = await request(app.getHttpServer()).get('/health/live');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ status: 'ok' });
  });
});
