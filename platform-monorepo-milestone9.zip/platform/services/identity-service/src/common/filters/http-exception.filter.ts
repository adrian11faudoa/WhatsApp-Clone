import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';

/**
 * Central error handler. Emits RFC 7807 Problem Details JSON, per
 * architecture-phase1-vol2.md Section 3.1 API conventions — every
 * service in the platform must return errors in this shape so client
 * error-handling code is uniform across the whole API surface.
 */
@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    const exceptionResponse =
      exception instanceof HttpException ? exception.getResponse() : null;

    const detail =
      typeof exceptionResponse === 'string'
        ? exceptionResponse
        : ((exceptionResponse as { message?: string | string[] })?.message ??
          'An unexpected error occurred');

    const errorCode =
      (exceptionResponse as { errorCode?: string })?.errorCode ??
      this.defaultErrorCode(status);

    if (status >= HttpStatus.INTERNAL_SERVER_ERROR) {
      this.logger.error(
        `Unhandled exception on ${request.method} ${request.url}`,
        exception instanceof Error ? exception.stack : String(exception),
      );
    }

    const problemDetails = {
      type: `https://docs.platform.internal/errors/${errorCode}`,
      title: this.defaultTitle(status),
      status,
      detail: Array.isArray(detail) ? detail.join('; ') : detail,
      instance: request.url,
      errorCode,
      traceId: request.headers['x-trace-id'] ?? undefined,
    };

    response.status(status).json(problemDetails);
  }

  private defaultTitle(status: number): string {
    const titles: Record<number, string> = {
      400: 'Bad Request',
      401: 'Unauthorized',
      403: 'Forbidden',
      404: 'Not Found',
      409: 'Conflict',
      422: 'Unprocessable Entity',
      429: 'Too Many Requests',
      500: 'Internal Server Error',
    };
    return titles[status] ?? 'Error';
  }

  private defaultErrorCode(status: number): string {
    const codes: Record<number, string> = {
      400: 'validation_error',
      401: 'unauthorized',
      403: 'forbidden',
      404: 'not_found',
      409: 'conflict',
      422: 'unprocessable_entity',
      429: 'rate_limited',
      500: 'internal_error',
    };
    return codes[status] ?? 'unknown_error';
  }
}
