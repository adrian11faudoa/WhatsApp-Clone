import { Module } from '@nestjs/common';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { TerminusModule } from '@nestjs/terminus';

import configuration from './config/configuration';
import { validate } from './config/validation';

import { PrismaModule } from './infrastructure/prisma/prisma.module';
import { VaultModule } from './infrastructure/vault/vault.module';
import { KafkaModule } from './infrastructure/kafka/kafka.module';

import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { DevicesModule } from './devices/devices.module';
import { HealthModule } from './health/health.module';

import { GlobalAuthGuard } from './common/guards/global-auth.guard';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
      validate,
    }),
    ThrottlerModule.forRoot({
      throttlers: [{ ttl: 60_000, limit: 100 }], // Volume 2 Sec 6 default; per-route overrides via @Throttle
    }),
    TerminusModule,
    PrismaModule,
    VaultModule,
    KafkaModule,
    AuthModule,
    UsersModule,
    DevicesModule,
    HealthModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: GlobalAuthGuard },
    { provide: APP_FILTER, useClass: HttpExceptionFilter },
    { provide: APP_INTERCEPTOR, useClass: LoggingInterceptor },
  ],
})
export class AppModule {}
