/**
 * Password value object — enforces the platform's password policy at
 * the domain boundary so no code path can create a Credentials record
 * with a policy-violating password, regardless of which controller
 * or use case is calling in.
 */
export class Password {
  private constructor(private readonly plaintext: string) {}

  private static readonly MIN_LENGTH = 10;

  static create(raw: string): Password {
    if (raw.length < Password.MIN_LENGTH) {
      throw new WeakPasswordError(
        `Password must be at least ${Password.MIN_LENGTH} characters`,
      );
    }
    if (!/[a-z]/.test(raw) || !/[A-Z]/.test(raw) || !/[0-9]/.test(raw)) {
      throw new WeakPasswordError(
        'Password must include uppercase, lowercase, and a digit',
      );
    }
    return new Password(raw);
  }

  reveal(): string {
    return this.plaintext;
  }
}

export class WeakPasswordError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WeakPasswordError';
  }
}
