import { Password, WeakPasswordError } from './password.vo';

describe('Password value object', () => {
  it('accepts a password meeting the policy', () => {
    const password = Password.create('Str0ngPassw0rd');
    expect(password.reveal()).toBe('Str0ngPassw0rd');
  });

  it('rejects passwords shorter than the minimum length', () => {
    expect(() => Password.create('Sh0rt')).toThrow(WeakPasswordError);
  });

  it('rejects passwords missing a digit', () => {
    expect(() => Password.create('NoDigitsHere')).toThrow(WeakPasswordError);
  });

  it('rejects passwords missing an uppercase letter', () => {
    expect(() => Password.create('alllowercase1')).toThrow(WeakPasswordError);
  });
});
