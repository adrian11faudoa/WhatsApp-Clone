import { Email, InvalidEmailError } from './email.vo';

describe('Email value object', () => {
  it('accepts a well-formed email and normalizes case/whitespace', () => {
    const email = Email.create('  Jane@Example.com  ');
    expect(email.toString()).toBe('jane@example.com');
  });

  it.each(['not-an-email', 'missing@domain', '@nodomain.com', ''])(
    'rejects malformed input: %s',
    (raw) => {
      expect(() => Email.create(raw)).toThrow(InvalidEmailError);
    },
  );

  it('equals() compares normalized values', () => {
    const a = Email.create('jane@example.com');
    const b = Email.create('JANE@EXAMPLE.COM');
    expect(a.equals(b)).toBe(true);
  });
});
