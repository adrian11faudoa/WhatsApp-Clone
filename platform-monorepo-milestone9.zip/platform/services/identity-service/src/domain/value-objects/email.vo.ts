/**
 * Email value object — validates and normalizes on construction so
 * an invalid or inconsistently-cased email can never exist inside the
 * domain layer. Pure, no I/O — unit-testable with zero mocks, per
 * architecture-phase1-vol1.md Section 5.3's Domain Service/VO rule.
 */
export class Email {
  private readonly value: string;

  private static readonly PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  private constructor(value: string) {
    this.value = value;
  }

  static create(raw: string): Email {
    const normalized = raw.trim().toLowerCase();
    if (!Email.PATTERN.test(normalized)) {
      throw new InvalidEmailError(raw);
    }
    return new Email(normalized);
  }

  toString(): string {
    return this.value;
  }

  equals(other: Email): boolean {
    return this.value === other.value;
  }
}

export class InvalidEmailError extends Error {
  constructor(raw: string) {
    super(`"${raw}" is not a valid email address`);
    this.name = 'InvalidEmailError';
  }
}
