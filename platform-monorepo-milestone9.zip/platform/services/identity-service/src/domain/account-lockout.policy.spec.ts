import { AccountLockoutPolicy } from './account-lockout.policy';

describe('AccountLockoutPolicy', () => {
  describe('isLocked', () => {
    it('returns false when lockedUntil is null', () => {
      expect(AccountLockoutPolicy.isLocked(null)).toBe(false);
    });

    it('returns true when lockedUntil is in the future', () => {
      const future = new Date(Date.now() + 60_000);
      expect(AccountLockoutPolicy.isLocked(future)).toBe(true);
    });

    it('returns false when lockedUntil is in the past', () => {
      const past = new Date(Date.now() - 60_000);
      expect(AccountLockoutPolicy.isLocked(past)).toBe(false);
    });
  });

  describe('onFailedAttempt', () => {
    it('increments failedAttempts without locking below threshold', () => {
      const result = AccountLockoutPolicy.onFailedAttempt(2);
      expect(result.failedAttempts).toBe(3);
      expect(result.lockedUntil).toBeNull();
    });

    it('locks the account once MAX_FAILED_ATTEMPTS is reached', () => {
      const now = new Date('2026-01-01T00:00:00Z');
      const result = AccountLockoutPolicy.onFailedAttempt(4, now);
      expect(result.failedAttempts).toBe(5);
      expect(result.lockedUntil).not.toBeNull();
      expect(result.lockedUntil!.getTime()).toBeGreaterThan(now.getTime());
    });
  });

  describe('onSuccessfulLogin', () => {
    it('resets failedAttempts and clears lockout', () => {
      const result = AccountLockoutPolicy.onSuccessfulLogin();
      expect(result).toEqual({ failedAttempts: 0, lockedUntil: null });
    });
  });
});
