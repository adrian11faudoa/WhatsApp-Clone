/**
 * Domain Service: decides account-lockout behavior from failed login
 * attempts. Pure function over primitive state — no I/O, no Prisma
 * import — the Application layer (AuthService) is responsible for
 * loading/persisting the Credentials row and calling this policy with
 * the current counters, per the Domain/Application boundary rule in
 * architecture-phase1-vol1.md Section 5.3.
 */
export class AccountLockoutPolicy {
  private static readonly MAX_FAILED_ATTEMPTS = 5;
  private static readonly LOCKOUT_DURATION_MINUTES = 15;

  static isLocked(lockedUntil: Date | null, now: Date = new Date()): boolean {
    return lockedUntil !== null && lockedUntil.getTime() > now.getTime();
  }

  static onFailedAttempt(
    currentFailedAttempts: number,
    now: Date = new Date(),
  ): { failedAttempts: number; lockedUntil: Date | null } {
    const failedAttempts = currentFailedAttempts + 1;
    if (failedAttempts >= AccountLockoutPolicy.MAX_FAILED_ATTEMPTS) {
      const lockedUntil = new Date(
        now.getTime() + AccountLockoutPolicy.LOCKOUT_DURATION_MINUTES * 60_000,
      );
      return { failedAttempts, lockedUntil };
    }
    return { failedAttempts, lockedUntil: null };
  }

  static onSuccessfulLogin(): { failedAttempts: number; lockedUntil: null } {
    return { failedAttempts: 0, lockedUntil: null };
  }
}
