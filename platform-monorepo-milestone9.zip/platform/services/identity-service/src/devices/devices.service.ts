import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { RegisterPushTokenDto } from './dto/register-push-token.dto';

/**
 * Closes the gap flagged in notification-service's README: nothing
 * previously exposed device push tokens outside identity-service.
 * `devices.push_token` (Volume 2 Sec 1.1) already existed in the
 * schema — it just had no write path and no outward event. Both added
 * here, Milestone 9.
 */
@Injectable()
export class DevicesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly kafkaProducer: KafkaProducerService,
  ) {}

  async registerPushToken(
    sessionId: string,
    userId: string,
    dto: RegisterPushTokenDto,
  ): Promise<void> {
    const session = await this.prisma.session.findUnique({ where: { id: sessionId } });
    if (!session) {
      throw new NotFoundException({
        message: 'Session not found',
        errorCode: 'session_not_found',
      });
    }

    const device = await this.prisma.device.update({
      where: { id: session.deviceId },
      data: { platform: dto.platform, pushToken: dto.pushToken, lastSeenAt: new Date() },
    });

    await this.kafkaProducer.publish('identity.device.push_token_registered', {
      eventType: 'identity.device.push_token_registered',
      key: userId,
      schemaVersion: 1,
      payload: {
        userId,
        deviceId: device.id,
        platform: device.platform,
        pushToken: device.pushToken,
      },
    });
  }
}
