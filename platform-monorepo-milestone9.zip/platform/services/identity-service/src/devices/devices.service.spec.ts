import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException } from '@nestjs/common';
import { DevicesService } from './devices.service';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';

describe('DevicesService', () => {
  let service: DevicesService;
  let prisma: { session: { findUnique: jest.Mock }; device: { update: jest.Mock } };
  let kafkaProducer: { publish: jest.Mock };

  beforeEach(async () => {
    prisma = {
      session: { findUnique: jest.fn() },
      device: { update: jest.fn() },
    };
    kafkaProducer = { publish: jest.fn().mockResolvedValue(undefined) };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DevicesService,
        { provide: PrismaService, useValue: prisma },
        { provide: KafkaProducerService, useValue: kafkaProducer },
      ],
    }).compile();

    service = module.get<DevicesService>(DevicesService);
  });

  it('throws NotFoundException when the session does not exist', async () => {
    prisma.session.findUnique.mockResolvedValue(null);

    await expect(
      service.registerPushToken('session-1', 'user-1', {
        platform: 'ios',
        pushToken: 'tok-1',
      }),
    ).rejects.toThrow(NotFoundException);
    expect(prisma.device.update).not.toHaveBeenCalled();
  });

  it('updates the device and publishes identity.device.push_token_registered', async () => {
    prisma.session.findUnique.mockResolvedValue({
      id: 'session-1',
      deviceId: 'device-1',
    });
    prisma.device.update.mockResolvedValue({
      id: 'device-1',
      platform: 'ios',
      pushToken: 'tok-1',
    });

    await service.registerPushToken('session-1', 'user-1', {
      platform: 'ios',
      pushToken: 'tok-1',
    });

    expect(prisma.device.update).toHaveBeenCalledWith({
      where: { id: 'device-1' },
      data: { platform: 'ios', pushToken: 'tok-1', lastSeenAt: expect.any(Date) },
    });
    expect(kafkaProducer.publish).toHaveBeenCalledWith(
      'identity.device.push_token_registered',
      expect.objectContaining({
        eventType: 'identity.device.push_token_registered',
        payload: {
          userId: 'user-1',
          deviceId: 'device-1',
          platform: 'ios',
          pushToken: 'tok-1',
        },
      }),
    );
  });
});
