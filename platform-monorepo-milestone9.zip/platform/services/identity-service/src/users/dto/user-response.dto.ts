import { ApiProperty } from '@nestjs/swagger';

export class UserResponseDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  username!: string;

  @ApiProperty({ required: false })
  email?: string;

  @ApiProperty()
  displayName!: string;

  @ApiProperty()
  status!: string;

  @ApiProperty()
  createdAt!: string;
}
