import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async findById(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || user.deletedAt) {
      throw new NotFoundException({
        message: 'User not found',
        errorCode: 'user_not_found',
      });
    }
    return user;
  }

  async updateProfile(userId: string, dto: UpdateUserDto) {
    await this.findById(userId); // ensures 404 semantics before attempting update
    return this.prisma.user.update({
      where: { id: userId },
      data: { ...(dto.displayName ? { displayName: dto.displayName } : {}) },
    });
  }
}
