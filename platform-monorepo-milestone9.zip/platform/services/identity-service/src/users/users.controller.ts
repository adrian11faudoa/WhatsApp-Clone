import { Body, Controller, Get, Patch } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAccessPayload } from '../auth/strategies/jwt.strategy';
import { UsersService } from './users.service';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserResponseDto } from './dto/user-response.dto';

@ApiTags('users')
@Controller('api/v1/users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get('me')
  @ApiOperation({ summary: 'Get the current authenticated user profile' })
  async me(@CurrentUser() user: JwtAccessPayload): Promise<UserResponseDto> {
    const record = await this.usersService.findById(user.sub);
    return this.toResponse(record);
  }

  @Patch('me')
  @ApiOperation({ summary: 'Update the current user profile' })
  async updateMe(
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: UpdateUserDto,
  ): Promise<UserResponseDto> {
    const record = await this.usersService.updateProfile(user.sub, dto);
    return this.toResponse(record);
  }

  private toResponse(record: {
    id: string;
    username: string;
    email: string | null;
    displayName: string;
    status: string;
    createdAt: Date;
  }): UserResponseDto {
    return {
      id: record.id,
      username: record.username,
      email: record.email ?? undefined,
      displayName: record.displayName,
      status: record.status,
      createdAt: record.createdAt.toISOString(),
    };
  }
}
