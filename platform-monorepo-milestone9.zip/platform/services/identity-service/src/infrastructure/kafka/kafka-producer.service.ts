import {
  Inject,
  Injectable,
  Logger,
  OnModuleDestroy,
  OnModuleInit,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Kafka, Producer } from 'kafkajs';
import { randomUUID } from 'crypto';

export interface DomainEvent<T = Record<string, unknown>> {
  eventType: string; // e.g. "identity.user.registered"
  payload: T;
  traceId: string;
  correlationId: string;
  causationId?: string;
  schemaVersion: number;
}

/**
 * Publishes domain events to Kafka per the event catalogue in
 * architecture-phase1-vol2.md Section 2. Topic naming: {context}.{entity}.{event}.
 * Every event carries trace_id/correlation_id/causation_id per the
 * observability contract (Volume 1 Section 8) — this is what lets a
 * distributed trace follow a request through the async path, not just
 * the initial HTTP call.
 */
@Injectable()
export class KafkaProducerService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(KafkaProducerService.name);
  private readonly kafka: Kafka;
  private producer: Producer;

  constructor(@Inject(ConfigService) private readonly configService: ConfigService) {
    this.kafka = new Kafka({
      clientId: this.configService.get<string>('kafka.clientId')!,
      brokers: this.configService.get<string[]>('kafka.brokers')!,
      retry: { retries: 8, initialRetryTime: 300 },
    });
    this.producer = this.kafka.producer({ idempotent: true });
  }

  async onModuleInit(): Promise<void> {
    await this.producer.connect();
    this.logger.log('Kafka producer connected');
  }

  async onModuleDestroy(): Promise<void> {
    await this.producer.disconnect();
  }

  async publish<T>(
    topic: string,
    event: Omit<DomainEvent<T>, 'traceId' | 'correlationId'> & {
      traceId?: string;
      correlationId?: string;
      key?: string;
    },
  ): Promise<void> {
    const traceId = event.traceId ?? randomUUID();
    const correlationId = event.correlationId ?? traceId;

    await this.producer.send({
      topic,
      messages: [
        {
          key: event.key,
          value: JSON.stringify({
            eventType: event.eventType,
            payload: event.payload,
            schemaVersion: event.schemaVersion,
          }),
          headers: {
            trace_id: traceId,
            correlation_id: correlationId,
            causation_id: event.causationId ?? '',
            occurred_at: new Date().toISOString(),
          },
        },
      ],
    });
  }
}
