import { Injectable, Logger } from '@nestjs/common';
import { readFileSync } from 'fs';

/**
 * Reads secrets populated by the Vault Agent Injector sidecar
 * (architecture-phase1-vol3.md Section 5.6). Application code never
 * calls the Vault API directly — it reads from a local file path the
 * sidecar keeps refreshed. In local dev, this same interface reads
 * from .env-provided paths instead, so no code branches by environment.
 */
@Injectable()
export class VaultService {
  private readonly logger = new Logger(VaultService.name);
  private cache = new Map<string, string>();

  readSecretFile(path: string): string {
    const cached = this.cache.get(path);
    if (cached) return cached;

    try {
      const value = readFileSync(path, 'utf-8').trim();
      this.cache.set(path, value);
      return value;
    } catch (err) {
      this.logger.error(`Failed to read secret at ${path}`, err as Error);
      throw new Error(`Secret unavailable: ${path}`);
    }
  }

  /** Vault Agent refreshes the underlying file on rotation; call this to force a re-read. */
  invalidate(path: string): void {
    this.cache.delete(path);
  }
}
