import {
  INestApplication,
  Injectable,
  Logger,
  OnModuleDestroy,
  OnModuleInit,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * Wraps PrismaClient as a Nest provider with lifecycle hooks so
 * connections are established on boot and drained on graceful
 * shutdown — required by the "graceful shutdown" item in the
 * master engineering brief's Code Quality section.
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);

  constructor() {
    super({
      log: [
        { emit: 'event', level: 'warn' },
        { emit: 'event', level: 'error' },
      ],
    });
  }

  async onModuleInit(): Promise<void> {
    await this.$connect();
    this.logger.log('Database connection established');
  }

  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
    this.logger.log('Database connection closed');
  }

  async enableShutdownHooks(app: INestApplication): Promise<void> {
    process.on('SIGTERM', async () => {
      this.logger.log('SIGTERM received, draining connections');
      await app.close();
    });
    process.on('SIGINT', async () => {
      this.logger.log('SIGINT received, draining connections');
      await app.close();
    });
  }
}
