import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/**
 * Standard guard applied to every endpoint requiring an authenticated
 * user. Public endpoints opt out via the @Public() decorator combined
 * with a global-guard + reflector pattern (see common/guards).
 */
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
