import {
  ConflictException,
  ForbiddenException,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { createHash, randomUUID } from 'crypto';
import { readFileSync } from 'fs';

import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { Email } from '../domain/value-objects/email.vo';
import { Password } from '../domain/value-objects/password.vo';
import { AccountLockoutPolicy } from '../domain/account-lockout.policy';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

export interface DeviceContext {
  platform: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

/**
 * Application Service (use-case orchestration layer). Contains no
 * business rules of its own — see architecture-phase1-vol1.md Section
 * 5.3: rules live in Domain layer (Email/Password VOs, AccountLockoutPolicy).
 * This class loads state, calls domain logic, persists, and publishes events.
 */
@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly jwtPrivateKey: string;
  private readonly accessTtlSeconds: number;
  private readonly refreshTtlSeconds: number;
  private readonly keyId: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly kafkaProducer: KafkaProducerService,
  ) {
    this.jwtPrivateKey = readFileSync(
      this.configService.get<string>('jwt.privateKeyPath')!,
      'utf-8',
    );
    this.accessTtlSeconds = this.configService.get<number>('jwt.accessTtlSeconds')!;
    this.refreshTtlSeconds = this.configService.get<number>('jwt.refreshTtlSeconds')!;
    this.keyId = this.configService.get<string>('jwt.keyId')!;
  }

  async register(dto: RegisterDto): Promise<{ userId: string }> {
    const email = dto.email ? Email.create(dto.email) : undefined;
    const password = Password.create(dto.password); // throws WeakPasswordError -> mapped to 400 by validation pipe upstream in practice; domain error here for defense in depth

    const existing = await this.prisma.user.findFirst({
      where: {
        OR: [
          { username: dto.username },
          ...(email ? [{ email: email.toString() }] : []),
          ...(dto.phone ? [{ phone: dto.phone }] : []),
        ],
      },
    });
    if (existing) {
      throw new ConflictException({
        message: 'username, email, or phone already registered',
        errorCode: 'account_exists',
      });
    }

    const passwordHash = await argon2.hash(password.reveal(), { type: argon2.argon2id });

    const user = await this.prisma.user.create({
      data: {
        username: dto.username,
        email: email?.toString(),
        phone: dto.phone,
        displayName: dto.displayName,
        status: 'pending_verification',
        credentials: { create: { passwordHash } },
      },
    });

    await this.kafkaProducer.publish('identity.user.registered', {
      eventType: 'identity.user.registered',
      key: user.id,
      schemaVersion: 1,
      payload: {
        userId: user.id,
        accountType: user.accountType,
        createdAt: user.createdAt.toISOString(),
      },
    });

    this.logger.log(`User registered: ${user.id}`);
    return { userId: user.id };
  }

  async login(dto: LoginDto, device: DeviceContext): Promise<TokenPair> {
    const user = await this.prisma.user.findFirst({
      where: dto.email ? { email: dto.email } : { phone: dto.phone },
      include: { credentials: true },
    });

    // Constant-shape response whether user exists or not, to avoid
    // account enumeration via response-time/content differences.
    if (!user || !user.credentials?.passwordHash) {
      throw new UnauthorizedException({
        message: 'Invalid credentials',
        errorCode: 'invalid_credentials',
      });
    }

    if (AccountLockoutPolicy.isLocked(user.credentials.lockedUntil)) {
      throw new ForbiddenException({
        message: 'Account temporarily locked due to failed login attempts',
        errorCode: 'account_locked',
      });
    }

    const passwordValid = await argon2.verify(
      user.credentials.passwordHash,
      dto.password,
    );

    if (!passwordValid) {
      const { failedAttempts, lockedUntil } = AccountLockoutPolicy.onFailedAttempt(
        user.credentials.failedAttempts,
      );
      await this.prisma.credentials.update({
        where: { userId: user.id },
        data: { failedAttempts, lockedUntil },
      });
      throw new UnauthorizedException({
        message: 'Invalid credentials',
        errorCode: 'invalid_credentials',
      });
    }

    if (user.status === 'suspended' || user.status === 'deleted') {
      throw new ForbiddenException({
        message: 'Account is not active',
        errorCode: 'account_inactive',
      });
    }

    const { failedAttempts, lockedUntil } = AccountLockoutPolicy.onSuccessfulLogin();
    await this.prisma.credentials.update({
      where: { userId: user.id },
      data: { failedAttempts, lockedUntil },
    });

    const tokens = await this.issueTokenPair(
      user.id,
      user.username,
      user.accountType,
      device,
    );

    await this.kafkaProducer.publish('auth.session.created', {
      eventType: 'auth.session.created',
      key: user.id,
      schemaVersion: 1,
      payload: { userId: user.id, ip: device.ipAddress },
    });

    return tokens;
  }

  /**
   * Refresh-token rotation with reuse detection, per
   * architecture-phase1-vol2.md Section 6: presenting an already-rotated
   * refresh token revokes the entire session family and is treated as
   * a compromise signal.
   */
  async refresh(rawRefreshToken: string): Promise<TokenPair> {
    const tokenHash = this.hashToken(rawRefreshToken);

    const existingToken = await this.prisma.refreshToken.findUnique({
      where: { tokenHash },
      include: { session: { include: { user: true } } },
    });

    if (!existingToken) {
      throw new UnauthorizedException({
        message: 'Invalid refresh token',
        errorCode: 'invalid_refresh_token',
      });
    }

    // Reuse detection: if this token has already been rotated (has children), it's being replayed.
    const rotatedChild = await this.prisma.refreshToken.findFirst({
      where: { rotatedFromId: existingToken.id },
    });

    if (rotatedChild || existingToken.expiresAt < new Date()) {
      await this.prisma.session.update({
        where: { id: existingToken.sessionId },
        data: { revokedAt: new Date() },
      });
      this.logger.warn(
        `Refresh token reuse detected for session ${existingToken.sessionId} — session family revoked`,
      );
      await this.kafkaProducer.publish('auth.session.revoked', {
        eventType: 'auth.session.revoked',
        key: existingToken.session.userId,
        schemaVersion: 1,
        payload: {
          sessionId: existingToken.sessionId,
          userId: existingToken.session.userId,
          reason: 'reuse_detected',
        },
      });
      throw new UnauthorizedException({
        message: 'Refresh token reuse detected — session revoked',
        errorCode: 'refresh_reuse_detected',
      });
    }

    if (existingToken.session.revokedAt) {
      throw new UnauthorizedException({
        message: 'Session has been revoked',
        errorCode: 'session_revoked',
      });
    }

    const user = existingToken.session.user;
    const accessToken = this.signAccessToken(
      user.id,
      user.username,
      user.accountType,
      existingToken.sessionId,
    );

    const newRawRefreshToken = randomUUID() + randomUUID();
    const newTokenHash = this.hashToken(newRawRefreshToken);
    const newExpiresAt = new Date(Date.now() + this.refreshTtlSeconds * 1000);

    await this.prisma.refreshToken.create({
      data: {
        sessionId: existingToken.sessionId,
        tokenHash: newTokenHash,
        rotatedFromId: existingToken.id,
        expiresAt: newExpiresAt,
      },
    });

    return {
      accessToken,
      refreshToken: newRawRefreshToken,
      expiresIn: this.accessTtlSeconds,
    };
  }

  async logout(sessionId: string, userId: string): Promise<void> {
    await this.prisma.session.update({
      where: { id: sessionId },
      data: { revokedAt: new Date() },
    });
    await this.kafkaProducer.publish('auth.session.revoked', {
      eventType: 'auth.session.revoked',
      key: userId,
      schemaVersion: 1,
      payload: { sessionId, userId, reason: 'logout' },
    });
  }

  private async issueTokenPair(
    userId: string,
    username: string,
    accountType: string,
    device: DeviceContext,
  ): Promise<TokenPair> {
    const deviceRecord = await this.prisma.device.create({
      data: { userId, platform: device.platform },
    });

    const rawRefreshToken = randomUUID() + randomUUID();
    const tokenHash = this.hashToken(rawRefreshToken);
    const expiresAt = new Date(Date.now() + this.refreshTtlSeconds * 1000);

    const session = await this.prisma.session.create({
      data: {
        userId,
        deviceId: deviceRecord.id,
        refreshTokenHash: tokenHash,
        ipAddress: device.ipAddress,
        userAgent: device.userAgent,
        expiresAt,
        refreshTokens: {
          create: { tokenHash, expiresAt },
        },
      },
    });

    const accessToken = this.signAccessToken(userId, username, accountType, session.id);

    return {
      accessToken,
      refreshToken: rawRefreshToken,
      expiresIn: this.accessTtlSeconds,
    };
  }

  private signAccessToken(
    userId: string,
    username: string,
    accountType: string,
    sessionId: string,
  ): string {
    return this.jwtService.sign(
      { sub: userId, username, accountType, sessionId },
      {
        privateKey: this.jwtPrivateKey,
        algorithm: 'RS256',
        expiresIn: this.accessTtlSeconds,
        keyid: this.keyId,
      },
    );
  }

  private hashToken(raw: string): string {
    // Refresh tokens are hashed at rest (never store the raw bearer secret),
    // same principle as password hashing but SHA-256 suffices here since
    // these are high-entropy random tokens, not low-entropy user passwords.
    return createHash('sha256').update(raw).digest('hex');
  }
}
