import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { readFileSync } from 'fs';

export interface JwtAccessPayload {
  sub: string; // userId
  username: string;
  accountType: string;
  sessionId: string;
}

/**
 * Verifies short-lived access tokens (15 min TTL, per Volume 2 Section 6).
 * RS256 asymmetric verification means any service holding only the
 * public key can verify tokens without calling back to Identity —
 * this is what keeps token verification off the hot-path DB entirely.
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(configService: ConfigService) {
    const publicKeyPath = configService.get<string>('jwt.publicKeyPath')!;
    super({
      jwtFromRequest: ExtractJwtFromAuthHeader(),
      ignoreExpiration: false,
      secretOrKey: readFileSync(publicKeyPath, 'utf-8'),
      algorithms: ['RS256'],
    });
  }

  validate(payload: JwtAccessPayload): JwtAccessPayload {
    // Whatever is returned here becomes `request.user` in controllers.
    return payload;
  }
}

function ExtractJwtFromAuthHeader() {
  return ExtractJwt.fromAuthHeaderAsBearerToken();
}
