import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsOptional, IsString, Matches, MinLength } from 'class-validator';

export class RegisterDto {
  @ApiProperty({ example: 'jane_doe' })
  @IsString()
  @Matches(/^[a-zA-Z0-9_]{3,32}$/, {
    message: 'username must be 3-32 characters, alphanumeric or underscore',
  })
  username!: string;

  @ApiProperty({ example: 'jane@example.com', required: false })
  @IsOptional()
  @IsEmail()
  email?: string;

  @ApiProperty({ example: '+15551234567', required: false })
  @IsOptional()
  @IsString()
  @Matches(/^\+[1-9]\d{6,14}$/, { message: 'phone must be E.164 format' })
  phone?: string;

  @ApiProperty({ example: 'Str0ngPassw0rd!' })
  @IsString()
  @MinLength(10)
  password!: string;

  @ApiProperty({ example: 'Jane Doe' })
  @IsString()
  @MinLength(1)
  displayName!: string;
}
