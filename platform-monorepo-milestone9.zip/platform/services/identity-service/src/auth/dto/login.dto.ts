import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class LoginDto {
  @ApiProperty({
    example: 'jane@example.com',
    required: false,
    description: 'Email or phone',
  })
  @IsOptional()
  @IsString()
  email?: string;

  @IsOptional()
  @IsString()
  phone?: string;

  @ApiProperty()
  @IsString()
  password!: string;
}
