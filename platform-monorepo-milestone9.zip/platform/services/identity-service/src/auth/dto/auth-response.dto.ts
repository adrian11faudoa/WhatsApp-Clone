import { ApiProperty } from '@nestjs/swagger';

export class AuthResponseDto {
  @ApiProperty()
  accessToken!: string;

  @ApiProperty()
  refreshToken!: string;

  @ApiProperty()
  expiresIn!: number;
}

export class MfaChallengeResponseDto {
  @ApiProperty()
  challengeId!: string;

  @ApiProperty({ example: 'mfa_required' })
  status!: string;
}
