import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as argon2 from 'argon2';

import { AuthService } from './auth.service';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';

// AuthService reads key files from disk in its constructor (RS256 keys)
// so we mock `fs.readFileSync` for this unit test rather than requiring
// real key material on the test runner.
jest.mock('fs', () => ({
  ...jest.requireActual('fs'),
  readFileSync: jest
    .fn()
    .mockReturnValue('-----BEGIN PRIVATE KEY-----\nmock\n-----END PRIVATE KEY-----'),
}));

describe('AuthService', () => {
  let service: AuthService;
  let prisma: {
    user: { findFirst: jest.Mock; create: jest.Mock };
    credentials: { update: jest.Mock };
    device: { create: jest.Mock };
    session: { create: jest.Mock; update: jest.Mock };
    refreshToken: { findUnique: jest.Mock; findFirst: jest.Mock; create: jest.Mock };
  };
  let kafkaProducer: { publish: jest.Mock };

  beforeEach(async () => {
    prisma = {
      user: { findFirst: jest.fn(), create: jest.fn() },
      credentials: { update: jest.fn() },
      device: { create: jest.fn() },
      session: { create: jest.fn(), update: jest.fn() },
      refreshToken: { findUnique: jest.fn(), findFirst: jest.fn(), create: jest.fn() },
    };
    kafkaProducer = { publish: jest.fn().mockResolvedValue(undefined) };

    const configValues: Record<string, unknown> = {
      'jwt.privateKeyPath': './keys/jwt-private.pem',
      'jwt.publicKeyPath': './keys/jwt-public.pem',
      'jwt.accessTtlSeconds': 900,
      'jwt.refreshTtlSeconds': 2592000,
      'jwt.keyId': 'test-key',
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: prisma },
        { provide: KafkaProducerService, useValue: kafkaProducer },
        {
          provide: JwtService,
          useValue: { sign: jest.fn().mockReturnValue('signed.jwt.token') },
        },
        {
          provide: ConfigService,
          useValue: { get: jest.fn((key: string) => configValues[key]) },
        },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
  });

  describe('register', () => {
    it('throws ConflictException when username already exists', async () => {
      prisma.user.findFirst.mockResolvedValue({ id: 'existing-user' });

      await expect(
        service.register({
          username: 'jane_doe',
          email: 'jane@example.com',
          password: 'Str0ngPassw0rd',
          displayName: 'Jane Doe',
        }),
      ).rejects.toThrow(ConflictException);

      expect(prisma.user.create).not.toHaveBeenCalled();
    });

    it('creates a user and publishes identity.user.registered on success', async () => {
      prisma.user.findFirst.mockResolvedValue(null);
      prisma.user.create.mockResolvedValue({
        id: 'new-user-id',
        accountType: 'human',
        createdAt: new Date('2026-01-01T00:00:00Z'),
      });

      const result = await service.register({
        username: 'jane_doe',
        email: 'jane@example.com',
        password: 'Str0ngPassw0rd',
        displayName: 'Jane Doe',
      });

      expect(result).toEqual({ userId: 'new-user-id' });
      expect(kafkaProducer.publish).toHaveBeenCalledWith(
        'identity.user.registered',
        expect.objectContaining({ eventType: 'identity.user.registered' }),
      );
    });
  });

  describe('login', () => {
    it('throws UnauthorizedException for a nonexistent user without leaking which field was wrong', async () => {
      prisma.user.findFirst.mockResolvedValue(null);

      await expect(
        service.login(
          { email: 'nobody@example.com', password: 'whatever' },
          { platform: 'web' },
        ),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('throws UnauthorizedException and increments failedAttempts on wrong password', async () => {
      const passwordHash = await argon2.hash('CorrectPassw0rd', {
        type: argon2.argon2id,
      });
      prisma.user.findFirst.mockResolvedValue({
        id: 'user-1',
        username: 'jane_doe',
        accountType: 'human',
        status: 'active',
        credentials: { passwordHash, failedAttempts: 0, lockedUntil: null },
      });

      await expect(
        service.login(
          { email: 'jane@example.com', password: 'WrongPassword' },
          { platform: 'web' },
        ),
      ).rejects.toThrow(UnauthorizedException);

      expect(prisma.credentials.update).toHaveBeenCalledWith({
        where: { userId: 'user-1' },
        data: { failedAttempts: 1, lockedUntil: null },
      });
    });

    it('issues tokens on successful login', async () => {
      const passwordHash = await argon2.hash('CorrectPassw0rd', {
        type: argon2.argon2id,
      });
      prisma.user.findFirst.mockResolvedValue({
        id: 'user-1',
        username: 'jane_doe',
        accountType: 'human',
        status: 'active',
        credentials: { passwordHash, failedAttempts: 2, lockedUntil: null },
      });
      prisma.device.create.mockResolvedValue({ id: 'device-1' });
      prisma.session.create.mockResolvedValue({ id: 'session-1' });

      const result = await service.login(
        { email: 'jane@example.com', password: 'CorrectPassw0rd' },
        { platform: 'web', ipAddress: '127.0.0.1' },
      );

      expect(result.accessToken).toBe('signed.jwt.token');
      expect(result.refreshToken).toBeDefined();
      expect(prisma.credentials.update).toHaveBeenCalledWith({
        where: { userId: 'user-1' },
        data: { failedAttempts: 0, lockedUntil: null },
      });
    });
  });

  describe('refresh', () => {
    it('detects reuse of an already-rotated refresh token and revokes the session', async () => {
      prisma.refreshToken.findUnique.mockResolvedValue({
        id: 'token-1',
        sessionId: 'session-1',
        expiresAt: new Date(Date.now() + 100_000),
        session: { userId: 'user-1' },
      });
      // A child token exists -> this token was already rotated -> reuse.
      prisma.refreshToken.findFirst.mockResolvedValue({
        id: 'token-2',
        rotatedFromId: 'token-1',
      });

      await expect(service.refresh('some-raw-token')).rejects.toThrow(
        UnauthorizedException,
      );

      expect(prisma.session.update).toHaveBeenCalledWith({
        where: { id: 'session-1' },
        data: { revokedAt: expect.any(Date) },
      });
      expect(kafkaProducer.publish).toHaveBeenCalledWith(
        'auth.session.revoked',
        expect.objectContaining({
          payload: expect.objectContaining({ reason: 'reuse_detected' }),
        }),
      );
    });
  });
});
