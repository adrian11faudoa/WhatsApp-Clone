export interface AppConfig {
  nodeEnv: string;
  port: number;
  database: { url: string };
  jwt: {
    accessTtlSeconds: number;
    refreshTtlSeconds: number;
    privateKeyPath: string;
    publicKeyPath: string;
    keyId: string;
  };
  kafka: { brokers: string[]; clientId: string };
  rateLimit: { ttlSeconds: number; max: number };
}

export default (): AppConfig => ({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: parseInt(process.env.PORT ?? '3001', 10),
  database: {
    url: process.env.DATABASE_URL ?? '',
  },
  jwt: {
    accessTtlSeconds: parseInt(process.env.JWT_ACCESS_TTL_SECONDS ?? '900', 10),
    refreshTtlSeconds: parseInt(process.env.JWT_REFRESH_TTL_SECONDS ?? '2592000', 10),
    privateKeyPath: process.env.JWT_PRIVATE_KEY_PATH ?? './keys/jwt-private.pem',
    publicKeyPath: process.env.JWT_PUBLIC_KEY_PATH ?? './keys/jwt-public.pem',
    keyId: process.env.JWT_KEY_ID ?? 'default',
  },
  kafka: {
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    clientId: process.env.KAFKA_CLIENT_ID ?? 'identity-service',
  },
  rateLimit: {
    ttlSeconds: parseInt(process.env.RATE_LIMIT_TTL_SECONDS ?? '60', 10),
    max: parseInt(process.env.RATE_LIMIT_MAX ?? '100', 10),
  },
});
