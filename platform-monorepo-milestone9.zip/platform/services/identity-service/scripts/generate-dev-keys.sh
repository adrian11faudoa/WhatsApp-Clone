#!/usr/bin/env bash
# Generates a local RS256 keypair for JWT signing in development only.
# Production keys are issued and rotated via Vault (Volume 3 Section 5.6) —
# this script exists purely so `docker-compose up` works out of the box.
set -euo pipefail
mkdir -p "$(dirname "$0")/../keys"
cd "$(dirname "$0")/../keys"
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out jwt-private.pem
openssl rsa -pubout -in jwt-private.pem -out jwt-public.pem
echo "Generated keys/jwt-private.pem and keys/jwt-public.pem (dev only — never commit these)"
