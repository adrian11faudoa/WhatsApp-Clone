# Identity Service

Owns the **Identity, Authentication, Authorization, Device, and Session**
bounded context — see `architecture-phase1-vol1.md` Section 4 for the
full domain boundary rationale and `architecture-phase1-mvp-addendum.md`
for why this is Phase 2 Milestone 1.

## What this service does

- User registration, login, MFA-ready login flow
- Device push-token registration (`PUT /api/v1/devices/me/push-token`,
  Milestone 9) — publishes `identity.device.push_token_registered` so
  `notification-service` can maintain its own device-token read-model
  without this service exposing a synchronous device-lookup endpoint
- RS256 JWT access tokens (15 min TTL) + rotating refresh tokens with
  reuse detection (Volume 2 Section 6)
- Session/device tracking
- Publishes `identity.*` and `auth.*` domain events to Kafka (Volume 2 Section 2.1)

## Architecture layering

```
src/
├── domain/          # Pure business rules — Email/Password VOs, AccountLockoutPolicy.
│                     Zero I/O, zero framework imports, fully unit-testable without mocks.
├── auth/, users/     # Application layer (use-case orchestration) + HTTP/DTO layer.
│                     Contains NO business rules — see Volume 1 Section 5.3's boundary rule.
├── infrastructure/   # Prisma, Vault, Kafka adapters — the only place framework/I/O code lives.
└── common/           # Cross-cutting: guards, filters, interceptors, decorators.
```

If you find business logic (an `if` expressing a rule, not a flow-control check) inside
`auth.service.ts` or `users.service.ts`, it's misplaced — it belongs in `domain/`.

## Local development

```bash
cp .env.example .env
./scripts/generate-dev-keys.sh      # local-only RS256 keypair
docker-compose up --build
npx prisma migrate dev              # first run only, applies schema.prisma
```

Service listens on `:3001`. Swagger UI at `/api/docs`. Health checks at
`/health/live` (liveness) and `/health/ready` (readiness — checks DB connectivity).

## Testing

```bash
npm test                # unit tests — domain layer runs with zero mocks
npm run test:cov        # with coverage report
npm run test:e2e        # full HTTP-level tests against a real Nest app instance
```

CI (`.github/workflows/ci.yml`) runs lint → unit → integration (real Postgres +
Redpanda via GitHub Actions services) → container build + Trivy vulnerability
scan, matching the pipeline stages in `architecture-phase1-vol3.md` Section 5.4.

## What's deliberately NOT in this milestone

- MFA enrollment/verification endpoints (schema and `mfa_devices` table exist;
  endpoints are Milestone 2 — Volume 3's MVP cut-line doesn't gate launch on this)
- OAuth social login (`oauth_identities` table exists, provider flows are Milestone 2)
- Full RBAC/policy-engine authorization (this milestone is authentication only;
  the Authorization Service consuming `identity.user.*` events is a separate deployable
  per Volume 1 Section 4.1)

## Contract references

- Data model: `architecture-phase1-vol2.md` Section 1.1
- Events published: `architecture-phase1-vol2.md` Section 2.1
- API conventions: `architecture-phase1-vol2.md` Section 3.1, endpoints in Section 3.3
- Security model (JWT/refresh/lockout): `architecture-phase1-vol2.md` Section 6
