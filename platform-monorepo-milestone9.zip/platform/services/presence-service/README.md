# Presence Service

Owns the **Presence and Device** bounded context — Phase 2 Milestone 4,
completing the four MVP deployables from
`architecture-phase1-mvp-addendum.md` (Identity+Auth → Messaging → Media
→ **Presence**).

## What this service does

- Tracks online/away/offline status per user via WebSocket connect/
  disconnect (namespace `/presence`) — no client polling, per
  `architecture-phase1-vol3.md` Section 7
- `GET /api/v1/presence/{userId}` for server-to-server and one-off lookups
  (e.g. Messaging's `DeliveryPolicy` checking who's online)
- Consumes `auth.session.revoked` from Identity (Kafka) to force a user
  offline when a session is revoked server-side, even before their WS
  connection notices

## Why there's no database

Presence is inherently ephemeral — per `architecture-phase1-vol1.md`
Section 7's CQRS scope decision, **Redis IS the read model**, not a cache
in front of one. There is no Postgres for this service, no Prisma, no
migrations. This is the one deployable in the MVP set that's genuinely
simpler than the others, not a corner cut.

## Architecture layering

```
src/domain/     # PresenceStatusPolicy — online/away/offline derivation. Zero I/O.
src/presence/    # Application layer (PresenceService) + HTTP (PresenceController)
                   + WS (PresenceGateway) + the Kafka consumer wiring
                   (SessionEventsConsumer).
src/infrastructure/ # RedisService (the actual data store), KafkaConsumerService
                       (generic — this is the platform's first consumer;
                       Identity and Messaging only produce).
```

## A cross-service correction made while building this

Building this service's `SessionEventsConsumer` surfaced a real contract
gap in `identity-service`: its `auth.session.revoked` event didn't carry
`userId` in two of its three call sites — fine as long as nothing
consumed the event, but this service is exactly that consumer. Fixed at
the source (`identity-service/src/auth/auth.service.ts` and
`auth.controller.ts`) rather than worked around here — the corrected
`identity-service-milestone1.zip` reflects this. This is the kind of gap
integration tests across services (not just per-service unit tests) exist
to catch; noted here since it's a good example of why.

## Known gap, not silently assumed away

If a pod crashes without a clean WS disconnect, that session's Redis
entry is never removed — no reconciliation sweep exists yet to clear
orphaned session ids. For MVP scale this is a minor accuracy issue (a
user might appear online slightly longer than they are); at production
scale it needs a scheduled sweep or session TTL-refresh pattern. Flagged
rather than fixed silently, since "just add a TTL" has real trade-offs
against the heartbeat-based away-detection this service already does.

## Local development

```bash
cp .env.example .env
mkdir -p keys && cp ../identity-service/keys/jwt-public.pem keys/
docker-compose up --build
```

HTTP + Swagger on `:3004` (`/api/docs`). WS namespace `/presence` on the
same port.

## Testing

```bash
npm test          # unit — PresenceStatusPolicy (zero mocks) + PresenceService (mocked Redis)
npm run test:cov
npm run test:e2e
```

## Contract references

- CQRS scope decision (why no DB): `architecture-phase1-vol1.md` Section 7
- Presence as a consumer of `auth.session.*`: `architecture-phase1-vol2.md` Section 2.1
- No-polling design rule: `architecture-phase1-vol3.md` Section 7
