export interface AppConfig {
  nodeEnv: string;
  port: number;
  jwt: { publicKeyPath: string };
  kafka: { brokers: string[]; clientId: string; consumerGroup: string };
  redis: { url: string };
  awayAfterSeconds: number;
}

export default (): AppConfig => ({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: parseInt(process.env.PORT ?? '3004', 10),
  jwt: { publicKeyPath: process.env.JWT_PUBLIC_KEY_PATH ?? './keys/jwt-public.pem' },
  kafka: {
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    clientId: process.env.KAFKA_CLIENT_ID ?? 'presence-service',
    consumerGroup: process.env.KAFKA_CONSUMER_GROUP ?? 'presence-service-group',
  },
  redis: { url: process.env.REDIS_URL ?? 'redis://localhost:6379' },
  awayAfterSeconds: parseInt(process.env.AWAY_AFTER_SECONDS ?? '300', 10),
});
