import { Controller, Get } from '@nestjs/common';
import { HealthCheckService, HealthCheck, HealthIndicatorResult } from '@nestjs/terminus';
import { Public } from '../common/decorators/public.decorator';
import { RedisService } from '../infrastructure/redis/redis.service';

/**
 * No PrismaHealthIndicator here — this service has no Postgres (Volume 1
 * Sec 7). Readiness is Redis reachability instead, checked directly
 * rather than via a Terminus built-in indicator (Terminus doesn't ship
 * one for ioredis specifically).
 */
@Controller('health')
export class HealthController {
  constructor(
    private readonly health: HealthCheckService,
    private readonly redis: RedisService,
  ) {}

  @Public()
  @Get('live')
  live(): { status: string } {
    return { status: 'ok' };
  }

  @Public()
  @Get('ready')
  @HealthCheck()
  ready() {
    return this.health.check([
      async (): Promise<HealthIndicatorResult> => {
        try {
          await this.redis.client.ping();
          return { redis: { status: 'up' } };
        } catch (err) {
          return { redis: { status: 'down', message: (err as Error).message } };
        }
      },
    ]);
  }
}
