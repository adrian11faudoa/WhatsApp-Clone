import { PresenceStatusPolicy } from './presence-status.policy';

describe('PresenceStatusPolicy', () => {
  const awayAfterSeconds = 300;

  it('returns offline when there are no active sessions', () => {
    expect(PresenceStatusPolicy.derive(0, new Date(), awayAfterSeconds)).toBe('offline');
  });

  it('returns online for an active session with no recorded activity yet', () => {
    expect(PresenceStatusPolicy.derive(1, null, awayAfterSeconds)).toBe('online');
  });

  it('returns online when last activity is within the away threshold', () => {
    const now = new Date('2026-01-01T00:10:00Z');
    const lastActivity = new Date('2026-01-01T00:08:00Z'); // 2 min ago
    expect(PresenceStatusPolicy.derive(1, lastActivity, awayAfterSeconds, now)).toBe(
      'online',
    );
  });

  it('returns away when last activity exceeds the away threshold', () => {
    const now = new Date('2026-01-01T00:10:00Z');
    const lastActivity = new Date('2026-01-01T00:00:00Z'); // 10 min ago
    expect(PresenceStatusPolicy.derive(1, lastActivity, awayAfterSeconds, now)).toBe(
      'away',
    );
  });

  it('ignores activity staleness entirely once sessions drop to zero', () => {
    const now = new Date('2026-01-01T00:10:00Z');
    const recentActivity = new Date('2026-01-01T00:09:59Z');
    expect(PresenceStatusPolicy.derive(0, recentActivity, awayAfterSeconds, now)).toBe(
      'offline',
    );
  });
});
