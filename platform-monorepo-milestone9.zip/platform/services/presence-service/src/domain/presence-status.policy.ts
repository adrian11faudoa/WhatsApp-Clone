export type PresenceStatus = 'online' | 'away' | 'offline';

/**
 * Domain Service: derives a user's presence status from raw session/
 * activity data. Pure — no Redis import — per architecture-phase1-vol1.md
 * Section 5.3. The Application layer (PresenceService) is responsible for
 * fetching sessionCount and lastActivityAt from Redis and calling this.
 *
 * Presence itself has no separate read model (architecture-phase1-vol1.md
 * Section 7's CQRS scope decision: "Presence — write = ephemeral Redis;
 * there is no separate read model, it IS the read model") — this policy
 * is the only "business logic" presence has; everything else is I/O.
 */
export class PresenceStatusPolicy {
  static derive(
    activeSessionCount: number,
    lastActivityAt: Date | null,
    awayAfterSeconds: number,
    now: Date = new Date(),
  ): PresenceStatus {
    if (activeSessionCount === 0) {
      return 'offline';
    }
    if (lastActivityAt === null) {
      // Has an active session but we've never recorded activity for it
      // (e.g. immediately after connect) — treat as online, not away.
      return 'online';
    }
    const idleSeconds = (now.getTime() - lastActivityAt.getTime()) / 1000;
    return idleSeconds > awayAfterSeconds ? 'away' : 'online';
  }
}
