import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

/**
 * Redis IS the presence data store — there is no Postgres for this
 * service (architecture-phase1-vol1.md Section 7). Keys:
 *   presence:{userId}:sessions   -> Set of socket/session ids
 *   presence:{userId}:activity   -> String, ISO timestamp of last activity
 * Session entries carry no independent TTL — they are removed explicitly
 * on disconnect. If a pod crashes without a clean disconnect, a
 * reconciliation sweep (not built in this milestone — see README) is
 * responsible for clearing orphaned entries; noted rather than silently
 * assumed away.
 */
@Injectable()
export class RedisService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(RedisService.name);
  public client!: Redis;

  constructor(private readonly configService: ConfigService) {}

  onModuleInit(): void {
    this.client = new Redis(this.configService.get<string>('redis.url')!, {
      lazyConnect: false,
      maxRetriesPerRequest: 3,
    });
    this.client.on('error', (err) => this.logger.error('Redis error', err));
  }

  async onModuleDestroy(): Promise<void> {
    await this.client.quit();
  }

  async addSession(userId: string, sessionId: string): Promise<void> {
    await this.client.sadd(`presence:${userId}:sessions`, sessionId);
    await this.touchActivity(userId);
  }

  async removeSession(userId: string, sessionId: string): Promise<void> {
    await this.client.srem(`presence:${userId}:sessions`, sessionId);
  }

  async getActiveSessionCount(userId: string): Promise<number> {
    return this.client.scard(`presence:${userId}:sessions`);
  }

  async getActiveSessionIds(userId: string): Promise<string[]> {
    return this.client.smembers(`presence:${userId}:sessions`);
  }

  async touchActivity(userId: string): Promise<void> {
    await this.client.set(`presence:${userId}:activity`, new Date().toISOString());
  }

  async getLastActivity(userId: string): Promise<Date | null> {
    const value = await this.client.get(`presence:${userId}:activity`);
    return value ? new Date(value) : null;
  }

  /** Removes ALL sessions for a user — used on forced logout/session-revoked. */
  async clearAllSessions(userId: string): Promise<void> {
    await this.client.del(`presence:${userId}:sessions`);
  }
}
