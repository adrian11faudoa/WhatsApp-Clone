import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { readFileSync } from 'fs';

import { PresenceService } from './presence.service';

interface AuthenticatedSocket extends Socket {
  data: { userId: string };
}

/**
 * Socket.IO namespace /presence. Connection = session opened; disconnect =
 * session closed. A "heartbeat" event lets long-lived idle connections
 * refresh their activity timestamp without a full reconnect, which is
 * what PresenceStatusPolicy's online/away distinction depends on.
 *
 * On presence change, broadcasts to a per-user room so any other service/
 * client that has joined `presence:{userId}` (e.g. Messaging's own gateway,
 * subscribing server-side to know when to flush an offline queue) gets a
 * push update — consistent with Volume 3 Sec 7's "push-only, no polling."
 */
@WebSocketGateway({ namespace: '/presence', cors: { origin: true, credentials: true } })
export class PresenceGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(PresenceGateway.name);
  private readonly jwtPublicKey: string;

  constructor(
    private readonly presenceService: PresenceService,
    private readonly jwtService: JwtService,
    configService: ConfigService,
  ) {
    this.jwtPublicKey = readFileSync(
      configService.get<string>('jwt.publicKeyPath')!,
      'utf-8',
    );
  }

  async handleConnection(socket: AuthenticatedSocket): Promise<void> {
    const token = this.extractToken(socket);
    if (!token) {
      socket.disconnect(true);
      return;
    }

    try {
      const payload = this.jwtService.verify<{ sub: string }>(token, {
        publicKey: this.jwtPublicKey,
        algorithms: ['RS256'],
      });
      socket.data.userId = payload.sub;

      await this.presenceService.onSessionOpened(payload.sub, socket.id);
      await this.broadcastStatus(payload.sub);
      this.logger.log(`Presence session opened: user=${payload.sub} socket=${socket.id}`);
    } catch (err) {
      this.logger.warn(`Presence WS auth failed: ${(err as Error).message}`);
      socket.disconnect(true);
    }
  }

  async handleDisconnect(socket: AuthenticatedSocket): Promise<void> {
    if (!socket.data?.userId) return;
    await this.presenceService.onSessionClosed(socket.data.userId, socket.id);
    await this.broadcastStatus(socket.data.userId);
  }

  @SubscribeMessage('heartbeat')
  async onHeartbeat(@ConnectedSocket() socket: AuthenticatedSocket): Promise<void> {
    if (!socket.data?.userId) return;
    await this.presenceService.recordActivity(socket.data.userId);
  }

  @SubscribeMessage('presence:subscribe')
  async onSubscribe(
    @ConnectedSocket() socket: AuthenticatedSocket,
    ...args: unknown[]
  ): Promise<void> {
    const data = args[0] as { userId: string };
    await socket.join(this.roomName(data.userId));
  }

  private async broadcastStatus(userId: string): Promise<void> {
    const status = await this.presenceService.getStatus(userId);
    this.server.to(this.roomName(userId)).emit('presence:update', status);
  }

  private roomName(userId: string): string {
    return `presence:${userId}`;
  }

  private extractToken(socket: Socket): string | null {
    const authToken = socket.handshake.auth?.token as string | undefined;
    if (authToken) return authToken;
    return socket.handshake.headers.authorization?.replace('Bearer ', '') ?? null;
  }
}
