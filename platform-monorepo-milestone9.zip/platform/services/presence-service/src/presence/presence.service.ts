import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { RedisService } from '../infrastructure/redis/redis.service';
import { PresenceStatusPolicy } from '../domain/presence-status.policy';

/**
 * Application Service. Loads raw session/activity data from Redis (the
 * source of truth — Volume 1 Sec 7) and calls the pure PresenceStatusPolicy
 * to derive the status a caller actually wants. No business rules here.
 */
@Injectable()
export class PresenceService {
  private readonly awayAfterSeconds: number;

  constructor(
    private readonly redis: RedisService,
    configService: ConfigService,
  ) {
    this.awayAfterSeconds = configService.get<number>('awayAfterSeconds')!;
  }

  async getStatus(userId: string) {
    const [sessionCount, lastActivityAt] = await Promise.all([
      this.redis.getActiveSessionCount(userId),
      this.redis.getLastActivity(userId),
    ]);

    const status = PresenceStatusPolicy.derive(
      sessionCount,
      lastActivityAt,
      this.awayAfterSeconds,
    );

    return { userId, status, lastActivityAt: lastActivityAt?.toISOString() ?? null };
  }

  async onSessionOpened(userId: string, sessionId: string): Promise<void> {
    await this.redis.addSession(userId, sessionId);
  }

  async onSessionClosed(userId: string, sessionId: string): Promise<void> {
    await this.redis.removeSession(userId, sessionId);
  }

  async recordActivity(userId: string): Promise<void> {
    await this.redis.touchActivity(userId);
  }

  /** Invoked when Identity publishes auth.session.revoked (forced logout, reuse-detection, admin action). */
  async forceOffline(userId: string): Promise<void> {
    await this.redis.clearAllSessions(userId);
  }
}
