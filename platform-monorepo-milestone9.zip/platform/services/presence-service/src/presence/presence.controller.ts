import { Controller, Get, Param } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { PresenceService } from './presence.service';
import { PresenceResponseDto } from './dto/presence-response.dto';

/**
 * Only a GET endpoint exists here deliberately — per
 * architecture-phase1-vol3.md Section 7: "No polling encouraged in
 * clients — presence is push-only over WS to avoid the thundering-herd
 * polling pattern at this user count." This endpoint exists for
 * server-to-server lookups (e.g. Messaging's DeliveryPolicy checking
 * online sessions) and one-off client queries, not for client polling loops.
 */
@ApiTags('presence')
@Controller('api/v1/presence')
export class PresenceController {
  constructor(private readonly presenceService: PresenceService) {}

  @Get(':userId')
  @ApiOperation({ summary: 'Get current presence status for a user' })
  async getStatus(@Param('userId') userId: string): Promise<PresenceResponseDto> {
    return this.presenceService.getStatus(userId);
  }
}
