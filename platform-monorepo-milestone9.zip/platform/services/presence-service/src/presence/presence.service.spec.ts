import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { PresenceService } from './presence.service';
import { RedisService } from '../infrastructure/redis/redis.service';

describe('PresenceService', () => {
  let service: PresenceService;
  let redis: {
    getActiveSessionCount: jest.Mock;
    getLastActivity: jest.Mock;
    addSession: jest.Mock;
    removeSession: jest.Mock;
    touchActivity: jest.Mock;
    clearAllSessions: jest.Mock;
  };

  beforeEach(async () => {
    redis = {
      getActiveSessionCount: jest.fn(),
      getLastActivity: jest.fn(),
      addSession: jest.fn(),
      removeSession: jest.fn(),
      touchActivity: jest.fn(),
      clearAllSessions: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PresenceService,
        { provide: RedisService, useValue: redis },
        {
          provide: ConfigService,
          useValue: { get: jest.fn().mockReturnValue(300) },
        },
      ],
    }).compile();

    service = module.get<PresenceService>(PresenceService);
  });

  describe('getStatus', () => {
    it('reports offline when there are no active sessions', async () => {
      redis.getActiveSessionCount.mockResolvedValue(0);
      redis.getLastActivity.mockResolvedValue(null);

      const result = await service.getStatus('user-1');

      expect(result).toEqual({
        userId: 'user-1',
        status: 'offline',
        lastActivityAt: null,
      });
    });

    it('reports online for an active session with recent activity', async () => {
      const recentActivity = new Date();
      redis.getActiveSessionCount.mockResolvedValue(1);
      redis.getLastActivity.mockResolvedValue(recentActivity);

      const result = await service.getStatus('user-1');

      expect(result.status).toBe('online');
      expect(result.lastActivityAt).toBe(recentActivity.toISOString());
    });

    it('reports away for an active session with stale activity', async () => {
      const staleActivity = new Date(Date.now() - 10 * 60_000); // 10 min ago, threshold is 300s
      redis.getActiveSessionCount.mockResolvedValue(1);
      redis.getLastActivity.mockResolvedValue(staleActivity);

      const result = await service.getStatus('user-1');

      expect(result.status).toBe('away');
    });
  });

  describe('onSessionOpened / onSessionClosed', () => {
    it('delegates to RedisService.addSession', async () => {
      await service.onSessionOpened('user-1', 'socket-1');
      expect(redis.addSession).toHaveBeenCalledWith('user-1', 'socket-1');
    });

    it('delegates to RedisService.removeSession', async () => {
      await service.onSessionClosed('user-1', 'socket-1');
      expect(redis.removeSession).toHaveBeenCalledWith('user-1', 'socket-1');
    });
  });

  describe('forceOffline', () => {
    it('clears all sessions for the user', async () => {
      await service.forceOffline('user-1');
      expect(redis.clearAllSessions).toHaveBeenCalledWith('user-1');
    });
  });
});
