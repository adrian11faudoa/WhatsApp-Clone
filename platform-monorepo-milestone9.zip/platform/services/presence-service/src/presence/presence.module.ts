import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';

import { PresenceController } from './presence.controller';
import { PresenceService } from './presence.service';
import { PresenceGateway } from './presence.gateway';
import { SessionEventsConsumer } from './session-events.consumer';

@Module({
  imports: [JwtModule.register({})],
  controllers: [PresenceController],
  providers: [PresenceService, PresenceGateway, SessionEventsConsumer],
})
export class PresenceModule {}
