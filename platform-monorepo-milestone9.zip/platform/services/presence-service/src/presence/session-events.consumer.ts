import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import {
  KafkaConsumerService,
  ConsumedEvent,
} from '../infrastructure/kafka/kafka-consumer.service';
import { PresenceService } from './presence.service';

/**
 * Subscribes to Identity's auth.session.revoked topic (Volume 2 Sec 2.1
 * explicitly lists Presence as a consumer of this event) and forces the
 * affected user offline in Redis — covers the case where a session is
 * revoked server-side (reuse-detection, admin suspend) while the client's
 * WS connection hasn't yet noticed/disconnected on its own.
 */
@Injectable()
export class SessionEventsConsumer implements OnModuleInit {
  private readonly logger = new Logger(SessionEventsConsumer.name);

  constructor(
    private readonly kafkaConsumer: KafkaConsumerService,
    private readonly presenceService: PresenceService,
  ) {}

  onModuleInit(): void {
    this.kafkaConsumer.registerHandler(
      'auth.session.revoked',
      async (event: ConsumedEvent) => {
        const payload = event.payload as { sessionId: string; userId?: string };
        if (!payload.userId) {
          this.logger.warn('auth.session.revoked event missing userId, skipping');
          return;
        }
        await this.presenceService.forceOffline(payload.userId);
        this.logger.log(
          `Forced offline for user ${payload.userId} due to session revocation`,
        );
      },
    );
  }
}
