import { ApiProperty } from '@nestjs/swagger';

export class PresenceResponseDto {
  @ApiProperty() userId!: string;
  @ApiProperty({ enum: ['online', 'away', 'offline'] }) status!: string;
  @ApiProperty({ required: false, nullable: true }) lastActivityAt!: string | null;
}
