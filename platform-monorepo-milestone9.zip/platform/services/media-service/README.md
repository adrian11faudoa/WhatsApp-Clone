# Media Service

Owns the **Media Upload, Media Processing, Voice Message** bounded
context — Phase 2 Milestone 3, per `architecture-phase1-mvp-addendum.md`'s
build order (Identity+Auth → Messaging → **Media** → Presence).

## What this service does

- Direct-to-S3 upload flow: client requests a presigned PUT URL, uploads
  directly to storage (never through this service's own request/response
  cycle), then confirms completion
- Async processing pipeline via BullMQ: virus scan + variant generation
  (thumbnails/transcodes/waveform depending on mime type)
- Publishes `media.upload.completed`, `media.processing.completed`,
  `media.scan.flagged` per `architecture-phase1-vol2.md` Section 2.4

## Architecture layering

```
src/domain/    # MediaUploadPolicy — allowed mime types, size limits, which
                 variants a mime type requires. Zero I/O.
src/media/      # Application layer (MediaService) + HTTP layer (MediaController)
                  + the BullMQ worker (MediaProcessingProcessor).
src/infrastructure/  # Prisma, Kafka, S3-compatible storage (MinIO locally).
```

## Scope note: what's real vs. what's a stand-in

The **pipeline orchestration is fully real**: job enqueueing, retry/backoff,
status transitions (`uploading` → `processing` → `ready`/`quarantined`),
variant record lifecycle, and event publishing all work exactly as
architected and are exercised by tests.

What's **not** real: actual virus-scan and transcode/thumbnail byte
processing — those need binaries (ClamAV, ffmpeg, sharp) this milestone's
codebase doesn't include. `MediaProcessingProcessor.runVirusScan()` and
`.generateVariant()` are the two isolated integration points where real
implementations plug in — see the comment block in
`src/media/media-processing.processor.ts` for exactly why this line was
drawn here rather than fudging it silently.

**Worker deployment:** the BullMQ worker runs in the same process as the
HTTP API in this milestone (`MediaProcessingProcessor` is a normal Nest
provider). Splitting it into a separately-scaled worker deployment is an
operational change for later — consistent with the "consolidated
deployables" MVP posture from `architecture-phase1-vol1.md` Section 9.

## Local development

```bash
cp .env.example .env
mkdir -p keys && cp ../identity-service/keys/jwt-public.pem keys/
docker-compose up --build   # spins up Postgres, Redis, Redpanda, and MinIO (S3-compatible)
npx prisma migrate dev
```

MinIO console at `http://localhost:9001` (minioadmin/minioadmin) if you
want to inspect uploaded objects directly.

## Testing

```bash
npm test          # unit — MediaUploadPolicy runs with zero mocks
npm run test:cov
npm run test:e2e
```

## Contract references

- Data model: `architecture-phase1-vol2.md` Section 1.5
- Events published: `architecture-phase1-vol2.md` Section 2.4
- Tech stack rationale (S3/CloudFront, BullMQ): `architecture-phase1-vol1.md` Section 1
