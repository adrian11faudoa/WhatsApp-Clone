export interface AppConfig {
  nodeEnv: string;
  port: number;
  database: { url: string };
  jwt: { publicKeyPath: string };
  kafka: { brokers: string[]; clientId: string };
  redis: { url: string };
  s3: {
    endpoint: string;
    region: string;
    bucket: string;
    accessKeyId: string;
    secretAccessKey: string;
    forcePathStyle: boolean;
  };
  maxUploadSizeBytes: number;
  presignedUrlTtlSeconds: number;
}

export default (): AppConfig => ({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: parseInt(process.env.PORT ?? '3003', 10),
  database: { url: process.env.DATABASE_URL ?? '' },
  jwt: { publicKeyPath: process.env.JWT_PUBLIC_KEY_PATH ?? './keys/jwt-public.pem' },
  kafka: {
    brokers: (process.env.KAFKA_BROKERS ?? 'localhost:9092').split(','),
    clientId: process.env.KAFKA_CLIENT_ID ?? 'media-service',
  },
  redis: { url: process.env.REDIS_URL ?? 'redis://localhost:6379' },
  s3: {
    endpoint: process.env.S3_ENDPOINT ?? 'http://localhost:9000',
    region: process.env.S3_REGION ?? 'us-east-1',
    bucket: process.env.S3_BUCKET ?? 'platform-media-dev',
    accessKeyId: process.env.S3_ACCESS_KEY_ID ?? 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? 'minioadmin',
    forcePathStyle: (process.env.S3_FORCE_PATH_STYLE ?? 'true') === 'true',
  },
  maxUploadSizeBytes: parseInt(process.env.MAX_UPLOAD_SIZE_BYTES ?? '104857600', 10),
  presignedUrlTtlSeconds: parseInt(process.env.PRESIGNED_URL_TTL_SECONDS ?? '300', 10),
});
