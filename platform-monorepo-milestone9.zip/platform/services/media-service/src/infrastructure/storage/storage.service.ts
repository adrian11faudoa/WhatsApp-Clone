import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { createHash } from 'crypto';

/**
 * S3-compatible storage adapter (MinIO locally, S3 + CloudFront in prod —
 * architecture-phase1-vol1.md Section 1). Storage keys are content-addressed
 * (sha256 of ownerId + timestamp + random, not of file bytes — content-hash
 * addressing of the bytes themselves would require buffering the whole
 * upload through this service, which direct-to-S3 presigned uploads
 * specifically avoid) so keys are unpredictable without being derived from
 * user-controllable input alone.
 */
@Injectable()
export class StorageService {
  private readonly client: S3Client;
  private readonly bucket: string;
  private readonly presignedUrlTtlSeconds: number;

  constructor(private readonly configService: ConfigService) {
    const s3Config = this.configService.get<{
      endpoint: string;
      region: string;
      bucket: string;
      accessKeyId: string;
      secretAccessKey: string;
      forcePathStyle: boolean;
    }>('s3')!;

    this.bucket = s3Config.bucket;
    this.presignedUrlTtlSeconds = this.configService.get<number>(
      'presignedUrlTtlSeconds',
    )!;

    this.client = new S3Client({
      endpoint: s3Config.endpoint,
      region: s3Config.region,
      forcePathStyle: s3Config.forcePathStyle,
      credentials: {
        accessKeyId: s3Config.accessKeyId,
        secretAccessKey: s3Config.secretAccessKey,
      },
    });
  }

  generateStorageKey(ownerId: string): string {
    const random = createHash('sha256')
      .update(`${ownerId}:${Date.now()}:${Math.random()}`)
      .digest('hex');
    return `media/${ownerId}/${random}`;
  }

  async getPresignedUploadUrl(storageKey: string, mimeType: string): Promise<string> {
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: storageKey,
      ContentType: mimeType,
    });
    return getSignedUrl(this.client, command, { expiresIn: this.presignedUrlTtlSeconds });
  }

  async getPresignedDownloadUrl(storageKey: string): Promise<string> {
    const command = new GetObjectCommand({ Bucket: this.bucket, Key: storageKey });
    return getSignedUrl(this.client, command, { expiresIn: this.presignedUrlTtlSeconds });
  }
}
