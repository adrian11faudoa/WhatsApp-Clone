import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { ConfigModule, ConfigService } from '@nestjs/config';

export const MEDIA_PROCESSING_QUEUE = 'media-processing';

/**
 * BullMQ queue for the async transcode/thumbnail/virus-scan pipeline —
 * architecture-phase1-vol1.md Section 1 ("Media Processing Service" is
 * worker-based, not inline in the request/response path, since a video
 * transcode can take much longer than an HTTP request should block for).
 */
@Module({
  imports: [
    BullModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        connection: { url: configService.get<string>('redis.url') },
      }),
    }),
    BullModule.registerQueue({ name: MEDIA_PROCESSING_QUEUE }),
  ],
  exports: [BullModule],
})
export class QueueModule {}
