import {
  CallHandler,
  ExecutionContext,
  Injectable,
  Logger,
  NestInterceptor,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { randomUUID } from 'crypto';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<Request>();
    const response = context.switchToHttp().getResponse<Response>();
    const traceId = (request.headers['x-trace-id'] as string) ?? randomUUID();
    request.headers['x-trace-id'] = traceId;
    response.setHeader('x-trace-id', traceId);
    const start = Date.now();
    const { method, url } = request;

    return next.handle().pipe(
      tap({
        next: () =>
          this.logger.log(
            JSON.stringify({
              traceId,
              method,
              url,
              statusCode: response.statusCode,
              durationMs: Date.now() - start,
            }),
          ),
        error: (err: Error) =>
          this.logger.error(
            JSON.stringify({
              traceId,
              method,
              url,
              statusCode: response.statusCode,
              durationMs: Date.now() - start,
              error: err.message,
            }),
          ),
      }),
    );
  }
}
