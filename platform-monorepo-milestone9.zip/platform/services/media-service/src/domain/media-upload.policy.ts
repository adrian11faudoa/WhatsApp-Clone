/**
 * Domain Service: decides whether a proposed upload is acceptable before
 * any storage I/O happens. Pure — no S3 client, no Prisma import — per
 * architecture-phase1-vol1.md Section 5.3's Domain/Application boundary.
 */

const ALLOWED_MIME_PREFIXES = ['image/', 'video/', 'audio/'] as const;
const ALLOWED_EXACT_MIME_TYPES = ['application/pdf'] as const;

export type MediaUploadRejectionReason = 'mime_type_not_allowed' | 'file_too_large';

export interface MediaUploadCheckResult {
  allowed: boolean;
  reason?: MediaUploadRejectionReason;
}

export class MediaUploadPolicy {
  static evaluate(
    mimeType: string,
    sizeBytes: number,
    maxUploadSizeBytes: number,
  ): MediaUploadCheckResult {
    const mimeAllowed =
      ALLOWED_MIME_PREFIXES.some((prefix) => mimeType.startsWith(prefix)) ||
      (ALLOWED_EXACT_MIME_TYPES as readonly string[]).includes(mimeType);

    if (!mimeAllowed) {
      return { allowed: false, reason: 'mime_type_not_allowed' };
    }
    if (sizeBytes > maxUploadSizeBytes) {
      return { allowed: false, reason: 'file_too_large' };
    }
    return { allowed: true };
  }

  /**
   * Determines which processing variants a given mime type should produce.
   * Pure lookup, no I/O — the actual transcode/thumbnail work happens in
   * the BullMQ processor (infrastructure layer), which calls this to know
   * *what* to produce, not *how*.
   */
  static requiredVariants(
    mimeType: string,
  ): Array<
    'thumbnail_sm' | 'thumbnail_lg' | 'transcode_720p' | 'transcode_1080p' | 'waveform'
  > {
    if (mimeType.startsWith('image/')) return ['thumbnail_sm', 'thumbnail_lg'];
    if (mimeType.startsWith('video/'))
      return ['thumbnail_sm', 'transcode_720p', 'transcode_1080p'];
    if (mimeType.startsWith('audio/')) return ['waveform'];
    return [];
  }
}
