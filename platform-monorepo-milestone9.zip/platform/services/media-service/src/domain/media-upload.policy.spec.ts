import { MediaUploadPolicy } from './media-upload.policy';

describe('MediaUploadPolicy', () => {
  const maxSize = 100 * 1024 * 1024; // 100MB

  describe('evaluate', () => {
    it.each(['image/png', 'image/jpeg', 'video/mp4', 'audio/mpeg', 'application/pdf'])(
      'allows a well-formed request for mime type %s within the size limit',
      (mimeType) => {
        const result = MediaUploadPolicy.evaluate(mimeType, 1024, maxSize);
        expect(result).toEqual({ allowed: true });
      },
    );

    it('rejects a disallowed mime type', () => {
      const result = MediaUploadPolicy.evaluate(
        'application/x-msdownload',
        1024,
        maxSize,
      );
      expect(result).toEqual({ allowed: false, reason: 'mime_type_not_allowed' });
    });

    it('rejects a file exceeding the size limit', () => {
      const result = MediaUploadPolicy.evaluate('image/png', maxSize + 1, maxSize);
      expect(result).toEqual({ allowed: false, reason: 'file_too_large' });
    });

    it('checks mime type before size (mime rejection takes precedence)', () => {
      const result = MediaUploadPolicy.evaluate(
        'application/x-msdownload',
        maxSize + 1,
        maxSize,
      );
      expect(result.reason).toBe('mime_type_not_allowed');
    });
  });

  describe('requiredVariants', () => {
    it('returns thumbnail variants for images', () => {
      expect(MediaUploadPolicy.requiredVariants('image/png')).toEqual([
        'thumbnail_sm',
        'thumbnail_lg',
      ]);
    });

    it('returns thumbnail + transcode variants for video', () => {
      expect(MediaUploadPolicy.requiredVariants('video/mp4')).toEqual([
        'thumbnail_sm',
        'transcode_720p',
        'transcode_1080p',
      ]);
    });

    it('returns waveform for audio', () => {
      expect(MediaUploadPolicy.requiredVariants('audio/mpeg')).toEqual(['waveform']);
    });

    it('returns an empty array for a type with no defined processing (e.g. pdf)', () => {
      expect(MediaUploadPolicy.requiredVariants('application/pdf')).toEqual([]);
    });
  });
});
