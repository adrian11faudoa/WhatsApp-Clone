import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';

import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { StorageService } from '../infrastructure/storage/storage.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { MediaUploadPolicy } from '../domain/media-upload.policy';
import { MEDIA_PROCESSING_QUEUE } from '../infrastructure/queue/queue.module';
import { InitiateUploadDto } from './dto/initiate-upload.dto';

/**
 * Application Service. Orchestrates: validate (domain policy) -> generate
 * storage key + presigned URL -> persist MediaObject(status=uploading) ->
 * (on completion callback) mark uploading->processing, publish
 * media.upload.completed, enqueue the processing job. No business rules
 * here — the allowed-mime/size-limit decision lives in MediaUploadPolicy.
 */
@Injectable()
export class MediaService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly storage: StorageService,
    private readonly kafkaProducer: KafkaProducerService,
    private readonly configService: ConfigService,
    @InjectQueue(MEDIA_PROCESSING_QUEUE) private readonly processingQueue: Queue,
  ) {}

  async initiateUpload(ownerId: string, dto: InitiateUploadDto) {
    const maxUploadSizeBytes = this.configService.get<number>('maxUploadSizeBytes')!;
    const check = MediaUploadPolicy.evaluate(
      dto.mimeType,
      dto.sizeBytes,
      maxUploadSizeBytes,
    );
    if (!check.allowed) {
      throw new BadRequestException({
        message: `Upload rejected: ${check.reason}`,
        errorCode: check.reason,
      });
    }

    const storageKey = this.storage.generateStorageKey(ownerId);

    const mediaObject = await this.prisma.mediaObject.create({
      data: {
        ownerId,
        storageKey,
        mimeType: dto.mimeType,
        sizeBytes: BigInt(dto.sizeBytes),
        status: 'uploading',
      },
    });

    const uploadUrl = await this.storage.getPresignedUploadUrl(storageKey, dto.mimeType);
    const ttl = this.configService.get<number>('presignedUrlTtlSeconds')!;

    return {
      mediaId: mediaObject.id,
      uploadUrl,
      storageKey,
      expiresInSeconds: ttl,
    };
  }

  /**
   * Called by the client once the direct-to-S3 upload succeeds. Transitions
   * uploading -> processing, publishes media.upload.completed (Volume 2
   * Sec 2.4), and enqueues the async processing job — mirrors the real
   * flow described there rather than pretending processing happens inline.
   */
  async completeUpload(mediaId: string, ownerId: string) {
    const mediaObject = await this.getOwnedMediaOrThrow(mediaId, ownerId);

    if (mediaObject.status !== 'uploading') {
      throw new BadRequestException({
        message: `Cannot complete upload from status ${mediaObject.status}`,
        errorCode: 'invalid_upload_state',
      });
    }

    const updated = await this.prisma.mediaObject.update({
      where: { id: mediaId },
      data: { status: 'processing' },
    });

    await this.kafkaProducer.publish('media.upload.completed', {
      eventType: 'media.upload.completed',
      key: mediaId,
      schemaVersion: 1,
      payload: { mediaId, ownerId, mimeType: updated.mimeType },
    });

    await this.processingQueue.add(
      'process-media',
      { mediaId, mimeType: updated.mimeType, storageKey: updated.storageKey },
      { attempts: 3, backoff: { type: 'exponential', delay: 5000 } },
    );

    return updated;
  }

  async getById(mediaId: string, requesterId: string) {
    const mediaObject = await this.getOwnedMediaOrThrow(mediaId, requesterId);
    const variants = await this.prisma.mediaVariant.findMany({
      where: { mediaObjectId: mediaId },
    });

    const downloadUrl =
      mediaObject.status === 'ready'
        ? await this.storage.getPresignedDownloadUrl(mediaObject.storageKey)
        : undefined;

    const variantUrls = await Promise.all(
      variants.map(async (v: { variantType: string; storageKey: string }) => ({
        variantType: v.variantType,
        url: await this.storage.getPresignedDownloadUrl(v.storageKey),
      })),
    );

    return { mediaObject, downloadUrl, variants: variantUrls };
  }

  private async getOwnedMediaOrThrow(mediaId: string, requesterId: string) {
    const mediaObject = await this.prisma.mediaObject.findUnique({
      where: { id: mediaId },
    });
    if (!mediaObject) {
      throw new NotFoundException({
        message: 'Media not found',
        errorCode: 'media_not_found',
      });
    }
    if (mediaObject.ownerId !== requesterId) {
      throw new ForbiddenException({
        message: 'Not the owner of this media object',
        errorCode: 'not_owner',
      });
    }
    return mediaObject;
  }
}
