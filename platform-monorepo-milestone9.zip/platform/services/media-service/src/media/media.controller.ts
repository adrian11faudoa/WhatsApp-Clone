import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';

import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtAccessPayload } from '../auth/strategies/jwt.strategy';
import { MediaService } from './media.service';
import { InitiateUploadDto, InitiateUploadResponseDto } from './dto/initiate-upload.dto';
import { MediaResponseDto } from './dto/media-response.dto';

@ApiTags('media')
@Controller('api/v1/media')
export class MediaController {
  constructor(private readonly mediaService: MediaService) {}

  @Post('uploads')
  @ApiOperation({
    summary: 'Initiate a direct-to-S3 upload, returns a presigned PUT URL',
  })
  async initiateUpload(
    @CurrentUser() user: JwtAccessPayload,
    @Body() dto: InitiateUploadDto,
  ): Promise<InitiateUploadResponseDto> {
    return this.mediaService.initiateUpload(user.sub, dto);
  }

  @Post('uploads/:mediaId/complete')
  @ApiOperation({
    summary: 'Confirm the direct upload finished; enqueues async processing',
  })
  async completeUpload(
    @Param('mediaId') mediaId: string,
    @CurrentUser() user: JwtAccessPayload,
  ) {
    return this.mediaService.completeUpload(mediaId, user.sub);
  }

  @Get(':mediaId')
  @ApiOperation({
    summary: 'Get media metadata + presigned download URLs for ready variants',
  })
  async getById(
    @Param('mediaId') mediaId: string,
    @CurrentUser() user: JwtAccessPayload,
  ): Promise<MediaResponseDto> {
    const { mediaObject, downloadUrl, variants } = await this.mediaService.getById(
      mediaId,
      user.sub,
    );
    return {
      id: mediaObject.id,
      status: mediaObject.status,
      mimeType: mediaObject.mimeType,
      downloadUrl,
      variants,
      createdAt: mediaObject.createdAt.toISOString(),
    };
  }
}
