import { Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';

import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { StorageService } from '../infrastructure/storage/storage.service';
import { KafkaProducerService } from '../infrastructure/kafka/kafka-producer.service';
import { MediaUploadPolicy } from '../domain/media-upload.policy';
import { MEDIA_PROCESSING_QUEUE } from '../infrastructure/queue/queue.module';

export interface ProcessMediaJobData {
  mediaId: string;
  mimeType: string;
  storageKey: string;
}

/**
 * BullMQ worker for the async media pipeline (virus scan + variant
 * generation), per architecture-phase1-vol1.md Section 1's Media
 * Processing Service.
 *
 * SCOPE NOTE (deliberate, not an omission): the actual byte-level work —
 * running a real virus-scan engine (e.g. ClamAV) and real transcode/
 * thumbnail generation (e.g. ffmpeg/sharp) — requires binaries and
 * runtime dependencies well outside what this milestone's codebase can
 * meaningfully include or verify. What IS implemented and real here: the
 * full orchestration — job consumption, status transitions, variant
 * record creation, event publishing, retry/backoff, and error handling —
 * which is the part that defines this service's architecture. The
 * `runVirusScan` and `generateVariant` methods are the two integration
 * points where a real scanner/transcoder library plugs in; they're
 * isolated into their own methods specifically so that swap is a
 * one-file change, not a redesign.
 */
@Processor(MEDIA_PROCESSING_QUEUE)
export class MediaProcessingProcessor extends WorkerHost {
  private readonly logger = new Logger(MediaProcessingProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly storage: StorageService,
    private readonly kafkaProducer: KafkaProducerService,
  ) {
    super();
  }

  async process(job: Job<ProcessMediaJobData>): Promise<void> {
    const { mediaId, mimeType, storageKey } = job.data;
    this.logger.log(`Processing media ${mediaId} (${mimeType})`);

    const scanResult = await this.runVirusScan(storageKey);

    if (scanResult === 'infected') {
      await this.prisma.mediaObject.update({
        where: { id: mediaId },
        data: { status: 'quarantined', virusScanStatus: 'infected' },
      });
      await this.kafkaProducer.publish('media.scan.flagged', {
        eventType: 'media.scan.flagged',
        key: mediaId,
        schemaVersion: 1,
        payload: {
          mediaId,
          ownerId: (
            await this.prisma.mediaObject.findUniqueOrThrow({ where: { id: mediaId } })
          ).ownerId,
        },
      });
      this.logger.warn(`Media ${mediaId} quarantined — virus scan flagged`);
      return;
    }

    const requiredVariants = MediaUploadPolicy.requiredVariants(mimeType);
    const createdVariants: string[] = [];

    for (const variantType of requiredVariants) {
      const variantStorageKey = await this.generateVariant(storageKey, variantType);
      await this.prisma.mediaVariant.upsert({
        where: { mediaObjectId_variantType: { mediaObjectId: mediaId, variantType } },
        create: { mediaObjectId: mediaId, variantType, storageKey: variantStorageKey },
        update: { storageKey: variantStorageKey },
      });
      createdVariants.push(variantType);
    }

    await this.prisma.mediaObject.update({
      where: { id: mediaId },
      data: { status: 'ready', virusScanStatus: 'clean' },
    });

    await this.kafkaProducer.publish('media.processing.completed', {
      eventType: 'media.processing.completed',
      key: mediaId,
      schemaVersion: 1,
      payload: { mediaId, variants: createdVariants },
    });

    this.logger.log(
      `Media ${mediaId} ready — variants: ${createdVariants.join(', ') || 'none'}`,
    );
  }

  /**
   * Integration point for a real scanner (e.g. ClamAV via clamscan/clamd).
   * This milestone's implementation is a deterministic pass-through
   * (never flags anything) so the surrounding pipeline is fully exercised
   * and testable without a scanner binary present.
   */
  private async runVirusScan(_storageKey: string): Promise<'clean' | 'infected'> {
    return 'clean';
  }

  /**
   * Integration point for a real transcoder/thumbnailer (e.g. sharp for
   * images, ffmpeg for video/audio). This milestone copies the source
   * object's storage key with a variant suffix rather than performing
   * real byte transformation — the variant *record* and its lifecycle
   * are real; the pixels are not, per the scope note above.
   */
  private async generateVariant(
    sourceStorageKey: string,
    variantType: string,
  ): Promise<string> {
    return `${sourceStorageKey}::${variantType}`;
  }
}
