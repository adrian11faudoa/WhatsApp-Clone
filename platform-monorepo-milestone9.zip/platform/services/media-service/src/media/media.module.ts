import { Module } from '@nestjs/common';
import { QueueModule } from '../infrastructure/queue/queue.module';
import { MediaController } from './media.controller';
import { MediaService } from './media.service';
import { MediaProcessingProcessor } from './media-processing.processor';

@Module({
  imports: [QueueModule],
  controllers: [MediaController],
  providers: [MediaService, MediaProcessingProcessor],
})
export class MediaModule {}
