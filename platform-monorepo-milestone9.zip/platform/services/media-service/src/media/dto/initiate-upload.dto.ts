import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsString, Max, Min } from 'class-validator';

export class InitiateUploadDto {
  @ApiProperty({ example: 'image/png' })
  @IsString()
  mimeType!: string;

  @ApiProperty({ example: 2048576 })
  @IsInt()
  @Min(1)
  @Max(5 * 1024 * 1024 * 1024) // 5GB hard ceiling regardless of policy config
  sizeBytes!: number;
}

export class InitiateUploadResponseDto {
  @ApiProperty() mediaId!: string;
  @ApiProperty() uploadUrl!: string;
  @ApiProperty() storageKey!: string;
  @ApiProperty() expiresInSeconds!: number;
}
