import { ApiProperty } from '@nestjs/swagger';

export class MediaVariantDto {
  @ApiProperty() variantType!: string;
  @ApiProperty() url!: string;
}

export class MediaResponseDto {
  @ApiProperty() id!: string;
  @ApiProperty() status!: string;
  @ApiProperty() mimeType!: string;
  @ApiProperty({ required: false }) downloadUrl?: string;
  @ApiProperty({ type: [MediaVariantDto], required: false }) variants?: MediaVariantDto[];
  @ApiProperty() createdAt!: string;
}
