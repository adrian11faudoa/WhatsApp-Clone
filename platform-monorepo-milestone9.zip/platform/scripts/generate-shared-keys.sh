#!/usr/bin/env bash
# Generates ONE RS256 keypair shared by all services for local dev, so
# tokens issued by identity-service verify correctly in messaging-service,
# media-service, and presence-service (Volume 1 Sec 1's RS256 rationale —
# any service holding only the public key can verify without calling
# Identity). Production key issuance/rotation is Vault's job (Volume 3
# Sec 5.6), not this script's.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p infra/keys
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out infra/keys/jwt-private.pem
openssl rsa -pubout -in infra/keys/jwt-private.pem -out infra/keys/jwt-public.pem
echo "Generated infra/keys/jwt-private.pem and infra/keys/jwt-public.pem (dev only — never commit these)."
