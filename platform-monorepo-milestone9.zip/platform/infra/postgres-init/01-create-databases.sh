#!/bin/bash
# Runs automatically on first container start (mounted into
# /docker-entrypoint-initdb.d/) — creates one database per service.
# Each service still owns its schema exclusively (Volume 1 Sec 4.3's
# "no shared database access" rule) — this is one Postgres SERVER for
# local-dev convenience, not one shared database; identity_db,
# messaging_db, and media_db are fully separate databases within it.
set -e

for db in identity_db messaging_db media_db notification_db; do
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    SELECT 'CREATE DATABASE $db' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$db')\gexec
EOSQL
done
