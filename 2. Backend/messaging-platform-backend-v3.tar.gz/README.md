# Messaging Platform — Backend (Volume 1: Foundation)

Foundational backend for the WhatsApp-style messaging platform: accounts,
authentication, devices, sessions, conversations (direct + group), and
conversation membership. This is **Backend Volume 1** — message
send/delivery, realtime transport, media, notifications, search, and
moderation are explicitly out of scope and left for later milestones (see
"Future compatibility" below).

## Architecture at a glance

- **Runtime**: NestJS + TypeScript
- **Database**: PostgreSQL via **Drizzle ORM** (see "Why Drizzle, not
  Prisma" below) + `pg`
- **Cache / rate limiting**: Redis via `ioredis`
- **Auth**: argon2id password hashing, short-lived signed JWT access
  tokens, long-lived opaque (hashed-at-rest) refresh tokens with rotation
- **Validation**: `class-validator` / `class-transformer` DTOs, global
  `ValidationPipe`
- **Docs**: OpenAPI/Swagger, served at `/api/v1/docs` outside production
- **Observability**: structured JSON logs, request correlation IDs,
  liveness/readiness health checks

### Why Drizzle, not Prisma

The master prompt names Prisma as the default, with an explicit
allowance for "an equivalent strongly typed data-access layer." In the
sandbox this was built in, Prisma's query/schema engine binaries are
fetched from `binaries.prisma.sh` at `prisma generate` time, and that
host is not reachable from the environment's network allowlist (only
package registries and a few source hosts are reachable). Drizzle ORM
ships as pure JavaScript/TypeScript over the standard `pg` driver, so it
installs and runs entirely from the npm registry. If Prisma is genuinely
required for this project, swapping back is a contained change scoped to
`src/database/` and `drizzle.config.ts` — the rest of the codebase talks
to the database only through the `Database` type exported from
`src/database/database.module.ts`.

## Project layout

```
src/
  main.ts                  Application bootstrap (helmet, CORS, Swagger, shutdown)
  app.module.ts             Root module wiring
  config/                   Typed, Joi-validated environment configuration
  database/                 Drizzle schema, connection lifecycle, migration/seed scripts
  redis/                    Shared Redis client (rate limiting today; presence/coordination later)
  common/                   Cross-cutting concerns: errors, filters, interceptors,
                             middleware, decorators, pagination, audit log, throttler guard
  auth/                     Register/login/refresh/logout, password + token services, JWT strategy/guard
  users/                    Current-user profile + public profile lookup
  devices/                  Device listing/revocation
  sessions/                 Session listing/revocation
  conversations/            Direct + group conversation foundation, membership, roles
  messages/                 Message persistence, sequencing, idempotency, editing, deletion, receipts (Volume 2)
  realtime/                 WebSocket gateway, transactional outbox publisher/poller, presence registry (Volume 2)
  reactions/                Message reactions (Volume 3)
  storage/                  StorageAdapter interface + local filesystem implementation, signed media URLs (Volume 3)
  jobs/                     Shared BullMQ queue configuration (Volume 3)
  media/                    Media upload/processing/download lifecycle (Volume 3)
  notifications/            Push tokens, preferences, notification orchestration and delivery (Volume 3)
test/
  *.e2e-spec.ts              Integration tests against a real Postgres + Redis
drizzle/                    Generated SQL migrations (source of truth for schema changes)
```

## Prerequisites

- Node.js 20+
- PostgreSQL 14+ (tested against 16)
- Redis 6+

## Setup

```bash
npm install
cp .env.example .env        # then fill in real secrets — see below
npm run db:migrate          # applies drizzle/*.sql to DATABASE_URL
npm run db:seed             # optional: seeds 3 dev users + a direct + group conversation
npm run start:dev
```

`npm run db:seed` creates `alice@example.dev`, `bob@example.dev`,
`carol@example.dev`, all with password `dev-seed-password-only`. It
refuses to run when `NODE_ENV=production`.

### Required environment variables

See `.env.example` for the full, commented list. The application
validates all of these at startup (`src/config/env.validation.ts`) and
**refuses to start** if required variables are missing or malformed, or
if `NODE_ENV=production` with a placeholder JWT secret still in place.

Key variables:

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` | Must each be ≥32 chars, and must differ |
| `CORS_ORIGINS` | Comma-separated allowed origins |

## Running tests

```bash
npm test              # unit tests (pure logic: password hashing, tokens, pagination, throttler tracking)
npm run test:e2e       # integration tests against a real Postgres + Redis (messaging_test DB)
```

`test:e2e` reads `.env.test`, which should point `DATABASE_URL` at a
**separate** test database (never the dev/prod one — tests truncate all
application tables between runs). Rate limiting is automatically
disabled when `NODE_ENV=test` (see `AppThrottlerGuard.shouldSkip`) since
integration tests intentionally exercise auth endpoints many times in
quick succession; this does not affect production/development behavior,
which is covered separately by unit tests on the guard's tracking logic.

What's covered:

- **Auth**: registration (incl. duplicate email/username, password
  policy, no password hash ever returned), login (incl. uniform
  invalid-credentials response for both "wrong password" and "unknown
  email"), refresh-token rotation + invalidation of the rotated-away
  token, logout revoking the session, rejection of missing/malformed
  bearer tokens.
- **Conversations**: direct-conversation creation, idempotency,
  symmetry (either participant can initiate), **correctness under 8
  concurrent duplicate-creation requests** (asserts exactly one row is
  ever created), self-conversation rejection, unknown-user rejection,
  **IDOR protection** (a non-member gets 404, indistinguishable from a
  nonexistent conversation), pagination bounds.
  Groups: creator becomes OWNER, only OWNER/ADMIN can remove members,
  the OWNER cannot be removed, only the OWNER can change roles, members
  can leave voluntarily and lose access afterward.

## API surface (this milestone)

All routes are under `/api/v1` (except `/health/live` and
`/health/ready`, which are excluded from the prefix for orchestrator
convenience).

```
POST   /auth/register
POST   /auth/login
POST   /auth/refresh
POST   /auth/logout               (auth required)
POST   /auth/logout-all           (auth required)

GET    /users/me                  (auth required)
PATCH  /users/me                  (auth required)
GET    /users/:userId             (auth required — public profile view)

GET    /devices                   (auth required)
DELETE /devices/:deviceId         (auth required)

GET    /sessions                  (auth required)
DELETE /sessions/:sessionId       (auth required)

GET    /conversations                              (auth required, cursor-paginated)
POST   /conversations/direct                        (auth required)
POST   /conversations/groups                         (auth required)
GET    /conversations/:conversationId                (auth required)
GET    /conversations/:conversationId/members         (auth required)
DELETE /conversations/:conversationId/members/me       (auth required — leave)
DELETE /conversations/:conversationId/members/:userId  (auth required — OWNER/ADMIN only)
PATCH  /conversations/:conversationId/members/:userId/role  (auth required — OWNER only)

GET    /health/live
GET    /health/ready
```

Full request/response schemas: run the app and open `/api/v1/docs`
(Swagger UI; disabled when `NODE_ENV=production`).

### Error shape

Every error response — validation failures, domain errors, and
unexpected exceptions alike — has the same shape:

```json
{
  "error": {
    "code": "EMAIL_ALREADY_REGISTERED",
    "message": "An account with this email already exists.",
    "details": { "...": "optional" },
    "retryable": false,
    "requestId": "...",
    "timestamp": "...",
    "path": "/api/v1/auth/register"
  }
}
```

Stable codes are enumerated in `src/common/errors/app-error-codes.ts`.

## Security notes

- Passwords are hashed with **argon2id** (`src/auth/password.service.ts`),
  cost parameters configurable via env, never logged.
- Refresh tokens are opaque random values; only their **SHA-256 hash**
  is persisted (`sessions.refresh_token_hash`), so a database leak alone
  cannot be replayed. Refresh is **rotating**: each use invalidates the
  presented token and issues a new one on the same session row.
- Access tokens are short-lived (15 min default) signed JWTs, verified
  against **live session state** on every request (`JwtStrategy`) — a
  revoked session or disabled account takes effect immediately rather
  than waiting for the token to expire on its own.
- Login responses are timing-equalized between "unknown email" and
  "wrong password" (a dummy hash verification always runs) and return
  the identical `INVALID_CREDENTIALS` error code, to resist email
  enumeration.
- Every conversation-scoped endpoint checks active membership before
  reading or mutating; a non-member gets the same `404` as a
  nonexistent conversation, not a `403`, since the alternative leaks
  conversation existence to non-members (IDOR-adjacent).
- Direct-conversation uniqueness is enforced by a **database unique
  index** on a deterministic `direct_key` (sorted pair of user IDs), not
  an application-level precheck — verified safe under 8 concurrent
  requests in `test/conversations.e2e-spec.ts`.
- Rate limiting (`@nestjs/throttler`, Redis-backed storage) applies
  tighter limits to `register`/`login`/`refresh` than the global
  default, dimensioned by authenticated user ID when available and IP
  otherwise.
- Global exception filter never leaks stack traces, SQL, or internal
  topology to clients.
- No secrets are hardcoded anywhere; `.env` is git-ignored;
  `.env.example` documents every variable without real values; startup
  fails if `NODE_ENV=production` and a placeholder JWT secret is still
  set.

## Future compatibility

This schema and API surface are designed so later milestones can add,
without redesigning what exists here:

- **Messaging**: `Conversation` is already the natural parent for a
  future `messages` table; `conversation_members.last_read_at` is
  reserved and unused today, for read receipts / unread counts.
- **Realtime**: `Session`/`Device` already carry the identity needed to
  authorize a WebSocket connection the same way HTTP requests are
  authorized (`JwtStrategy`'s live-session check pattern applies
  directly).
- **Media, notifications, search, moderation**: no schema or API
  decisions here assume these don't exist; they're simply not built
  yet.
- **Audit log**: `audit_events` already records the security-sensitive
  events from this milestone (registration, login, logout, refresh,
  session revocation, group creation, membership changes) in an
  extensible shape a later admin/analytics milestone can query or
  extend.

## What is explicitly NOT in this milestone

Per the Backend Volume 1 scope: message send/delivery, WebSocket
messaging, message receipts/reactions, production presence, media
upload/processing, push notification delivery, search indexing,
moderation workflows, analytics pipelines, Kafka/event-stream
infrastructure, full BullMQ worker infrastructure, Kubernetes/Terraform
deployment, frontend, and mobile apps. None of these have been faked or
stubbed — the endpoints and tables for them simply do not exist yet.

---

## Volume 2 — Messaging & Realtime

Volume 2 adds durable message persistence, editing/deletion, delivery
and read receipts, and an authenticated WebSocket gateway for realtime
delivery — the scope defined in Backend Prompt — Volume 2.

### What's new

- **`messages`** table: server-assigned per-conversation `sequence`
  (not `created_at`) is the authoritative ordering field. Idempotency on
  `(conversation_id, sender_id, client_message_id)`.
- **`message_outbox`** table: a transactional outbox written in the same
  transaction as the message insert/update/delete it describes.
- Per-member **delivery/read checkpoints** on `conversation_members`
  (`last_delivered_sequence`, `last_read_sequence`) rather than a row
  per message per recipient.
- An authenticated **WebSocket gateway** (`/realtime`, socket.io) for
  `send_message`, `acknowledge_delivery`, `acknowledge_read`, and
  `synchronize`, plus REST equivalents for clients not using WebSocket.
- A background **outbox poller** as the durability backstop for
  realtime fan-out.

### Message ordering and idempotency

Every conversation has a `last_sequence` counter. Creating a message
atomically does `UPDATE conversations SET last_sequence = last_sequence
+ 1 ... RETURNING last_sequence` inside the same transaction as the
insert — this is what makes sequence assignment race-free under
concurrent sends without a distributed lock (verified under 8 concurrent
requests in `test/messages.e2e-spec.ts`).

A client-generated `clientMessageId` plus a unique index on
`(conversation_id, sender_id, client_message_id)` makes retried sends
safe: a retried request returns the original message rather than
creating a duplicate, and this is correct under concurrency (also
verified with 8 parallel identical requests).

### Message API (REST)

```
POST   /conversations/:id/messages              Send a message (idempotent on clientMessageId)
GET    /conversations/:id/messages               Browse history, most recent first (beforeSequence cursor)
GET    /conversations/:id/messages/since          Catch-up: messages after afterSequence, oldest first
GET    /conversations/:id/messages/:messageId      Get one message
PATCH  /conversations/:id/messages/:messageId      Edit (sender only)
DELETE /conversations/:id/messages/:messageId      Delete for everyone (sender only, idempotent)

GET    /conversations/:id/receipts                Per-member delivered/read checkpoints
POST   /conversations/:id/receipts/delivered        Acknowledge delivery up to a sequence
POST   /conversations/:id/receipts/read              Acknowledge read up to a sequence
```

All require `Authorization: Bearer <accessToken>` and active conversation
membership — a non-member gets `404`, matching the same IDOR-safe
pattern as the conversations API.

### Deletion model (explicit scope decision)

Only **delete for everyone** is implemented, and only by the original
sender. "Delete for self" (hide a message on one device/account without
affecting others) is not implemented in this milestone — it would need
a per-user hidden-message table, which the schema can accommodate later
without redesign, but doesn't exist yet. Deletion is soft: the row's
`content` stays in the database (the column is `NOT NULL`), but the API
layer (`MessagesService.toResponseDto`) always returns `content: null`
for any message with `deletedAt` set. Deletion is idempotent — deleting
an already-deleted message returns success, not an error.

### Editing

Only the original sender may edit their own message; there is no
admin/owner override in this milestone. Editing a deleted message is
rejected. Edits set `editedAt` and publish a `message_updated` event.

### Realtime protocol (WebSocket, socket.io, path `/realtime`)

**Connecting**: pass the access token as `auth: { token }` (or an
`Authorization: Bearer` header) in the socket.io handshake. Authentication
runs as socket.io **handshake middleware** (`server.use(...)` in
`MessagingGateway.afterInit`), not in `handleConnection` — this matters:
handshake middleware completes before the client's `connect` event fires
and before any command packet is processed, so there is no window where
a command could race ahead of authentication finishing. (An earlier
version of this gateway did the auth check in `handleConnection` instead,
which is an ordinary async event handler the client doesn't wait for —
integration testing caught the resulting race condition, which is why
this is called out explicitly here.) A rejected handshake surfaces to the
client as `connect_error`; a valid one joins the socket to a `user:{id}`
room and a `conversation:{id}` room for every conversation the user is
currently an active member of.

**Envelope** (every event pushed to a client):
```json
{
  "eventId": "uuid",
  "type": "message_created",
  "version": 1,
  "timestamp": "2026-01-01T00:00:00.000Z",
  "conversationId": "uuid",
  "correlationId": null,
  "payload": { "...": "event-specific" }
}
```

**Commands** (client emits, with an ack callback):

| Command | Payload | Ack shape |
|---|---|---|
| `send_message` | `{ conversationId, clientMessageId, content, type?, replyToId? }` | `{ ok, message }` or `{ ok: false, error }` |
| `acknowledge_delivery` | `{ conversationId, upToSequence }` | `{ ok }` |
| `acknowledge_read` | `{ conversationId, upToSequence }` | `{ ok }` |
| `synchronize` | `{ conversationId, afterSequence, limit? }` | `{ ok, items, nextCursor, hasMore }` |
| `heartbeat` | *(none)* | `{ ok: true }` |

Every command handler re-derives authorization from the identity
established at handshake time (never from anything in the payload), and
is independently rate-limited per user via Redis (`send_message`:
20/10s, `acknowledge_*`: 30/10s each, `synchronize`: 10/10s;
`ws:connect` is limited to 20/60s per IP at the handshake).

**Events** (server pushes to the `conversation:{id}` room):
`message_created`, `message_updated`, `message_deleted`,
`message_delivered`, `message_read`. All commands and events share the
error-code vocabulary in `RealtimeErrorCode`
(`src/realtime/realtime-envelope.ts`).

### Reconnect / synchronization

There is no separate "resume" protocol beyond `synchronize`: a
reconnecting client re-authenticates (a fresh handshake), then calls
`synchronize` with its last known `afterSequence` for each conversation
it cares about, paging with the returned `nextCursor` until `hasMore` is
`false`. Because Postgres retains full message history in this milestone
(nothing is pruned), there is no unrecoverable "sequence gap" — a client
arbitrarily far behind simply pages through more results; it never needs
to guess at missing messages.

### Transactional outbox and delivery guarantees

Message creation, editing, and deletion each write an outbox row in the
**same transaction** as the underlying change. After that transaction
commits, `MessagesService` makes a best-effort **immediate** publish
attempt (low latency for the common case); a background poller
(`OutboxProcessorService`, `@Interval` every 2s) is the durability
backstop, picking up any row still `PENDING` — whether because the
immediate attempt failed, or the process crashed between commit and that
attempt — using `SELECT ... FOR UPDATE SKIP LOCKED` inside an explicit
transaction (verified: a manually-inserted `PENDING` row was picked up
and published within one poll interval in manual testing). A row that
fails `OUTBOX_MAX_ATTEMPTS` (5) publish attempts is marked `FAILED` and
left for operational follow-up rather than retried forever.

**What this guarantees and what it doesn't**: durable message
persistence in Postgres never depends on realtime publish succeeding —
a publish failure means "a connected client might not get an
instant push," never "the message might be lost." Offline or
never-connected recipients are not a failure case at all; they simply
catch up via `synchronize` or `GET .../messages/since` whenever they
next connect. This is a deliberate simplification appropriate to this
milestone's scope, not an oversight — see "Known limitations" below for
what a future scaling milestone would add.

### Redis's role in realtime

Redis is used for: (a) command-level rate limiting
(`RedisRateLimiterService`, separate from the HTTP
`ThrottlerStorageRedisService` since WS commands aren't HTTP routes and
have per-command rather than per-route limits), and (b) a presence
registry (`PresenceRegistryService`) mirroring which sockets belong to
which user. Redis is **not** the source of truth for anything durable —
actual message routing uses this process's **in-memory** socket map,
because this milestone runs a single backend instance. See "Known
limitations."

### Known limitations (Volume 2)

- **Single-instance realtime fan-out.** `RealtimeServerRegistryService`
  holds one process's live socket.io `Server`. Running more than one
  backend instance would require a socket.io Redis adapter (or
  equivalent) for cross-instance delivery; the Redis presence keys this
  milestone already writes are the extension point a later
  horizontal-scaling milestone would build on, but that adapter itself
  is not implemented here.
- **Room membership is computed at connect time.** If a user is removed
  from a group (or joins a new one) while connected, their existing
  socket's room membership doesn't update until they reconnect. A future
  milestone would push room join/leave on membership-change events.
- **WebSocket CORS is not environment-configured.** `@WebSocketGateway`
  decorator options are evaluated at class-definition time, before
  `ConfigModule` has loaded `.env`, so the gateway currently uses
  `origin: true` (reflects any requesting origin) rather than reading
  `CORS_ORIGINS` the way the HTTP CORS policy in `main.ts` does. Noted
  in code; tightening this is a natural follow-up for the infrastructure
  milestone.
- **No "delete for self."** See "Deletion model" above.
- **Typing indicators are not implemented.** The Volume 2 prompt lists
  them only under "consider rate-limiting if implemented," not in the
  required commands/events lists, so they were left out to keep this
  milestone's scope bounded — not because they'd be hard to add (the
  envelope and gateway pattern extend to them directly).

### Testing (Volume 2 additions)

- **Unit**: `redis-rate-limiter.service.spec.ts` (allow/deny counting,
  fail-open on Redis error, test-env bypass).
- **E2E** (`test/messages.e2e-spec.ts`, `test/realtime.e2e-spec.ts`):
  sequencing across senders, idempotent retry (including 8-way
  concurrent duplicate submission), reply validation, history/sync
  pagination, edit/delete authorization and idempotency, receipt
  checkpoints and their idempotency/monotonicity, WebSocket connection
  auth (valid/missing/garbage/revoked-session token), `send_message`
  end-to-end including realtime fan-out to a second connected client,
  membership enforcement over the socket, payload validation, and both
  acknowledgement commands and `synchronize` over the socket.
- Rate limiting (`RedisRateLimiterService` and `AppThrottlerGuard`) is
  disabled under `NODE_ENV=test`, for the same reason across both: e2e
  tests intentionally exercise these endpoints/commands in rapid
  succession, and each limiter's counting logic is verified separately
  by its own unit test instead.

---

## Volume 3 — Reactions, Presence, Media, Notifications

Volume 3 adds message reactions, ephemeral typing/presence, a full
media upload-and-processing pipeline, and notification orchestration —
the scope defined in Backend Prompt — Volume 3.

### What's new

- **`message_reactions`**: one reaction per user per message (picking a
  new emoji replaces the old one), upsert-based, realtime events via
  the existing outbox.
- **Typing indicators & presence**: Redis-backed, ephemeral, never
  written to Postgres. Presence is derived from actual connect/
  disconnect (not a TTL guess) and is privacy-filtered through the
  existing `profiles.showOnline`/`showLastSeen` flags.
- **`media_assets` / `media_variants` / `message_attachments`**: full
  upload-initiate → upload → detect → process → ready lifecycle, with
  attachment-only messages now supported (`messages.content` is
  nullable as of this volume).
- **`push_tokens` / `notification_preferences` / `notifications`**:
  multi-device push-token registration, preference-aware eligibility,
  deduplication, and asynchronous delivery via BullMQ.
- **BullMQ** (`JobsModule`) as the durable background-job infrastructure
  for media processing, media cleanup, and notification delivery.

### Why local filesystem storage, not S3

The master prompt specifies S3-compatible object storage. This sandbox
has no AWS credentials and no network access to any object-storage
provider (the same network-allowlist constraint documented in the
Volume 1 section for Prisma). `StorageAdapter`
(`src/storage/storage-adapter.interface.ts`) is the boundary a
production `S3Adapter` would implement; `LocalFilesystemStorageAdapter`
is this milestone's only implementation, and it is a **genuinely
working** adapter — it writes, reads, and deletes real files under
`MEDIA_STORAGE_ROOT`, with path-traversal protection — not a mock.
Nothing above the adapter boundary (`MediaService`, the upload/download
controllers, the processing worker) would need to change to swap in a
real S3 adapter later.

Because the LOCAL adapter has no separate storage endpoint to redirect
clients to, uploads and downloads necessarily proxy through the app
server in this milestone — unlike a real S3 adapter, which would let
clients PUT directly to a presigned URL and bypass the app server
entirely (the intended production path, and why the upload/download API
shape is still built around short-lived signed URLs rather than a
direct POST-with-file-body endpoint).

### Media upload flow

```
POST   /media                       Initiate: returns { mediaAssetId, uploadUrl, ... }
PUT    /media/upload/:token          Upload raw bytes (auth = the signed token itself)
GET    /media/:mediaAssetId          Metadata + signed variant download URLs
GET    /media/download/:token         Stream bytes (auth = the signed token itself)
DELETE /media/:mediaAssetId          Owner-only, idempotent, async storage cleanup
```

Every byte is treated as untrusted regardless of what the client
declared: actual upload size is checked against both the per-category
limit and the originally declared size, and content type is detected
from the file's magic bytes via `file-type` — never taken from the
client-supplied header. A `MediaProcessingWorker` (BullMQ) then
generates a **real** JPEG thumbnail for `IMAGE` uploads using `sharp`
(verified in testing: downloaded and confirmed as a valid 320×320
JPEG) and extracts width/height. `VIDEO`/`AUDIO`/`DOCUMENT` categories
are validated and moved straight to `READY` with no derived variant —
this milestone does not include a transcoding pipeline (explicitly
out of scope per the prompt), and that limitation is not hidden behind
a fake "processed" status.

Upload/download authorization is the signed token itself (like an S3
presigned URL), not a session Bearer token — `MediaUrlSignerService`
reuses the JWT access-token secret but with a distinct `typ` claim and
short, purpose-specific expiry so a media token can never be confused
with (or substituted for) a session access token. Reading a `READY`
asset's metadata (`GET /media/:id`) *does* require a session and is
authorized either as the owner or as a member of the conversation the
asset is attached to — that authorization already happened by the time
a download token was issued, so the download endpoint itself doesn't
re-check session identity.

### Message/media integration

`messages.content` is nullable as of this volume: a message may have
text, one or more `attachmentIds` (must be the sender's own `READY`
media, and not already attached elsewhere — enforced by a unique index
on `message_attachments.media_asset_id`), or both. `CreateMessageDto`
requires at least one of the two.

### Reactions

`PUT /conversations/:id/messages/:messageId/reactions/me` sets (or
replaces) the caller's reaction; `DELETE` the same path removes it
(idempotent). Adding is implemented as a genuine atomic
`INSERT ... ON CONFLICT DO UPDATE` on the `(message_id, user_id)` unique
index — an earlier check-then-insert version of this had exactly the
race the project's concurrency requirements warn against (two
simultaneous adds could both see "no existing row" and both attempt an
insert), which a concurrency test (8 parallel identical requests)
caught as an unhandled unique-violation before the fix.

### Typing & presence protocol

New WebSocket commands: `typing_start`, `typing_stop` (see
`src/realtime/dto/command-payloads.ts`). New events:
`typing_start`, `typing_stop`, `presence_changed`. Typing state is a
Redis key with an 8-second TTL, explicitly cleared on `typing_stop`,
on `send_message` (sending implicitly stops "is typing"), and on
disconnect — the TTL is only the backstop for the case none of those
fire (e.g. a network partition with no clean disconnect). Server-side
debounce silently drops (not errors) a `typing_start` faster than one
per 3 seconds per (user, conversation).

Presence (`online`/`lastSeenAt`) flips the instant a user's first
socket connects and the instant their last socket disconnects — not
inferred from a heartbeat TTL — and is broadcast to that user's
conversation rooms only when `profile.showOnline` is true;
`lastSeenAt` is additionally withheld when `profile.showLastSeen` is
false. `GET /users/:userId` now includes privacy-filtered `online`/
`lastSeenAt` fields.

### Notifications

```
POST   /push-tokens                 Register/refresh a push token (upsert on token value)
GET    /push-tokens                  List the caller's tokens
DELETE /push-tokens/:id              Invalidate a token

GET    /notification-preferences     Get (creates defaults on first access)
PATCH  /notification-preferences      Update
```

Triggered by `message_created`: `NotificationsService.notifyMessageCreated`
is called fire-and-forget from `MessagesService.createMessage`, after
the message transaction has already committed — a slow or unavailable
push provider can never affect message-send latency or success, and a
notification-pipeline exception is caught and logged, never surfaced
as a message-send failure. Eligibility excludes the sender, requires an
`ACTIVE` account, and checks the recipient's `messageNotifications`/
`groupNotifications` preference (verified: a recipient who disabled the
category gets no notification row at all). Deduplication is a unique
index on `(user_id, source_event_type, source_event_id)` — a retried or
duplicate-published event for the same recipient is a no-op insert, not
a second notification (verified with a direct duplicate-insert
attempt). Delivery is asynchronous via BullMQ
(`NotificationDeliveryWorker`), fanning out to every `ACTIVE` push
token for the recipient (multi-device) and recording a per-token result
summary in `notifications.delivery_results`.

Notification bodies are always generic ("You have a new message.") —
verified that message content never appears in the stored title/body —
and the `LogPushProvider`'s own log line includes only the generic
title and the last 6 characters of the token, never the body.

### Why a log-only push provider, not real APNS/FCM

No push-provider credentials exist in this sandbox. `PushProvider`
(`src/notifications/providers/push-provider.interface.ts`) is the
boundary a real `ApnsPushProvider`/`FcmPushProvider` would implement.
`LogPushProvider` is this milestone's only implementation, and it is
honest about what it is: every call returns `skipped_no_provider`,
**never** `sent` — it does not fabricate a successful delivery. A
notification whose every delivery attempt comes back
`skipped_no_provider` is stored with `status: SKIPPED`, not `SENT`
(verified directly against the database in tests). What the log
provider *does* let the pipeline exercise for real: job enqueue,
per-token fan-out, result recording, and the retry/backoff wiring
around a provider call — everything except the actual network call to
a push service, which doesn't exist to call.

### Known limitations (Volume 3)

- **No video/audio transcoding.** See "Media upload flow" above —
  explicitly out of scope per the prompt, not hidden.
- **No real push provider.** See "Why a log-only push provider" above.
- **Presence/typing don't survive a Redis flush or a full outage
  gracefully beyond "everyone appears offline/not-typing until the next
  state change."** This is consistent with presence being explicitly
  non-authoritative ephemeral state — durable messaging is unaffected.
- **`GET /media/:id` authorization walks a single join** (attachment →
  message → conversation membership) rather than reusing
  `ConversationMembershipService` directly, to avoid `MediaModule`
  depending on `ConversationsModule` for what is one indexed lookup;
  see the comment in `MediaService.assertReadableAsset`.
- **Reaction values are validated only as "a short string"** (1–32
  chars), not against a fixed emoji allowlist — the product spec
  doesn't define one, and inventing one would be an arbitrary,
  unrequested product decision.

### Testing (Volume 3 additions)

- **E2E** (`test/reactions.e2e-spec.ts`, `test/media.e2e-spec.ts`,
  `test/notifications.e2e-spec.ts`): reaction add/replace/remove
  including an 8-way concurrency test (the one that caught the
  check-then-insert race described above), reaction authorization and
  deleted-message rejection; a real upload → raw-binary receive →
  content-type detection → BullMQ processing → thumbnail generation →
  signed download round-trip, oversized/mismatched-size rejection,
  owner/conversation-member/non-member authorization, attachment-only
  messages, attaching not-ready or another user's media; push-token
  registration/upsert/list/invalidate, preference defaults and updates,
  sender-excluded and preference-filtered notification eligibility,
  deduplication, privacy-safe notification bodies, and the honest
  `SKIPPED` (not `SENT`) status with no provider configured.
- All 4 e2e spec files (Volumes 1–3) and the full unit suite were
  re-run together after every Volume 3 change as a regression check.

