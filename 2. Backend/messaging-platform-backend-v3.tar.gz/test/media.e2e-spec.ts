import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { Pool } from 'pg';
import * as express from 'express';
import { AppModule } from '../src/app.module';
import { DATABASE_POOL } from '../src/database/database.module';
import { truncateAll } from './db-test-helper';

// A minimal valid 1x1 PNG, well under any category size limit, used to
// exercise the real upload -> detect -> process -> ready pipeline.
const TINY_PNG = Buffer.from(
  '89504e470d0a1a0a0000000d4948445200000001000000010802000000907753de0000000c4944415478da6360606060000000050001a5f645400000000049454e44ae426082',
  'hex',
);

async function waitUntil(
  check: () => Promise<boolean>,
  timeoutMs = 8000,
  intervalMs = 200,
): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await check()) return;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
  throw new Error('waitUntil timed out');
}

describe('Media (e2e)', () => {
  let app: INestApplication;
  let pool: Pool;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication({ bodyParser: false });
    // Mirrors src/main.ts's body-parsing setup exactly: the test app is
    // built directly from AppModule (bypassing main.ts's bootstrap()),
    // so without this, the media upload route here would get Nest's
    // default JSON body parser instead of raw binary handling — this
    // block is what makes the raw-upload tests below meaningful rather
    // than accidentally passing against unrelated body-parsing.
    app.use(
      '/media/upload',
      express.raw({ limit: 20 * 1024 * 1024, type: () => true }),
    );
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    await app.init();
    pool = app.get(DATABASE_POOL);
  });

  afterAll(async () => {
    await app.close();
  });

  beforeEach(async () => {
    await truncateAll(pool);
  });

  async function registerUser(email: string, username: string) {
    const res = await request(app.getHttpServer())
      .post('/auth/register')
      .send({
        email,
        password: 'correct-horse-battery',
        username,
        displayName: username,
      })
      .expect(201);
    return {
      userId: res.body.user.id as string,
      accessToken: res.body.tokens.accessToken as string,
    };
  }

  async function uploadAndWaitReady(accessToken: string) {
    const initRes = await request(app.getHttpServer())
      .post('/media')
      .set('Authorization', `Bearer ${accessToken}`)
      .send({
        category: 'IMAGE',
        declaredContentType: 'image/png',
        declaredSizeBytes: TINY_PNG.length,
      })
      .expect(201);

    const mediaAssetId = initRes.body.mediaAssetId as string;
    const uploadUrl = initRes.body.uploadUrl as string;

    await request(app.getHttpServer())
      .put(`/${uploadUrl}`)
      .set('Content-Type', 'application/octet-stream')
      .send(TINY_PNG)
      .expect(204);

    await waitUntil(async () => {
      const res = await request(app.getHttpServer())
        .get(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);
      return res.body.status === 'READY';
    });

    return mediaAssetId;
  }

  describe('upload lifecycle', () => {
    it('initiates an upload and returns a signed upload URL', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const res = await request(app.getHttpServer())
        .post('/media')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          category: 'IMAGE',
          declaredContentType: 'image/png',
          declaredSizeBytes: TINY_PNG.length,
        })
        .expect(201);

      expect(res.body.mediaAssetId).toEqual(expect.any(String));
      expect(res.body.uploadUrl).toMatch(/^media\/upload\//);
    });

    it('rejects a declared size over the category limit', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      await request(app.getHttpServer())
        .post('/media')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          category: 'IMAGE',
          declaredContentType: 'image/png',
          declaredSizeBytes: 999_999_999,
        })
        .expect(400);
    });

    it('rejects an upload with no auth-required session but an invalid token', async () => {
      await request(app.getHttpServer())
        .put('/media/upload/not-a-real-token')
        .set('Content-Type', 'application/octet-stream')
        .send(TINY_PNG)
        .expect(401);
    });

    it('processes a real upload end-to-end to READY with a detected content type', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      const res = await request(app.getHttpServer())
        .get(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(res.body.status).toBe('READY');
      expect(res.body.detectedContentType).toBe('image/png');
      expect(res.body.variants.length).toBeGreaterThan(0);
    });

    it('generates a downloadable thumbnail variant for an image', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      const res = await request(app.getHttpServer())
        .get(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      const thumbnail = res.body.variants.find(
        (v: { kind: string }) => v.kind === 'THUMBNAIL',
      );
      expect(thumbnail).toBeDefined();

      const download = await request(app.getHttpServer())
        .get(`/${thumbnail.downloadUrl}`)
        .expect(200);
      expect(download.headers['content-type']).toBe('image/jpeg');
      expect(download.body.length).toBeGreaterThan(0);
    });

    it('rejects an upload larger than declared', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const initRes = await request(app.getHttpServer())
        .post('/media')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          category: 'IMAGE',
          declaredContentType: 'image/png',
          declaredSizeBytes: 5, // smaller than the actual bytes we'll send
        })
        .expect(201);

      await request(app.getHttpServer())
        .put(`/${initRes.body.uploadUrl}`)
        .set('Content-Type', 'application/octet-stream')
        .send(TINY_PNG)
        .expect(400);
    });
  });

  describe('authorization', () => {
    it('lets the owner read their own not-yet-ready asset', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const initRes = await request(app.getHttpServer())
        .post('/media')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          category: 'IMAGE',
          declaredContentType: 'image/png',
          declaredSizeBytes: TINY_PNG.length,
        })
        .expect(201);

      const res = await request(app.getHttpServer())
        .get(`/media/${initRes.body.mediaAssetId}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);
      expect(res.body.status).toBe('INITIATED');
    });

    it('denies a non-owner, non-conversation-member from reading an unattached asset', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      await request(app.getHttpServer())
        .get(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .expect(404);
    });

    it('allows a conversation member to read media attached to a message they can see', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);

      await request(app.getHttpServer())
        .post(`/conversations/${convoRes.body.id}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'img1', attachmentIds: [mediaAssetId] })
        .expect(201);

      const res = await request(app.getHttpServer())
        .get(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .expect(200);
      expect(res.body.id).toBe(mediaAssetId);
    });
  });

  describe('message attachment integration', () => {
    it('creates an attachment-only message with no text content', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);

      const msgRes = await request(app.getHttpServer())
        .post(`/conversations/${convoRes.body.id}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'img1', attachmentIds: [mediaAssetId] })
        .expect(201);

      expect(msgRes.body.content).toBeNull();
      expect(msgRes.body.attachmentIds).toEqual([mediaAssetId]);
    });

    it('rejects a message with neither content nor attachments', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);

      await request(app.getHttpServer())
        .post(`/conversations/${convoRes.body.id}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'empty1' })
        .expect(400);
    });

    it('rejects attaching media that is not READY', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const initRes = await request(app.getHttpServer())
        .post('/media')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          category: 'IMAGE',
          declaredContentType: 'image/png',
          declaredSizeBytes: TINY_PNG.length,
        })
        .expect(201);

      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);

      await request(app.getHttpServer())
        .post(`/conversations/${convoRes.body.id}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          clientMessageId: 'notready',
          attachmentIds: [initRes.body.mediaAssetId],
        })
        .expect(400);
    });

    it("rejects attaching another user's media", async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const mediaAssetId = await uploadAndWaitReady(bob.accessToken);

      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);

      await request(app.getHttpServer())
        .post(`/conversations/${convoRes.body.id}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'stolen', attachmentIds: [mediaAssetId] })
        .expect(404);
    });
  });

  describe('deletion', () => {
    it('deletes an owned asset idempotently', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      await request(app.getHttpServer())
        .delete(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      await request(app.getHttpServer())
        .delete(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      await request(app.getHttpServer())
        .get(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(404);
    });

    it('forbids a non-owner from deleting media', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const mediaAssetId = await uploadAndWaitReady(alice.accessToken);

      await request(app.getHttpServer())
        .delete(`/media/${mediaAssetId}`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .expect(403);
    });
  });
});
