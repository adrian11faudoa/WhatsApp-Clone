import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { Pool } from 'pg';
import { AppModule } from '../src/app.module';
import { DATABASE_POOL } from '../src/database/database.module';
import { truncateAll } from './db-test-helper';

async function waitUntil(
  check: () => Promise<boolean>,
  timeoutMs = 8000,
  intervalMs = 150,
): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await check()) return;
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
  throw new Error('waitUntil timed out');
}

describe('Notifications (e2e)', () => {
  let app: INestApplication;
  let pool: Pool;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    await app.init();
    pool = app.get(DATABASE_POOL);
  });

  afterAll(async () => {
    await app.close();
  });

  beforeEach(async () => {
    await truncateAll(pool);
  });

  async function registerUser(email: string, username: string) {
    const res = await request(app.getHttpServer())
      .post('/auth/register')
      .send({
        email,
        password: 'correct-horse-battery',
        username,
        displayName: username,
      })
      .expect(201);
    return {
      userId: res.body.user.id as string,
      accessToken: res.body.tokens.accessToken as string,
      deviceId: res.body.deviceId as string,
    };
  }

  async function countNotifications(userId: string): Promise<number> {
    const res = await pool.query(
      `SELECT count(*)::int AS count FROM notifications WHERE user_id = $1`,
      [userId],
    );
    return res.rows[0].count;
  }

  describe('push tokens', () => {
    it("registers a push token for the caller's own device", async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const res = await request(app.getHttpServer())
        .post('/push-tokens')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          deviceId: alice.deviceId,
          platform: 'ANDROID',
          token: 'token-abc',
        })
        .expect(201);

      expect(res.body.status).toBe('ACTIVE');
      expect(res.body.deviceId).toBe(alice.deviceId);
    });

    it('re-registering the same token updates rather than duplicates', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const first = await request(app.getHttpServer())
        .post('/push-tokens')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          deviceId: alice.deviceId,
          platform: 'ANDROID',
          token: 'shared-token',
        })
        .expect(201);

      const second = await request(app.getHttpServer())
        .post('/push-tokens')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          deviceId: alice.deviceId,
          platform: 'ANDROID',
          token: 'shared-token',
        })
        .expect(201);

      expect(second.body.id).toBe(first.body.id);

      const countRes = await pool.query(
        `SELECT count(*)::int AS count FROM push_tokens WHERE token = 'shared-token'`,
      );
      expect(countRes.rows[0].count).toBe(1);
    });

    it('lists and invalidates a push token', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const reg = await request(app.getHttpServer())
        .post('/push-tokens')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ deviceId: alice.deviceId, platform: 'IOS', token: 'ios-token' })
        .expect(201);

      const list = await request(app.getHttpServer())
        .get('/push-tokens')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);
      expect(list.body).toHaveLength(1);

      await request(app.getHttpServer())
        .delete(`/push-tokens/${reg.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      const afterRes = await pool.query(
        `SELECT status FROM push_tokens WHERE id = $1`,
        [reg.body.id],
      );
      expect(afterRes.rows[0].status).toBe('INVALID');
    });

    it("rejects invalidating another user's push token", async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const reg = await request(app.getHttpServer())
        .post('/push-tokens')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          deviceId: alice.deviceId,
          platform: 'ANDROID',
          token: 'alice-token',
        })
        .expect(201);

      await request(app.getHttpServer())
        .delete(`/push-tokens/${reg.body.id}`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .expect(404);
    });
  });

  describe('notification preferences', () => {
    it('defaults every category to enabled', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const res = await request(app.getHttpServer())
        .get('/notification-preferences')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(res.body).toEqual({
        messageNotifications: true,
        groupNotifications: true,
        mentionNotifications: true,
      });
    });

    it('persists a preference update', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const res = await request(app.getHttpServer())
        .patch('/notification-preferences')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ messageNotifications: false })
        .expect(200);

      expect(res.body.messageNotifications).toBe(false);
      expect(res.body.groupNotifications).toBe(true);
    });
  });

  describe('message-triggered notification eligibility', () => {
    async function setupConversation() {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      await request(app.getHttpServer())
        .post('/push-tokens')
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({
          deviceId: bob.deviceId,
          platform: 'ANDROID',
          token: 'bob-token',
        })
        .expect(201);
      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);
      return { alice, bob, conversationId: convoRes.body.id as string };
    }

    it('creates exactly one notification for the recipient, never the sender', async () => {
      const { alice, bob, conversationId } = await setupConversation();

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'Hello' })
        .expect(201);

      await waitUntil(async () => (await countNotifications(bob.userId)) === 1);
      expect(await countNotifications(alice.userId)).toBe(0);
    });

    it('never places message content in the notification body', async () => {
      const { alice, bob, conversationId } = await setupConversation();

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          clientMessageId: 'm1',
          content: 'a very private secret message',
        })
        .expect(201);

      await waitUntil(async () => (await countNotifications(bob.userId)) === 1);
      const res = await pool.query(
        `SELECT title, body FROM notifications WHERE user_id = $1`,
        [bob.userId],
      );
      expect(res.rows[0].body).not.toContain('secret');
      expect(res.rows[0].title).not.toContain('secret');
    });

    it('is deduplicated: two message_created triggers for the same message never double-notify', async () => {
      const { alice, bob, conversationId } = await setupConversation();

      const msgRes = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'Hello' })
        .expect(201);

      await waitUntil(async () => (await countNotifications(bob.userId)) === 1);

      // Simulate a retried/duplicate event for the same message the way
      // the dedup unique index is meant to guard against.
      await pool.query(
        `INSERT INTO notifications (user_id, source_event_type, source_event_id, conversation_id, title, body)
         VALUES ($1, 'message_created', $2, $3, 'New message', 'You have a new message.')
         ON CONFLICT DO NOTHING`,
        [bob.userId, msgRes.body.id, conversationId],
      );

      expect(await countNotifications(bob.userId)).toBe(1);
    });

    it('skips notification creation when the recipient disabled the category', async () => {
      const { alice, bob, conversationId } = await setupConversation();

      await request(app.getHttpServer())
        .patch('/notification-preferences')
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ messageNotifications: false })
        .expect(200);

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'Hello' })
        .expect(201);

      // Give the (correctly-skipped) async path a moment, then assert
      // nothing was created.
      await new Promise((resolve) => setTimeout(resolve, 800));
      expect(await countNotifications(bob.userId)).toBe(0);
    });

    it('marks the notification SKIPPED (not SENT) when no push provider is configured', async () => {
      const { alice, bob, conversationId } = await setupConversation();

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'Hello' })
        .expect(201);

      await waitUntil(async () => {
        const res = await pool.query(
          `SELECT status FROM notifications WHERE user_id = $1`,
          [bob.userId],
        );
        return res.rows[0]?.status === 'SKIPPED';
      });

      const res = await pool.query(
        `SELECT status, delivery_results FROM notifications WHERE user_id = $1`,
        [bob.userId],
      );
      expect(res.rows[0].status).toBe('SKIPPED');
      expect(res.rows[0].delivery_results[0].result).toBe(
        'skipped_no_provider',
      );
    });

    it('creates a SKIPPED notification intent when the recipient has no registered push token', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const convoRes = await request(app.getHttpServer())
        .post('/conversations/direct')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ userId: bob.userId })
        .expect(201);

      await request(app.getHttpServer())
        .post(`/conversations/${convoRes.body.id}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'Hello' })
        .expect(201);

      await waitUntil(async () => (await countNotifications(bob.userId)) === 1);
      const res = await pool.query(
        `SELECT status FROM notifications WHERE user_id = $1`,
        [bob.userId],
      );
      // Intent is still created (an eligible member with no token is
      // still eligible for the intent; the worker is what finds zero
      // active tokens and marks it SKIPPED).
      expect(res.rows[0].status).toBe('SKIPPED');
    });
  });
});
