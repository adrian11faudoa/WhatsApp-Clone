import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { Pool } from 'pg';
import { AppModule } from '../src/app.module';
import { DATABASE_POOL } from '../src/database/database.module';
import { truncateAll } from './db-test-helper';

describe('Messages (e2e)', () => {
  let app: INestApplication;
  let pool: Pool;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    await app.init();
    pool = app.get(DATABASE_POOL);
  });

  afterAll(async () => {
    await app.close();
  });

  beforeEach(async () => {
    await truncateAll(pool);
  });

  async function registerUser(email: string, username: string) {
    const res = await request(app.getHttpServer())
      .post('/auth/register')
      .send({
        email,
        password: 'correct-horse-battery',
        username,
        displayName: username,
      })
      .expect(201);
    return {
      userId: res.body.user.id as string,
      accessToken: res.body.tokens.accessToken as string,
    };
  }

  async function createDirectConversation(
    accessToken: string,
    otherUserId: string,
  ) {
    const res = await request(app.getHttpServer())
      .post('/conversations/direct')
      .set('Authorization', `Bearer ${accessToken}`)
      .send({ userId: otherUserId })
      .expect(201);
    return res.body.id as string;
  }

  async function setup() {
    const alice = await registerUser('alice@example.com', 'alice');
    const bob = await registerUser('bob@example.com', 'bob');
    const conversationId = await createDirectConversation(
      alice.accessToken,
      bob.userId,
    );
    return { alice, bob, conversationId };
  }

  describe('message creation', () => {
    it('creates a message with server-assigned sequence starting at 1', async () => {
      const { alice, conversationId } = await setup();

      const res = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'Hello' })
        .expect(201);

      expect(res.body.sequence).toBe(1);
      expect(res.body.content).toBe('Hello');
      expect(res.body.senderId).toBe(alice.userId);
    });

    it('assigns a shared, strictly increasing sequence across senders', async () => {
      const { alice, bob, conversationId } = await setup();

      const first = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'a1', content: 'from alice' })
        .expect(201);

      const second = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ clientMessageId: 'b1', content: 'from bob' })
        .expect(201);

      expect(first.body.sequence).toBe(1);
      expect(second.body.sequence).toBe(2);
    });

    it('rejects sending into a conversation the user is not a member of', async () => {
      const { conversationId } = await setup();
      const carol = await registerUser('carol@example.com', 'carol');

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${carol.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'sneaky' })
        .expect(404);
    });

    it('rejects content over the length limit', async () => {
      const { alice, conversationId } = await setup();
      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'x'.repeat(8001) })
        .expect(400);
    });

    it('rejects a replyToId that does not exist in the conversation', async () => {
      const { alice, conversationId } = await setup();
      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({
          clientMessageId: 'c1',
          content: 'reply',
          replyToId: '00000000-0000-0000-0000-000000000000',
        })
        .expect(400);
    });

    it('accepts a valid reply reference', async () => {
      const { alice, bob, conversationId } = await setup();
      const original = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      const reply = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({
          clientMessageId: 'c2',
          content: 'a reply',
          replyToId: original.body.id,
        })
        .expect(201);

      expect(reply.body.replyToId).toBe(original.body.id);
    });
  });

  describe('idempotency', () => {
    it('returns the same message for a retried clientMessageId', async () => {
      const { alice, conversationId } = await setup();

      const first = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'retry-1', content: 'Hello' })
        .expect(201);

      const second = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'retry-1', content: 'Hello' })
        .expect(201);

      expect(second.body.id).toBe(first.body.id);
      expect(second.body.sequence).toBe(first.body.sequence);
    });

    it('stays correct under concurrent duplicate submission', async () => {
      const { alice, conversationId } = await setup();

      const requests = Array.from({ length: 8 }, () =>
        request(app.getHttpServer())
          .post(`/conversations/${conversationId}/messages`)
          .set('Authorization', `Bearer ${alice.accessToken}`)
          .send({ clientMessageId: 'concurrent-1', content: 'race' }),
      );

      const results = await Promise.all(requests);
      const ids = new Set(results.map((r) => r.body.id));
      expect(ids.size).toBe(1);

      const countRes = await pool.query(
        `SELECT count(*)::int AS count FROM messages WHERE client_message_id = 'concurrent-1'`,
      );
      expect(countRes.rows[0].count).toBe(1);
    });

    it('allows the same clientMessageId to be reused by a different sender', async () => {
      const { alice, bob, conversationId } = await setup();

      const fromAlice = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'shared-id', content: 'from alice' })
        .expect(201);

      const fromBob = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ clientMessageId: 'shared-id', content: 'from bob' })
        .expect(201);

      expect(fromAlice.body.id).not.toBe(fromBob.body.id);
    });
  });

  describe('retrieval and pagination', () => {
    it('denies a non-member access to message history', async () => {
      const { conversationId } = await setup();
      const carol = await registerUser('carol@example.com', 'carol');

      await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${carol.accessToken}`)
        .expect(404);
    });

    it('paginates history backwards, most recent first', async () => {
      const { alice, conversationId } = await setup();

      for (let i = 1; i <= 5; i++) {
        await request(app.getHttpServer())
          .post(`/conversations/${conversationId}/messages`)
          .set('Authorization', `Bearer ${alice.accessToken}`)
          .send({ clientMessageId: `m${i}`, content: `message ${i}` })
          .expect(201);
      }

      const firstPage = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/messages?limit=2`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(firstPage.body.items).toHaveLength(2);
      expect(firstPage.body.items[0].sequence).toBe(5);
      expect(firstPage.body.items[1].sequence).toBe(4);
      expect(firstPage.body.hasMore).toBe(true);

      const secondPage = await request(app.getHttpServer())
        .get(
          `/conversations/${conversationId}/messages?limit=2&beforeSequence=${firstPage.body.nextCursor}`,
        )
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(
        secondPage.body.items.map((m: { sequence: number }) => m.sequence),
      ).toEqual([3, 2]);
    });

    it('synchronizes messages strictly after a checkpoint, oldest first', async () => {
      const { alice, conversationId } = await setup();

      for (let i = 1; i <= 3; i++) {
        await request(app.getHttpServer())
          .post(`/conversations/${conversationId}/messages`)
          .set('Authorization', `Bearer ${alice.accessToken}`)
          .send({ clientMessageId: `s${i}`, content: `message ${i}` })
          .expect(201);
      }

      const res = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/messages/since?afterSequence=1`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(
        res.body.items.map((m: { sequence: number }) => m.sequence),
      ).toEqual([2, 3]);
      expect(res.body.hasMore).toBe(false);
    });

    it('returns an empty page when synchronizing from the latest checkpoint', async () => {
      const { alice, conversationId } = await setup();
      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'only', content: 'hi' })
        .expect(201);

      const res = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/messages/since?afterSequence=1`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(res.body.items).toHaveLength(0);
      expect(res.body.hasMore).toBe(false);
    });
  });

  describe('editing', () => {
    it('allows the sender to edit their own message', async () => {
      const { alice, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      const edited = await request(app.getHttpServer())
        .patch(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ content: 'edited' })
        .expect(200);

      expect(edited.body.content).toBe('edited');
      expect(edited.body.editedAt).not.toBeNull();
    });

    it("forbids editing another sender's message", async () => {
      const { alice, bob, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      const res = await request(app.getHttpServer())
        .patch(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ content: 'hacked' })
        .expect(403);

      expect(res.body.error.code).toBe('FORBIDDEN');
    });

    it('rejects invalid (empty) edit content', async () => {
      const { alice, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      await request(app.getHttpServer())
        .patch(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ content: '' })
        .expect(400);
    });

    it('rejects editing a deleted message', async () => {
      const { alice, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      await request(app.getHttpServer())
        .delete(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      await request(app.getHttpServer())
        .patch(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ content: 'too late' })
        .expect(400);
    });
  });

  describe('deletion', () => {
    it('allows the sender to delete their own message and masks content afterward', async () => {
      const { alice, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'secret' })
        .expect(201);

      await request(app.getHttpServer())
        .delete(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      const fetched = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      expect(fetched.body.content).toBeNull();
      expect(fetched.body.deletedAt).not.toBeNull();
    });

    it("forbids deleting another sender's message", async () => {
      const { alice, bob, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      await request(app.getHttpServer())
        .delete(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .expect(403);
    });

    it('is idempotent: deleting twice both succeed', async () => {
      const { alice, conversationId } = await setup();
      const created = await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'c1', content: 'original' })
        .expect(201);

      await request(app.getHttpServer())
        .delete(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      await request(app.getHttpServer())
        .delete(`/conversations/${conversationId}/messages/${created.body.id}`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);
    });

    it('404s deleting a nonexistent message', async () => {
      const { alice, conversationId } = await setup();
      await request(app.getHttpServer())
        .delete(
          `/conversations/${conversationId}/messages/00000000-0000-0000-0000-000000000000`,
        )
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(404);
    });
  });

  describe('receipts', () => {
    it('records delivery and read checkpoints, never moving them backwards', async () => {
      const { alice, bob, conversationId } = await setup();
      for (let i = 1; i <= 3; i++) {
        await request(app.getHttpServer())
          .post(`/conversations/${conversationId}/messages`)
          .set('Authorization', `Bearer ${alice.accessToken}`)
          .send({ clientMessageId: `m${i}`, content: `message ${i}` })
          .expect(201);
      }

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/receipts/read`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ upToSequence: 3 })
        .expect(204);

      // Acking an older sequence must not move the checkpoint backwards.
      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/receipts/read`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ upToSequence: 1 })
        .expect(204);

      const state = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/receipts`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);

      const bobState = state.body.find(
        (s: { userId: string }) => s.userId === bob.userId,
      );
      expect(bobState.lastReadSequence).toBe(3);
      expect(bobState.lastDeliveredSequence).toBe(3);
    });

    it('is idempotent for duplicate acknowledgements', async () => {
      const { alice, bob, conversationId } = await setup();
      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'hi' })
        .expect(201);

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/receipts/delivered`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ upToSequence: 1 })
        .expect(204);

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/receipts/delivered`)
        .set('Authorization', `Bearer ${bob.accessToken}`)
        .send({ upToSequence: 1 })
        .expect(204);

      const state = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/receipts`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);
      const bobState = state.body.find(
        (s: { userId: string }) => s.userId === bob.userId,
      );
      expect(bobState.lastDeliveredSequence).toBe(1);
    });

    it('rejects receipts from a non-member', async () => {
      const { conversationId } = await setup();
      const carol = await registerUser('carol@example.com', 'carol');

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/receipts/read`)
        .set('Authorization', `Bearer ${carol.accessToken}`)
        .send({ upToSequence: 1 })
        .expect(404);
    });
  });
});
