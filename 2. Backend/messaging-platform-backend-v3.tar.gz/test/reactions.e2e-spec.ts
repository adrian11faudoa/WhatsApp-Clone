import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { Pool } from 'pg';
import { AppModule } from '../src/app.module';
import { DATABASE_POOL } from '../src/database/database.module';
import { truncateAll } from './db-test-helper';

describe('Reactions (e2e)', () => {
  let app: INestApplication;
  let pool: Pool;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    await app.init();
    pool = app.get(DATABASE_POOL);
  });

  afterAll(async () => {
    await app.close();
  });

  beforeEach(async () => {
    await truncateAll(pool);
  });

  async function registerUser(email: string, username: string) {
    const res = await request(app.getHttpServer())
      .post('/auth/register')
      .send({
        email,
        password: 'correct-horse-battery',
        username,
        displayName: username,
      })
      .expect(201);
    return {
      userId: res.body.user.id as string,
      accessToken: res.body.tokens.accessToken as string,
    };
  }

  async function setup() {
    const alice = await registerUser('alice@example.com', 'alice');
    const bob = await registerUser('bob@example.com', 'bob');
    const convoRes = await request(app.getHttpServer())
      .post('/conversations/direct')
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ userId: bob.userId })
      .expect(201);
    const conversationId = convoRes.body.id as string;

    const msgRes = await request(app.getHttpServer())
      .post(`/conversations/${conversationId}/messages`)
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ clientMessageId: 'm1', content: 'Hello' })
      .expect(201);

    return { alice, bob, conversationId, messageId: msgRes.body.id as string };
  }

  it('adds a reaction', async () => {
    const { alice, conversationId, messageId } = await setup();

    const res = await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ value: '👍' })
      .expect(200);

    expect(res.body.value).toBe('👍');
    expect(res.body.userId).toBe(alice.userId);
  });

  it('replaces an existing reaction rather than stacking a second one', async () => {
    const { alice, bob, conversationId, messageId } = await setup();

    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${bob.accessToken}`)
      .send({ value: '👍' })
      .expect(200);

    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${bob.accessToken}`)
      .send({ value: '❤️' })
      .expect(200);

    const summary = await request(app.getHttpServer())
      .get(`/conversations/${conversationId}/messages/${messageId}/reactions`)
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .expect(200);

    expect(summary.body).toHaveLength(1);
    expect(summary.body[0].value).toBe('❤️');
    expect(summary.body[0].userIds).toEqual([bob.userId]);
  });

  it('is idempotent under concurrent duplicate add requests', async () => {
    const { alice, conversationId, messageId } = await setup();

    const requests = Array.from({ length: 5 }, () =>
      request(app.getHttpServer())
        .put(
          `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
        )
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ value: '🎉' }),
    );
    const results = await Promise.all(requests);
    results.forEach((r) => expect(r.status).toBe(200));

    const countRes = await pool.query(
      `SELECT count(*)::int AS count FROM message_reactions WHERE message_id = $1`,
      [messageId],
    );
    expect(countRes.rows[0].count).toBe(1);
  });

  it('removes a reaction and is idempotent on repeat removal', async () => {
    const { alice, conversationId, messageId } = await setup();

    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ value: '👍' })
      .expect(200);

    await request(app.getHttpServer())
      .delete(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .expect(204);

    await request(app.getHttpServer())
      .delete(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .expect(204);

    const summary = await request(app.getHttpServer())
      .get(`/conversations/${conversationId}/messages/${messageId}/reactions`)
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .expect(200);
    expect(summary.body).toHaveLength(0);
  });

  it('groups multiple users reacting with the same value', async () => {
    const { alice, bob, conversationId, messageId } = await setup();

    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ value: '👍' })
      .expect(200);
    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${bob.accessToken}`)
      .send({ value: '👍' })
      .expect(200);

    const summary = await request(app.getHttpServer())
      .get(`/conversations/${conversationId}/messages/${messageId}/reactions`)
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .expect(200);

    expect(summary.body).toHaveLength(1);
    expect(summary.body[0].count).toBe(2);
    expect(summary.body[0].userIds.sort()).toEqual(
      [alice.userId, bob.userId].sort(),
    );
  });

  it('rejects a reaction from a non-member of the conversation', async () => {
    const { conversationId, messageId } = await setup();
    const carol = await registerUser('carol@example.com', 'carol');

    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${carol.accessToken}`)
      .send({ value: '👍' })
      .expect(404);
  });

  it('rejects reacting to a deleted message', async () => {
    const { alice, conversationId, messageId } = await setup();

    await request(app.getHttpServer())
      .delete(`/conversations/${conversationId}/messages/${messageId}`)
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .expect(204);

    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ value: '👍' })
      .expect(400);
  });

  it('rejects an empty reaction value', async () => {
    const { alice, conversationId, messageId } = await setup();
    await request(app.getHttpServer())
      .put(
        `/conversations/${conversationId}/messages/${messageId}/reactions/me`,
      )
      .set('Authorization', `Bearer ${alice.accessToken}`)
      .send({ value: '' })
      .expect(400);
  });
});
