import { Inject, Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import sharp from 'sharp';
import { eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../../database/database.module';
import { mediaAssets, mediaVariants } from '../../database/schema';
import {
  STORAGE_ADAPTER,
  StorageAdapter,
} from '../../storage/storage-adapter.interface';
import { MEDIA_PROCESSING_QUEUE } from '../../jobs/jobs.module';
import { MediaProcessingJobPayload } from '../media.service';

const THUMBNAIL_MAX_DIMENSION = 320;

/**
 * Real image processing (actual thumbnail generation via sharp), not a
 * simulated/fake job. VIDEO/AUDIO/DOCUMENT categories are validated and
 * moved to READY without a generated variant — this milestone
 * deliberately does not include a transcoding pipeline (explicitly
 * out of scope per the prompt: "complete media transcoding
 * infrastructure" / "complete FFmpeg worker fleet"). The job contract
 * (payload, idempotency key, retries, backoff) is real and identical
 * across categories; only the IMAGE path does derived-variant work today.
 */
@Processor(MEDIA_PROCESSING_QUEUE)
export class MediaProcessingWorker extends WorkerHost {
  private readonly logger = new Logger(MediaProcessingWorker.name);

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    @Inject(STORAGE_ADAPTER) private readonly storage: StorageAdapter,
  ) {
    super();
  }

  async process(job: Job<MediaProcessingJobPayload>): Promise<void> {
    const { mediaAssetId } = job.data;

    const [asset] = await this.db
      .select()
      .from(mediaAssets)
      .where(eq(mediaAssets.id, mediaAssetId))
      .limit(1);

    if (!asset) {
      this.logger.warn(
        `Media asset ${mediaAssetId} no longer exists; skipping.`,
      );
      return;
    }
    if (asset.status !== 'UPLOADED') {
      // Already processed (or deleted) — a duplicate/retried job must
      // not reprocess or overwrite state. Idempotent no-op.
      this.logger.debug(
        `Media asset ${mediaAssetId} is not UPLOADED (status: ${asset.status}); skipping.`,
      );
      return;
    }

    await this.db
      .update(mediaAssets)
      .set({ status: 'PROCESSING', updatedAt: new Date() })
      .where(eq(mediaAssets.id, mediaAssetId));

    try {
      if (asset.category === 'IMAGE') {
        await this.processImage(asset);
      }
      // VIDEO/AUDIO/DOCUMENT: validated at upload time (real content-type
      // detection + size checks in MediaService.completeUpload); no
      // further derived-variant processing is implemented in this
      // milestone.

      await this.db
        .update(mediaAssets)
        .set({ status: 'READY', updatedAt: new Date() })
        .where(eq(mediaAssets.id, mediaAssetId));
    } catch (err) {
      this.logger.error(
        `Media processing failed for ${mediaAssetId}: ${(err as Error).message}`,
      );
      await this.db
        .update(mediaAssets)
        .set({
          status: 'FAILED',
          failureReason: (err as Error).message,
          updatedAt: new Date(),
        })
        .where(eq(mediaAssets.id, mediaAssetId));
      throw err; // let BullMQ retry per the queue's configured attempts/backoff
    }
  }

  private async processImage(
    asset: typeof mediaAssets.$inferSelect,
  ): Promise<void> {
    const original = await this.storage.getObject(asset.storageKey);
    if (!original) {
      throw new Error(
        `Original object missing from storage: ${asset.storageKey}`,
      );
    }

    const image = sharp(original.data);
    const metadata = await image.metadata();

    await this.db
      .update(mediaAssets)
      .set({
        widthPx: metadata.width ?? null,
        heightPx: metadata.height ?? null,
      })
      .where(eq(mediaAssets.id, asset.id));

    const thumbnailBuffer = await image
      .resize(THUMBNAIL_MAX_DIMENSION, THUMBNAIL_MAX_DIMENSION, {
        fit: 'inside',
      })
      .jpeg({ quality: 80 })
      .toBuffer();
    const thumbnailMeta = await sharp(thumbnailBuffer).metadata();

    const thumbnailKey = `${asset.storageKey}-thumbnail`;
    await this.storage.putObject(thumbnailKey, thumbnailBuffer, 'image/jpeg');

    await this.db
      .insert(mediaVariants)
      .values({
        mediaAssetId: asset.id,
        kind: 'THUMBNAIL',
        storageKey: thumbnailKey,
        contentType: 'image/jpeg',
        widthPx: thumbnailMeta.width ?? null,
        heightPx: thumbnailMeta.height ?? null,
        sizeBytes: thumbnailBuffer.length,
      })
      .onConflictDoNothing();

    await this.db
      .insert(mediaVariants)
      .values({
        mediaAssetId: asset.id,
        kind: 'ORIGINAL',
        storageKey: asset.storageKey,
        contentType: asset.detectedContentType ?? asset.declaredContentType,
        widthPx: metadata.width ?? null,
        heightPx: metadata.height ?? null,
        sizeBytes: asset.actualSizeBytes ?? original.data.length,
      })
      .onConflictDoNothing();
  }
}
