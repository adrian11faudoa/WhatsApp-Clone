import { Inject, Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import {
  STORAGE_ADAPTER,
  StorageAdapter,
} from '../../storage/storage-adapter.interface';
import { MEDIA_CLEANUP_QUEUE } from '../../jobs/jobs.module';
import { MediaCleanupJobPayload } from '../media.service';

/**
 * Deletes the underlying storage objects for a media asset that has
 * already been marked DELETED in the database. Runs asynchronously so
 * the delete API response doesn't wait on storage I/O, and is safe to
 * retry: deleting an already-deleted (or never-existing) object is a
 * no-op in StorageAdapter.deleteObject.
 */
@Processor(MEDIA_CLEANUP_QUEUE)
export class MediaCleanupWorker extends WorkerHost {
  private readonly logger = new Logger(MediaCleanupWorker.name);

  constructor(
    @Inject(STORAGE_ADAPTER) private readonly storage: StorageAdapter,
  ) {
    super();
  }

  async process(job: Job<MediaCleanupJobPayload>): Promise<void> {
    for (const key of job.data.storageKeys) {
      try {
        await this.storage.deleteObject(key);
      } catch (err) {
        this.logger.warn(
          `Failed to delete storage object ${key}, will retry via job backoff: ${(err as Error).message}`,
        );
        throw err;
      }
    }
  }
}
