import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Inject,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { Request, Response } from 'express';
import { Throttle } from '@nestjs/throttler';
import { MediaService } from './media.service';
import { MediaUrlSignerService } from '../storage/media-url-signer.service';
import {
  STORAGE_ADAPTER,
  StorageAdapter,
} from '../storage/storage-adapter.interface';
import {
  InitiateUploadDto,
  InitiateUploadResponseDto,
  MediaAssetResponseDto,
} from './dto/media.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Public } from '../common/decorators/public.decorator';
import {
  CurrentUser,
  AuthenticatedUser,
} from '../common/decorators/current-user.decorator';
import { AppException } from '../common/errors/app.exception';
import { AppErrorCode } from '../common/errors/app-error-codes';

@ApiTags('media')
@Controller('media')
export class MediaController {
  constructor(
    private readonly mediaService: MediaService,
    private readonly urlSigner: MediaUrlSignerService,
    @Inject(STORAGE_ADAPTER) private readonly storage: StorageAdapter,
  ) {}

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @Post()
  @ApiOperation({
    summary: 'Initiate a media upload; returns a short-lived upload URL.',
  })
  initiate(
    @CurrentUser() user: AuthenticatedUser,
    @Body() dto: InitiateUploadDto,
  ): Promise<InitiateUploadResponseDto> {
    return this.mediaService.initiateUpload(user.userId, dto);
  }

  /**
   * Authorization here comes from the signed upload token itself (like
   * an S3 presigned URL) rather than a session Bearer token — see
   * MediaUrlSignerService. `@Public()` only exempts this route from the
   * *session* JwtAuthGuard; the token param below is still mandatorily
   * verified before any upload is accepted.
   */
  @Public()
  @Throttle({ default: { limit: 30, ttl: 60_000 } })
  @Put('upload/:token')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({
    name: 'token',
    description: 'Signed upload token from POST /media.',
  })
  @ApiOperation({
    summary:
      'Upload the raw file bytes for a previously initiated media asset.',
  })
  async upload(
    @Param('token') token: string,
    @Req() req: Request,
  ): Promise<void> {
    let payload;
    try {
      payload = this.urlSigner.verify(token, 'media_upload');
    } catch {
      throw new AppException({
        code: AppErrorCode.UNAUTHENTICATED,
        message: 'Upload token is invalid or has expired.',
        status: HttpStatus.UNAUTHORIZED,
      });
    }

    // Populated by the express.raw() middleware scoped to this path in
    // main.ts — req.body is a Buffer here, not a parsed JSON object.
    const body = req.body;
    if (!Buffer.isBuffer(body) || body.length === 0) {
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: 'Request body must be the raw file bytes.',
        status: HttpStatus.BAD_REQUEST,
      });
    }

    await this.mediaService.completeUpload(
      payload.mediaAssetId,
      payload.storageKey,
      body,
    );
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @Get(':mediaAssetId')
  @ApiParam({ name: 'mediaAssetId', format: 'uuid' })
  @ApiOperation({
    summary: 'Get media metadata and signed variant download URLs.',
  })
  get(
    @CurrentUser() user: AuthenticatedUser,
    @Param('mediaAssetId', ParseUUIDPipe) mediaAssetId: string,
  ): Promise<MediaAssetResponseDto> {
    return this.mediaService.getMediaAsset(user.userId, mediaAssetId);
  }

  /**
   * Like the upload route, authorization is the signed token itself —
   * MediaService.getMediaAsset already performed the real conversation-
   * membership/ownership check when it issued this token, so re-checking
   * session identity here would be redundant, not additional security.
   */
  @Public()
  @Get('download/:token')
  @ApiParam({
    name: 'token',
    description: 'Signed download token from GET /media/:id.',
  })
  @ApiOperation({
    summary: 'Stream the bytes for a signed media download token.',
  })
  async download(
    @Param('token') token: string,
    @Res() res: Response,
  ): Promise<void> {
    let payload;
    try {
      payload = this.urlSigner.verify(token, 'media_download');
    } catch {
      throw new AppException({
        code: AppErrorCode.UNAUTHENTICATED,
        message: 'Download token is invalid or has expired.',
        status: HttpStatus.UNAUTHORIZED,
      });
    }

    const object = await this.storage.getObject(payload.storageKey);
    if (!object) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Media object not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    res.setHeader('Content-Type', object.contentType);
    res.setHeader('Content-Length', object.data.length);
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.send(object.data);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @Delete(':mediaAssetId')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({ name: 'mediaAssetId', format: 'uuid' })
  @ApiOperation({ summary: 'Delete a media asset (owner only, idempotent).' })
  async remove(
    @CurrentUser() user: AuthenticatedUser,
    @Param('mediaAssetId', ParseUUIDPipe) mediaAssetId: string,
  ): Promise<void> {
    await this.mediaService.deleteMedia(user.userId, mediaAssetId);
  }
}
