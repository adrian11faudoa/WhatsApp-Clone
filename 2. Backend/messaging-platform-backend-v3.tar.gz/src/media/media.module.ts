import { Module } from '@nestjs/common';
import { MediaController } from './media.controller';
import { MediaService } from './media.service';
import { MediaProcessingWorker } from './jobs/media-processing.worker';
import { MediaCleanupWorker } from './jobs/media-cleanup.worker';
import { StorageModule } from '../storage/storage.module';
import { JobsModule } from '../jobs/jobs.module';
import { ConversationsModule } from '../conversations/conversations.module';
import { AuditService } from '../common/audit/audit.service';

@Module({
  imports: [StorageModule, JobsModule, ConversationsModule],
  controllers: [MediaController],
  providers: [
    MediaService,
    MediaProcessingWorker,
    MediaCleanupWorker,
    AuditService,
  ],
  exports: [MediaService],
})
export class MediaModule {}
