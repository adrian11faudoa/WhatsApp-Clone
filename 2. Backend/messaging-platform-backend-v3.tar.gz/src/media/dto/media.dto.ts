import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  MaxLength,
  Min,
} from 'class-validator';

export const MEDIA_CATEGORIES = [
  'IMAGE',
  'VIDEO',
  'AUDIO',
  'DOCUMENT',
] as const;
export type MediaCategory = (typeof MEDIA_CATEGORIES)[number];

export class InitiateUploadDto {
  @ApiProperty({ enum: MEDIA_CATEGORIES })
  @IsIn(MEDIA_CATEGORIES)
  category!: MediaCategory;

  @ApiProperty({ example: 'image/png' })
  @IsString()
  @MaxLength(255)
  declaredContentType!: string;

  @ApiProperty({
    description:
      'Declared size in bytes, validated against per-category limits.',
  })
  @IsInt()
  @Min(1)
  declaredSizeBytes!: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  originalFilename?: string;
}

export class InitiateUploadResponseDto {
  @ApiProperty()
  mediaAssetId!: string;

  @ApiProperty({
    description:
      'Relative path to PUT the raw file bytes to (Content-Type header must match declaredContentType).',
  })
  uploadUrl!: string;

  @ApiProperty()
  uploadUrlExpiresAt!: Date;

  @ApiProperty()
  maxSizeBytes!: number;
}

export class MediaVariantDto {
  @ApiProperty({ enum: ['ORIGINAL', 'THUMBNAIL', 'PREVIEW'] })
  kind!: string;

  @ApiProperty()
  contentType!: string;

  @ApiPropertyOptional()
  widthPx?: number | null;

  @ApiPropertyOptional()
  heightPx?: number | null;

  @ApiProperty()
  sizeBytes!: number;

  @ApiProperty({
    description: 'Short-lived signed download URL for this variant.',
  })
  downloadUrl!: string;

  @ApiProperty()
  downloadUrlExpiresAt!: Date;
}

export class MediaAssetResponseDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  ownerId!: string;

  @ApiProperty()
  category!: string;

  @ApiProperty()
  status!: string;

  @ApiProperty()
  declaredContentType!: string;

  @ApiPropertyOptional()
  detectedContentType?: string | null;

  @ApiProperty()
  declaredSizeBytes!: number;

  @ApiPropertyOptional()
  actualSizeBytes?: number | null;

  @ApiPropertyOptional()
  originalFilename?: string | null;

  @ApiPropertyOptional()
  widthPx?: number | null;

  @ApiPropertyOptional()
  heightPx?: number | null;

  @ApiPropertyOptional()
  failureReason?: string | null;

  @ApiProperty()
  createdAt!: Date;

  @ApiProperty()
  updatedAt!: Date;

  @ApiPropertyOptional({
    type: [MediaVariantDto],
    description: 'Only populated once status is READY.',
  })
  variants?: MediaVariantDto[];
}
