import { HttpStatus, Inject, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { randomUUID, createHash } from 'crypto';
import { and, eq, isNull } from 'drizzle-orm';
import { fromBuffer } from 'file-type';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import {
  mediaAssets,
  mediaVariants,
  messageAttachments,
  messages,
} from '../database/schema';
import { AppException } from '../common/errors/app.exception';
import { AppErrorCode } from '../common/errors/app-error-codes';
import { AuditService } from '../common/audit/audit.service';
import {
  STORAGE_ADAPTER,
  StorageAdapter,
} from '../storage/storage-adapter.interface';
import { MediaUrlSignerService } from '../storage/media-url-signer.service';
import {
  MEDIA_PROCESSING_QUEUE,
  MEDIA_CLEANUP_QUEUE,
} from '../jobs/jobs.module';
import { ConversationMembershipService } from '../conversations/conversation-membership.service';
import {
  InitiateUploadDto,
  InitiateUploadResponseDto,
  MediaAssetResponseDto,
  MediaCategory,
} from './dto/media.dto';

export interface MediaProcessingJobPayload {
  mediaAssetId: string;
}

export interface MediaCleanupJobPayload {
  storageKeys: string[];
}

@Injectable()
export class MediaService {
  private readonly logger = new Logger(MediaService.name);

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    @Inject(STORAGE_ADAPTER) private readonly storage: StorageAdapter,
    private readonly urlSigner: MediaUrlSignerService,
    private readonly auditService: AuditService,
    private readonly config: ConfigService,
    private readonly membershipService: ConversationMembershipService,
    @InjectQueue(MEDIA_PROCESSING_QUEUE)
    private readonly processingQueue: Queue<MediaProcessingJobPayload>,
    @InjectQueue(MEDIA_CLEANUP_QUEUE)
    private readonly cleanupQueue: Queue<MediaCleanupJobPayload>,
  ) {}

  async initiateUpload(
    ownerId: string,
    dto: InitiateUploadDto,
  ): Promise<InitiateUploadResponseDto> {
    const maxBytes = this.maxBytesForCategory(dto.category);
    if (dto.declaredSizeBytes > maxBytes) {
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: `${dto.category} uploads may not exceed ${maxBytes} bytes.`,
        status: HttpStatus.BAD_REQUEST,
      });
    }

    const mediaAssetId = randomUUID();
    const storageKey = `media/${ownerId}/${mediaAssetId}/original`;

    await this.db.insert(mediaAssets).values({
      id: mediaAssetId,
      ownerId,
      category: dto.category,
      status: 'INITIATED',
      storageProvider: 'LOCAL',
      storageKey,
      declaredContentType: dto.declaredContentType,
      declaredSizeBytes: dto.declaredSizeBytes,
      originalFilename: dto.originalFilename,
    });

    await this.auditService.record({
      type: 'MEDIA_UPLOAD_INITIATED',
      userId: ownerId,
      metadata: { mediaAssetId, category: dto.category },
    });

    const { token, expiresAt } = this.urlSigner.signUploadToken(
      mediaAssetId,
      storageKey,
    );

    return {
      mediaAssetId,
      uploadUrl: `media/upload/${token}`,
      uploadUrlExpiresAt: expiresAt,
      maxSizeBytes: maxBytes,
    };
  }

  /**
   * Receives the raw uploaded bytes (called by the controller after it
   * verifies the signed upload token). Every byte is treated as
   * untrusted regardless of what the client declared: actual size is
   * checked against the category limit and the originally declared
   * size, and content type is detected from the file's magic bytes
   * (never taken from the client-supplied header or declaredContentType).
   */
  async completeUpload(
    mediaAssetId: string,
    storageKey: string,
    data: Buffer,
  ): Promise<void> {
    const [asset] = await this.db
      .select()
      .from(mediaAssets)
      .where(eq(mediaAssets.id, mediaAssetId))
      .limit(1);

    if (!asset || asset.storageKey !== storageKey) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Media asset not found for this upload token.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    if (asset.status !== 'INITIATED' && asset.status !== 'FAILED') {
      throw new AppException({
        code: AppErrorCode.CONFLICT,
        message: `Media asset is not awaiting upload (status: ${asset.status}).`,
        status: HttpStatus.CONFLICT,
      });
    }

    const maxBytes = this.maxBytesForCategory(asset.category as MediaCategory);
    if (data.length > maxBytes || data.length > asset.declaredSizeBytes) {
      await this.markFailed(
        mediaAssetId,
        'Uploaded size exceeded declared/category limit.',
      );
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: 'Uploaded file exceeds the declared or category size limit.',
        status: HttpStatus.BAD_REQUEST,
      });
    }

    const detected = await fromBuffer(data);
    const detectedContentType = detected?.mime ?? 'application/octet-stream';
    const checksum = createHash('sha256').update(data).digest('hex');

    await this.storage.putObject(storageKey, data, detectedContentType);

    await this.db
      .update(mediaAssets)
      .set({
        status: 'UPLOADED',
        actualSizeBytes: data.length,
        detectedContentType,
        checksumSha256: checksum,
        updatedAt: new Date(),
      })
      .where(eq(mediaAssets.id, mediaAssetId));

    await this.processingQueue.add(
      'process',
      { mediaAssetId },
      {
        jobId: `process-${mediaAssetId}`, // idempotency key — a re-enqueue for the same asset dedupes
        attempts: 3,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: true,
        removeOnFail: 100,
      },
    );
  }

  async getMediaAsset(
    userId: string,
    mediaAssetId: string,
  ): Promise<MediaAssetResponseDto> {
    const asset = await this.assertReadableAsset(userId, mediaAssetId);

    const variantRows =
      asset.status === 'READY'
        ? await this.db
            .select()
            .from(mediaVariants)
            .where(eq(mediaVariants.mediaAssetId, mediaAssetId))
        : [];

    return {
      id: asset.id,
      ownerId: asset.ownerId,
      category: asset.category,
      status: asset.status,
      declaredContentType: asset.declaredContentType,
      detectedContentType: asset.detectedContentType,
      declaredSizeBytes: asset.declaredSizeBytes,
      actualSizeBytes: asset.actualSizeBytes,
      originalFilename: asset.originalFilename,
      widthPx: asset.widthPx,
      heightPx: asset.heightPx,
      failureReason: asset.failureReason,
      createdAt: asset.createdAt,
      updatedAt: asset.updatedAt,
      variants: variantRows.map((v) => {
        const { token, expiresAt } = this.urlSigner.signDownloadToken(
          asset.id,
          v.storageKey,
          v.kind,
        );
        return {
          kind: v.kind,
          contentType: v.contentType,
          widthPx: v.widthPx,
          heightPx: v.heightPx,
          sizeBytes: v.sizeBytes,
          downloadUrl: `media/download/${token}`,
          downloadUrlExpiresAt: expiresAt,
        };
      }),
    };
  }

  /** Used by MessagesService to validate attachmentIds at message-creation time. */
  async assertOwnedReadyAsset(
    userId: string,
    mediaAssetId: string,
  ): Promise<void> {
    const [asset] = await this.db
      .select({
        id: mediaAssets.id,
        ownerId: mediaAssets.ownerId,
        status: mediaAssets.status,
      })
      .from(mediaAssets)
      .where(eq(mediaAssets.id, mediaAssetId))
      .limit(1);

    if (!asset || asset.ownerId !== userId) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: `Media asset ${mediaAssetId} not found.`,
        status: HttpStatus.NOT_FOUND,
      });
    }
    if (asset.status !== 'READY') {
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: `Media asset ${mediaAssetId} is not ready to attach (status: ${asset.status}).`,
        status: HttpStatus.BAD_REQUEST,
      });
    }

    const [alreadyAttached] = await this.db
      .select({ id: messageAttachments.id })
      .from(messageAttachments)
      .where(eq(messageAttachments.mediaAssetId, mediaAssetId))
      .limit(1);
    if (alreadyAttached) {
      throw new AppException({
        code: AppErrorCode.CONFLICT,
        message: `Media asset ${mediaAssetId} is already attached to a message.`,
        status: HttpStatus.CONFLICT,
      });
    }
  }

  async deleteMedia(userId: string, mediaAssetId: string): Promise<void> {
    const [asset] = await this.db
      .select()
      .from(mediaAssets)
      .where(eq(mediaAssets.id, mediaAssetId))
      .limit(1);

    if (!asset) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Media asset not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }
    if (asset.ownerId !== userId) {
      throw new AppException({
        code: AppErrorCode.FORBIDDEN,
        message: 'Only the uploader can delete this media asset.',
        status: HttpStatus.FORBIDDEN,
      });
    }
    if (asset.status === 'DELETED') {
      return; // idempotent
    }

    const variantRows = await this.db
      .select({ storageKey: mediaVariants.storageKey })
      .from(mediaVariants)
      .where(eq(mediaVariants.mediaAssetId, mediaAssetId));

    await this.db
      .update(mediaAssets)
      .set({ status: 'DELETED', deletedAt: new Date(), updatedAt: new Date() })
      .where(eq(mediaAssets.id, mediaAssetId));

    // Physical deletion is asynchronous — durable metadata state
    // (DELETED) is authoritative immediately; the object-storage cleanup
    // is a best-effort follow-up that can retry independently of the
    // request/response cycle.
    await this.cleanupQueue.add(
      'cleanup',
      {
        storageKeys: [
          asset.storageKey,
          ...variantRows.map((v) => v.storageKey),
        ],
      },
      {
        attempts: 5,
        backoff: { type: 'exponential', delay: 3000 },
        removeOnComplete: true,
      },
    );

    await this.auditService.record({
      type: 'MEDIA_DELETED',
      userId,
      metadata: { mediaAssetId },
    });
  }

  // ---------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------

  private async markFailed(
    mediaAssetId: string,
    reason: string,
  ): Promise<void> {
    await this.db
      .update(mediaAssets)
      .set({ status: 'FAILED', failureReason: reason, updatedAt: new Date() })
      .where(eq(mediaAssets.id, mediaAssetId));
  }

  /**
   * Media access is authorized independently of message/UI visibility:
   * the owner can always read their own asset (any status); anyone else
   * needs a fuller check — for this milestone, that means the asset must
   * be attached to a message in a conversation the requester actively
   * belongs to. Not-yet-attached assets are owner-only.
   */
  private async assertReadableAsset(userId: string, mediaAssetId: string) {
    const [asset] = await this.db
      .select()
      .from(mediaAssets)
      .where(
        and(eq(mediaAssets.id, mediaAssetId), isNull(mediaAssets.deletedAt)),
      )
      .limit(1);

    if (!asset) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Media asset not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    if (asset.ownerId === userId) {
      return asset;
    }

    const [attachment] = await this.db
      .select({
        messageId: messageAttachments.messageId,
        conversationId: messages.conversationId,
      })
      .from(messageAttachments)
      .innerJoin(messages, eq(messageAttachments.messageId, messages.id))
      .where(eq(messageAttachments.mediaAssetId, mediaAssetId))
      .limit(1);

    if (!attachment) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Media asset not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    // Throws NOT_FOUND (not FORBIDDEN) for a non-member, matching the
    // same "don't confirm existence to unauthorized callers" pattern
    // used throughout — see ConversationMembershipService.
    await this.membershipService.assertActiveMember(
      userId,
      attachment.conversationId,
    );

    return asset;
  }

  private maxBytesForCategory(category: MediaCategory | string): number {
    switch (category) {
      case 'IMAGE':
        return this.config.get<number>('media.maxImageBytes') as number;
      case 'VIDEO':
        return this.config.get<number>('media.maxVideoBytes') as number;
      case 'AUDIO':
        return this.config.get<number>('media.maxAudioBytes') as number;
      case 'DOCUMENT':
      default:
        return this.config.get<number>('media.maxDocumentBytes') as number;
    }
  }
}
