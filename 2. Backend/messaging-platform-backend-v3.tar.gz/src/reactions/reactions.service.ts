import { HttpStatus, Inject, Injectable } from '@nestjs/common';
import { and, eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { messageReactions, messageOutbox, messages } from '../database/schema';
import { AppException } from '../common/errors/app.exception';
import { AppErrorCode } from '../common/errors/app-error-codes';
import { AuditService } from '../common/audit/audit.service';
import { ConversationMembershipService } from '../conversations/conversation-membership.service';
import { RealtimeEventType } from '../realtime/realtime-envelope';
import { OutboxPublisherService } from '../realtime/outbox-publisher.service';
import { ReactionResponseDto, ReactionSummaryDto } from './dto/reaction.dto';

@Injectable()
export class ReactionsService {
  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly membershipService: ConversationMembershipService,
    private readonly auditService: AuditService,
    private readonly outboxPublisher: OutboxPublisherService,
  ) {}

  /**
   * Upsert on (messageId, userId): picking a new value replaces the
   * user's existing reaction rather than adding a second one — this is
   * both the product model (one reaction per user per message) and what
   * makes duplicate/concurrent "add" requests converge deterministically
   * without a separate uniqueness precheck.
   */
  async addReaction(
    userId: string,
    conversationId: string,
    messageId: string,
    value: string,
  ): Promise<ReactionResponseDto> {
    await this.membershipService.assertActiveMember(userId, conversationId);
    await this.assertReactableMessage(conversationId, messageId);

    const { row, outboxRowId } = await this.db.transaction(async (tx) => {
      const now = new Date();

      // Atomic upsert on the (message_id, user_id) unique index — not a
      // select-then-insert/update. The earlier check-then-act version of
      // this method had exactly the race the project's concurrency
      // requirements warn against: two simultaneous adds could both see
      // "no existing row" and both attempt an insert, and the loser
      // crashed with an unhandled unique-violation instead of
      // converging. A real concurrency test (8 parallel identical
      // requests) caught this. ON CONFLICT DO UPDATE makes the
      // operation a single atomic statement, so there is no window
      // between the check and the write for a second request to land in.
      const [inserted] = await tx
        .insert(messageReactions)
        .values({ messageId, conversationId, userId, value })
        .onConflictDoUpdate({
          target: [messageReactions.messageId, messageReactions.userId],
          set: { value, updatedAt: now },
        })
        .returning();

      const dto = this.toResponseDto(inserted);

      const [outboxRow] = await tx
        .insert(messageOutbox)
        .values({
          aggregateType: 'reaction',
          aggregateId: inserted.id,
          conversationId,
          eventType: RealtimeEventType.REACTION_ADDED,
          payload: dto,
        })
        .returning({ id: messageOutbox.id });

      return { row: dto, outboxRowId: outboxRow.id };
    });

    await this.auditService.record({
      type: 'REACTION_ADDED',
      userId,
      metadata: { messageId, conversationId, value },
    });

    this.outboxPublisher.tryPublishImmediately(outboxRowId).catch(() => {
      /* poller retries; see OutboxPublisherService */
    });

    return row;
  }

  /** Idempotent: removing a reaction that doesn't exist is a no-op success. */
  async removeReaction(
    userId: string,
    conversationId: string,
    messageId: string,
  ): Promise<void> {
    await this.membershipService.assertActiveMember(userId, conversationId);

    const outboxRowId = await this.db.transaction(async (tx) => {
      const [deleted] = await tx
        .delete(messageReactions)
        .where(
          and(
            eq(messageReactions.messageId, messageId),
            eq(messageReactions.userId, userId),
          ),
        )
        .returning({ id: messageReactions.id });

      if (!deleted) {
        return null;
      }

      const [outboxRow] = await tx
        .insert(messageOutbox)
        .values({
          aggregateType: 'reaction',
          aggregateId: deleted.id,
          conversationId,
          eventType: RealtimeEventType.REACTION_REMOVED,
          payload: { messageId, conversationId, userId },
        })
        .returning({ id: messageOutbox.id });

      return outboxRow.id;
    });

    if (!outboxRowId) return;

    await this.auditService.record({
      type: 'REACTION_REMOVED',
      userId,
      metadata: { messageId, conversationId },
    });

    this.outboxPublisher.tryPublishImmediately(outboxRowId).catch(() => {
      /* poller retries */
    });
  }

  async getReactions(
    userId: string,
    conversationId: string,
    messageId: string,
  ): Promise<ReactionSummaryDto[]> {
    await this.membershipService.assertActiveMember(userId, conversationId);

    const rows = await this.db
      .select({
        value: messageReactions.value,
        userId: messageReactions.userId,
      })
      .from(messageReactions)
      .where(eq(messageReactions.messageId, messageId));

    const byValue = new Map<string, string[]>();
    for (const row of rows) {
      const list = byValue.get(row.value) ?? [];
      list.push(row.userId);
      byValue.set(row.value, list);
    }

    return Array.from(byValue.entries()).map(([value, userIds]) => ({
      value,
      userIds,
      count: userIds.length,
    }));
  }

  private async assertReactableMessage(
    conversationId: string,
    messageId: string,
  ): Promise<void> {
    const [message] = await this.db
      .select({ id: messages.id, deletedAt: messages.deletedAt })
      .from(messages)
      .where(
        and(
          eq(messages.id, messageId),
          eq(messages.conversationId, conversationId),
        ),
      )
      .limit(1);

    if (!message) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Message not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }
    if (message.deletedAt) {
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: 'Cannot react to a deleted message.',
        status: HttpStatus.BAD_REQUEST,
      });
    }
  }

  private toResponseDto(
    row: typeof messageReactions.$inferSelect,
  ): ReactionResponseDto {
    return {
      id: row.id,
      messageId: row.messageId,
      userId: row.userId,
      value: row.value,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }
}
