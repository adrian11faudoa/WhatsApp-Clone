import { Module } from '@nestjs/common';
import { ReactionsController } from './reactions.controller';
import { ReactionsService } from './reactions.service';
import { ConversationsModule } from '../conversations/conversations.module';
import { RealtimeModule } from '../realtime/realtime.module';
import { AuditService } from '../common/audit/audit.service';

@Module({
  imports: [ConversationsModule, RealtimeModule],
  controllers: [ReactionsController],
  providers: [ReactionsService, AuditService],
})
export class ReactionsModule {}
