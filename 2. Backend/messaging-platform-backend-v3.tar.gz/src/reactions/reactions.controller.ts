import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Put,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { ReactionsService } from './reactions.service';
import {
  AddReactionDto,
  ReactionResponseDto,
  ReactionSummaryDto,
} from './dto/reaction.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
  CurrentUser,
  AuthenticatedUser,
} from '../common/decorators/current-user.decorator';

@ApiTags('reactions')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('conversations/:conversationId/messages/:messageId/reactions')
export class ReactionsController {
  constructor(private readonly reactionsService: ReactionsService) {}

  @Get()
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiParam({ name: 'messageId', format: 'uuid' })
  @ApiOperation({
    summary: 'Get reaction summary for a message, grouped by value.',
  })
  list(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Param('messageId', ParseUUIDPipe) messageId: string,
  ): Promise<ReactionSummaryDto[]> {
    return this.reactionsService.getReactions(
      user.userId,
      conversationId,
      messageId,
    );
  }

  @Put('me')
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiParam({ name: 'messageId', format: 'uuid' })
  @ApiOperation({
    summary:
      "Set the caller's reaction on a message (replaces any existing reaction).",
  })
  set(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Param('messageId', ParseUUIDPipe) messageId: string,
    @Body() dto: AddReactionDto,
  ): Promise<ReactionResponseDto> {
    return this.reactionsService.addReaction(
      user.userId,
      conversationId,
      messageId,
      dto.value,
    );
  }

  @Delete('me')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiParam({ name: 'messageId', format: 'uuid' })
  @ApiOperation({ summary: "Remove the caller's reaction (idempotent)." })
  async remove(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Param('messageId', ParseUUIDPipe) messageId: string,
  ): Promise<void> {
    await this.reactionsService.removeReaction(
      user.userId,
      conversationId,
      messageId,
    );
  }
}
