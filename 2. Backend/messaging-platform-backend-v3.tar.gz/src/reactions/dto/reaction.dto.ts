import { ApiProperty } from '@nestjs/swagger';
import { IsString, MaxLength, MinLength } from 'class-validator';

/**
 * Reaction values are validated as "a short string" rather than against
 * a fixed emoji allowlist — the product spec doesn't define one, and a
 * hardcoded allowlist would be an arbitrary product decision this
 * milestone shouldn't invent. Length bounds prevent abuse (e.g. someone
 * submitting paragraphs of text as a "reaction").
 */
export class AddReactionDto {
  @ApiProperty({ example: '👍', maxLength: 32 })
  @IsString()
  @MinLength(1)
  @MaxLength(32)
  value!: string;
}

export class ReactionResponseDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  messageId!: string;

  @ApiProperty()
  userId!: string;

  @ApiProperty()
  value!: string;

  @ApiProperty()
  createdAt!: Date;

  @ApiProperty()
  updatedAt!: Date;
}

export class ReactionSummaryDto {
  @ApiProperty({ description: 'The reaction value, e.g. an emoji.' })
  value!: string;

  @ApiProperty({ type: [String] })
  userIds!: string[];

  @ApiProperty()
  count!: number;
}
