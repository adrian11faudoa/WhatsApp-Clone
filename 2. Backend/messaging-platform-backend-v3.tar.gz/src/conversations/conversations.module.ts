import { Module } from '@nestjs/common';
import { ConversationsController } from './conversations.controller';
import { ConversationsService } from './conversations.service';
import { ConversationMembershipService } from './conversation-membership.service';
import { AuditService } from '../common/audit/audit.service';

@Module({
  controllers: [ConversationsController],
  providers: [
    ConversationsService,
    AuditService,
    ConversationMembershipService,
  ],
  exports: [ConversationsService, ConversationMembershipService],
})
export class ConversationsModule {}
