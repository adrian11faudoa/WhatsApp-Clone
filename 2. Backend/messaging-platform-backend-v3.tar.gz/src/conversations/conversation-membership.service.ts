import { HttpStatus, Inject, Injectable } from '@nestjs/common';
import { and, eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { conversationMembers, conversations } from '../database/schema';
import { AppException } from '../common/errors/app.exception';
import { AppErrorCode } from '../common/errors/app-error-codes';

/**
 * The single source of truth for "is this user allowed to read/act on
 * this conversation." Both ConversationsService and MessagesService (and
 * the realtime gateway) route through this rather than each
 * implementing their own membership check, so there is exactly one place
 * that decides conversation access.
 */
@Injectable()
export class ConversationMembershipService {
  constructor(@Inject(DATABASE_CONNECTION) private readonly db: Database) {}

  /**
   * Confirms the user is an ACTIVE member of the conversation. Throws
   * NOT_FOUND (never FORBIDDEN) for both "conversation doesn't exist"
   * and "user isn't a member" — the two must be indistinguishable to the
   * caller, or a non-member could confirm a conversation's existence by
   * ID alone (an IDOR-adjacent information leak).
   */
  async assertActiveMember(userId: string, conversationId: string) {
    const [membership] = await this.db
      .select()
      .from(conversationMembers)
      .where(
        and(
          eq(conversationMembers.conversationId, conversationId),
          eq(conversationMembers.userId, userId),
          eq(conversationMembers.status, 'ACTIVE'),
        ),
      )
      .limit(1);

    if (!membership) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Conversation not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    return membership;
  }

  async getConversationType(
    conversationId: string,
  ): Promise<'DIRECT' | 'GROUP' | null> {
    const [conversation] = await this.db
      .select({ type: conversations.type })
      .from(conversations)
      .where(eq(conversations.id, conversationId))
      .limit(1);
    return conversation?.type ?? null;
  }

  async listActiveMemberIds(conversationId: string): Promise<string[]> {
    const rows = await this.db
      .select({ userId: conversationMembers.userId })
      .from(conversationMembers)
      .where(
        and(
          eq(conversationMembers.conversationId, conversationId),
          eq(conversationMembers.status, 'ACTIVE'),
        ),
      );
    return rows.map((r) => r.userId);
  }

  /** All conversation IDs a user is currently an active member of — used
   * by the realtime gateway to compute which rooms a new connection
   * should join. */
  async listActiveConversationIdsForUser(userId: string): Promise<string[]> {
    const rows = await this.db
      .select({ conversationId: conversationMembers.conversationId })
      .from(conversationMembers)
      .where(
        and(
          eq(conversationMembers.userId, userId),
          eq(conversationMembers.status, 'ACTIVE'),
        ),
      );
    return rows.map((r) => r.conversationId);
  }
}
