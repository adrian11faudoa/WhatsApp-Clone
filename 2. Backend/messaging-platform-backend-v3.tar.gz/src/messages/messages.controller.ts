import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt, IsOptional, Min } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { MessagesService } from './messages.service';
import {
  CreateMessageDto,
  EditMessageDto,
  MessageResponseDto,
} from './dto/message.dto';
import { AcknowledgeDto, ConversationReceiptStateDto } from './dto/receipt.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
  CurrentUser,
  AuthenticatedUser,
} from '../common/decorators/current-user.decorator';

class HistoryQueryDto {
  @ApiPropertyOptional({
    description: 'Return messages older than this sequence.',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  beforeSequence?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}

class SinceQueryDto {
  @ApiPropertyOptional({ default: 0 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  afterSequence?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}

@ApiTags('messages')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('conversations/:conversationId/messages')
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  @Post()
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiOperation({
    summary:
      'Send a message (REST alternative to the send_message WS command). Idempotent on clientMessageId.',
  })
  create(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body() dto: CreateMessageDto,
  ): Promise<MessageResponseDto> {
    return this.messagesService.createMessage(user.userId, conversationId, dto);
  }

  @Get()
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiOperation({
    summary:
      'Browse conversation history, most recent first, paginated backwards via beforeSequence.',
  })
  listHistory(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Query() query: HistoryQueryDto,
  ) {
    return this.messagesService.listHistory(
      user.userId,
      conversationId,
      query.beforeSequence,
      query.limit,
    );
  }

  @Get('since')
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiOperation({
    summary:
      'Synchronization/catch-up: messages strictly after a checkpoint sequence, oldest first.',
  })
  listSince(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Query() query: SinceQueryDto,
  ) {
    return this.messagesService.listSince(
      user.userId,
      conversationId,
      query.afterSequence ?? 0,
      query.limit,
    );
  }

  @Get(':messageId')
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiParam({ name: 'messageId', format: 'uuid' })
  @ApiOperation({ summary: 'Get a single message.' })
  getOne(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Param('messageId', ParseUUIDPipe) messageId: string,
  ): Promise<MessageResponseDto> {
    return this.messagesService.getMessage(
      user.userId,
      conversationId,
      messageId,
    );
  }

  @Patch(':messageId')
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiParam({ name: 'messageId', format: 'uuid' })
  @ApiOperation({ summary: "Edit the sender's own message." })
  edit(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Param('messageId', ParseUUIDPipe) messageId: string,
    @Body() dto: EditMessageDto,
  ): Promise<MessageResponseDto> {
    return this.messagesService.editMessage(
      user.userId,
      conversationId,
      messageId,
      dto,
    );
  }

  @Delete(':messageId')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiParam({ name: 'messageId', format: 'uuid' })
  @ApiOperation({
    summary: "Delete the sender's own message for everyone (idempotent).",
  })
  async remove(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Param('messageId', ParseUUIDPipe) messageId: string,
  ): Promise<void> {
    await this.messagesService.deleteMessage(
      user.userId,
      conversationId,
      messageId,
    );
  }
}

@ApiTags('receipts')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('conversations/:conversationId/receipts')
export class ReceiptsController {
  constructor(private readonly messagesService: MessagesService) {}

  @Get()
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiOperation({
    summary: 'Get delivery/read checkpoints for all active members.',
  })
  getState(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
  ): Promise<ConversationReceiptStateDto[]> {
    return this.messagesService.getReceiptState(user.userId, conversationId);
  }

  @Post('delivered')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiOperation({
    summary: 'Acknowledge delivery up to a sequence (idempotent).',
  })
  async acknowledgeDelivered(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body() dto: AcknowledgeDto,
  ): Promise<void> {
    await this.messagesService.acknowledgeDelivery(
      user.userId,
      conversationId,
      dto.upToSequence,
    );
  }

  @Post('read')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({ name: 'conversationId', format: 'uuid' })
  @ApiOperation({ summary: 'Acknowledge read up to a sequence (idempotent).' })
  async acknowledgeRead(
    @CurrentUser() user: AuthenticatedUser,
    @Param('conversationId', ParseUUIDPipe) conversationId: string,
    @Body() dto: AcknowledgeDto,
  ): Promise<void> {
    await this.messagesService.acknowledgeRead(
      user.userId,
      conversationId,
      dto.upToSequence,
    );
  }
}
