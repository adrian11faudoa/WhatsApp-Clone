import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  ArrayMaxSize,
  ArrayUnique,
  IsArray,
  IsIn,
  IsOptional,
  IsString,
  IsUUID,
  MaxLength,
  MinLength,
} from 'class-validator';

/** Message types accepted by clients in this milestone. */
export const CREATABLE_MESSAGE_TYPES = ['TEXT'] as const;
export type CreatableMessageType = (typeof CREATABLE_MESSAGE_TYPES)[number];

export const MAX_MESSAGE_CONTENT_LENGTH = 8000;

export class CreateMessageDto {
  @ApiProperty({
    description:
      'Client-generated idempotency key. Retrying the same (conversation, sender, clientMessageId) returns the original message rather than creating a duplicate.',
  })
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  clientMessageId!: string;

  @ApiPropertyOptional({ enum: CREATABLE_MESSAGE_TYPES, default: 'TEXT' })
  @IsOptional()
  @IsIn(CREATABLE_MESSAGE_TYPES)
  type?: CreatableMessageType;

  @ApiProperty({ maxLength: MAX_MESSAGE_CONTENT_LENGTH })
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(MAX_MESSAGE_CONTENT_LENGTH)
  content?: string;

  @ApiPropertyOptional({
    format: 'uuid',
    description: 'ID of a message in the same conversation being replied to.',
  })
  @IsOptional()
  @IsUUID()
  replyToId?: string;

  @ApiPropertyOptional({
    type: [String],
    description:
      'READY media asset IDs owned by the sender to attach. At least one of content/attachmentIds is required.',
  })
  @IsOptional()
  @IsArray()
  @ArrayMaxSize(10)
  @ArrayUnique()
  @IsUUID('4', { each: true })
  attachmentIds?: string[];
}

export class EditMessageDto {
  @ApiProperty({ maxLength: MAX_MESSAGE_CONTENT_LENGTH })
  @IsString()
  @MinLength(1)
  @MaxLength(MAX_MESSAGE_CONTENT_LENGTH)
  content!: string;
}

export class MessageResponseDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  conversationId!: string;

  @ApiProperty()
  senderId!: string;

  @ApiProperty()
  clientMessageId!: string;

  @ApiProperty()
  sequence!: number;

  @ApiProperty()
  type!: string;

  @ApiPropertyOptional({
    description: 'Null when the message has been deleted.',
  })
  content!: string | null;

  @ApiPropertyOptional()
  replyToId?: string | null;

  @ApiPropertyOptional()
  editedAt?: Date | null;

  @ApiPropertyOptional()
  deletedAt?: Date | null;

  @ApiProperty({ type: [String] })
  attachmentIds!: string[];

  @ApiProperty()
  createdAt!: Date;

  @ApiProperty()
  updatedAt!: Date;
}
