import { ApiProperty } from '@nestjs/swagger';
import { IsInt, Min } from 'class-validator';

/**
 * Acknowledgements identify a checkpoint by sequence number ("delivered
 * / read up to and including this sequence") rather than a single
 * message ID, matching the per-member checkpoint model in
 * conversation_members. This is idempotent by construction: acking the
 * same or an older sequence twice is a no-op.
 */
export class AcknowledgeDto {
  @ApiProperty({
    description:
      'The highest message sequence number in the conversation being acknowledged.',
  })
  @IsInt()
  @Min(0)
  upToSequence!: number;
}

export class ConversationReceiptStateDto {
  @ApiProperty()
  userId!: string;

  @ApiProperty()
  lastDeliveredSequence!: number;

  @ApiProperty()
  lastReadSequence!: number;
}
