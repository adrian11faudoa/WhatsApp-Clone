import { Module } from '@nestjs/common';
import { MessagesController, ReceiptsController } from './messages.controller';
import { MessagesService } from './messages.service';
import { ConversationsModule } from '../conversations/conversations.module';
import { RealtimeModule } from '../realtime/realtime.module';
import { AuthModule } from '../auth/auth.module';
import { MediaModule } from '../media/media.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { MessagingGateway } from '../realtime/messaging.gateway';

@Module({
  imports: [
    ConversationsModule,
    RealtimeModule,
    AuthModule,
    MediaModule,
    NotificationsModule,
  ],
  controllers: [MessagesController, ReceiptsController],
  providers: [MessagesService, MessagingGateway],
  exports: [MessagesService],
})
export class MessagesModule {}
