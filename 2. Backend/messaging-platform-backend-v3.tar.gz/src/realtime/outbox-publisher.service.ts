import { Inject, Injectable, Logger } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import {
  DATABASE_CONNECTION,
  Database,
  DbTransaction,
} from '../database/database.module';
import { messageOutbox } from '../database/schema';
import { RealtimeServerRegistryService } from './realtime-server-registry.service';
import { buildEnvelope } from './realtime-envelope';

export const OUTBOX_MAX_ATTEMPTS = 5;

/**
 * Publishes a single outbox row to connected WebSocket clients and
 * records the outcome back onto the row. Message durability never
 * depends on this succeeding — the row is already committed in
 * Postgres by the time this runs — so a publish failure here means
 * "some connected clients might not get a realtime push yet," never
 * "the message might be lost." Clients catch up via the synchronize
 * endpoint/command regardless.
 */
@Injectable()
export class OutboxPublisherService {
  private readonly logger = new Logger(OutboxPublisherService.name);

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly registry: RealtimeServerRegistryService,
  ) {}

  /** Fetches a still-PENDING row by ID and publishes it, if found. */
  async tryPublishImmediately(outboxRowId: string): Promise<void> {
    const [row] = await this.db
      .select()
      .from(messageOutbox)
      .where(eq(messageOutbox.id, outboxRowId))
      .limit(1);

    if (!row || row.status !== 'PENDING') {
      return; // already published by the poller, or doesn't exist
    }

    await this.publishRow(row, this.db);
  }

  /**
   * Core publish logic, reused by both the immediate best-effort path
   * (executor = the plain Database connection) and the background
   * poller (executor = the transaction holding this row's
   * FOR UPDATE SKIP LOCKED lock, so the status write happens before the
   * lock is released). Never throws — failures are recorded on the row
   * (attempts/lastError) so the poller can retry, up to
   * OUTBOX_MAX_ATTEMPTS before the row is marked FAILED and left for
   * operational follow-up.
   */
  async publishRow(
    row: typeof messageOutbox.$inferSelect,
    executor: Database | DbTransaction = this.db,
  ): Promise<void> {
    if (!this.registry.isReady()) {
      // The gateway hasn't finished initializing yet (e.g. very early in
      // boot) — leave the row PENDING for the poller to retry shortly.
      return;
    }

    try {
      const envelope = buildEnvelope(row.eventType, row.payload, {
        conversationId: row.conversationId,
      });
      this.registry.emitToConversation(row.conversationId, envelope);

      await executor
        .update(messageOutbox)
        .set({ status: 'PUBLISHED', publishedAt: new Date() })
        .where(eq(messageOutbox.id, row.id));
    } catch (err) {
      const attempts = row.attempts + 1;
      const failed = attempts >= OUTBOX_MAX_ATTEMPTS;

      this.logger.warn(
        `Outbox publish attempt ${attempts} failed for row ${row.id} (${row.eventType}): ${(err as Error).message}`,
      );

      await executor
        .update(messageOutbox)
        .set({
          attempts,
          lastError: (err as Error).message,
          status: failed ? 'FAILED' : 'PENDING',
        })
        .where(eq(messageOutbox.id, row.id));

      if (failed) {
        this.logger.error(
          `Outbox row ${row.id} (${row.eventType}) exceeded ${OUTBOX_MAX_ATTEMPTS} publish attempts and was marked FAILED.`,
        );
      }
    }
  }
}
