import { Inject, Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { Interval } from '@nestjs/schedule';
import { eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { messageOutbox } from '../database/schema';
import { OutboxPublisherService } from './outbox-publisher.service';

const POLL_INTERVAL_MS = 2000;
const BATCH_SIZE = 50;

/**
 * Durability backstop for the transactional outbox: the immediate
 * publish attempt in MessagesService covers the common case, but if the
 * process crashes between commit and that attempt, or the attempt
 * itself fails, rows are left PENDING. This poller picks them up on a
 * fixed interval so no event is silently lost to a transient failure.
 *
 * Row selection uses `SELECT ... FOR UPDATE SKIP LOCKED`, so multiple
 * backend instances (a future horizontal-scaling scenario) can run this
 * poller concurrently without double-processing the same row or
 * blocking on each other.
 */
@Injectable()
export class OutboxProcessorService implements OnModuleDestroy {
  private readonly logger = new Logger(OutboxProcessorService.name);
  private processing = false;
  private stopped = false;

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly publisher: OutboxPublisherService,
  ) {}

  onModuleDestroy() {
    this.stopped = true;
  }

  @Interval(POLL_INTERVAL_MS)
  async poll(): Promise<void> {
    if (this.stopped || this.processing) {
      return; // avoid overlapping runs if a batch takes longer than the interval
    }
    this.processing = true;
    try {
      await this.processBatch();
    } catch (err) {
      this.logger.error(`Outbox poll batch failed: ${(err as Error).message}`);
    } finally {
      this.processing = false;
    }
  }

  private async processBatch(): Promise<void> {
    const processedCount = await this.db.transaction(async (tx) => {
      const rows = await tx
        .select()
        .from(messageOutbox)
        .where(eq(messageOutbox.status, 'PENDING'))
        .orderBy(messageOutbox.createdAt)
        .limit(BATCH_SIZE)
        .for('update', { skipLocked: true });

      for (const row of rows) {
        // Runs inside this same transaction, so the row lock acquired
        // above is held until the status write below commits —
        // otherwise SKIP LOCKED would not prevent a second poller
        // (single-process today, multi-instance in a future scaling
        // milestone) from picking up the same row.
        await this.publisher.publishRow(row, tx);
      }

      return rows.length;
    });

    if (processedCount > 0) {
      this.logger.debug(
        `Outbox poller processed ${processedCount} pending row(s).`,
      );
    }
  }
}
