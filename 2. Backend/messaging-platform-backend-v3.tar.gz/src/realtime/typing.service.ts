import { Inject, Injectable, Logger } from '@nestjs/common';
import Redis from 'ioredis';
import { REDIS_CLIENT } from '../redis/redis.module';

const TYPING_TTL_SECONDS = 8;

/**
 * Typing state is purely ephemeral — a Redis key with a short TTL, never
 * a database row (per the "typing state must not become durable message
 * history" requirement). The TTL alone is not the disconnect-cleanup
 * mechanism, though: MessagingGateway explicitly clears a user's typing
 * state on disconnect and on send_message, so observers don't have to
 * wait out a stale TTL to see typing stop in the common cases. The TTL
 * is the backstop for the case neither of those fires (e.g. a network
 * partition that never delivers a clean disconnect).
 */
@Injectable()
export class TypingService {
  private readonly logger = new Logger(TypingService.name);

  constructor(@Inject(REDIS_CLIENT) private readonly redis: Redis) {}

  async start(conversationId: string, userId: string): Promise<void> {
    try {
      await this.redis.set(
        this.key(conversationId, userId),
        '1',
        'EX',
        TYPING_TTL_SECONDS,
      );
    } catch (err) {
      this.logger.warn(
        `Failed to record typing state (fails open, non-durable): ${(err as Error).message}`,
      );
    }
  }

  async stop(conversationId: string, userId: string): Promise<void> {
    try {
      await this.redis.del(this.key(conversationId, userId));
    } catch (err) {
      this.logger.warn(
        `Failed to clear typing state: ${(err as Error).message}`,
      );
    }
  }

  private key(conversationId: string, userId: string): string {
    return `typing:${conversationId}:${userId}`;
  }
}
