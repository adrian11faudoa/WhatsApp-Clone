import { Inject, Injectable, Logger } from '@nestjs/common';
import Redis from 'ioredis';
import { eq } from 'drizzle-orm';
import { REDIS_CLIENT } from '../redis/redis.module';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { profiles } from '../database/schema';

const PRESENCE_STATE_TTL_SECONDS = 30 * 24 * 60 * 60; // 30 days

export interface PresenceState {
  /** null means the subject's privacy settings hide this entirely. */
  online: boolean | null;
  lastSeenAt: string | null;
}

/**
 * Account-level presence, derived from connect/disconnect (not a TTL
 * heartbeat guess) so it's accurate rather than inferred: "online" flips
 * true the instant a user's first socket connects and false the instant
 * their last socket disconnects (see MessagingGateway). Stored in Redis,
 * never in Postgres — presence is explicitly non-authoritative ephemeral
 * state per the project's Redis-usage rules, and a Redis outage must not
 * corrupt or block durable messaging (this service never touches
 * message/conversation tables and every write is best-effort/fail-open).
 *
 * Privacy is enforced here, not by callers: `getPresence` always checks
 * the subject's own profile.showOnline/showLastSeen before returning
 * anything, so there is exactly one place that can leak this and it
 * can't be bypassed by a caller forgetting to check.
 */
@Injectable()
export class PresenceService {
  private readonly logger = new Logger(PresenceService.name);

  constructor(
    @Inject(REDIS_CLIENT) private readonly redis: Redis,
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
  ) {}

  async markOnline(userId: string): Promise<void> {
    try {
      await this.redis
        .multi()
        .hset(this.key(userId), {
          online: '1',
          lastSeenAt: new Date().toISOString(),
        })
        .persist(this.key(userId))
        .exec();
    } catch (err) {
      this.logger.warn(
        `Failed to mark ${userId} online: ${(err as Error).message}`,
      );
    }
  }

  async markOffline(userId: string): Promise<void> {
    try {
      await this.redis
        .multi()
        .hset(this.key(userId), {
          online: '0',
          lastSeenAt: new Date().toISOString(),
        })
        .expire(this.key(userId), PRESENCE_STATE_TTL_SECONDS)
        .exec();
    } catch (err) {
      this.logger.warn(
        `Failed to mark ${userId} offline: ${(err as Error).message}`,
      );
    }
  }

  /** Returns the raw state with no privacy filtering — for internal use
   * only (e.g. deciding whether to broadcast at all). Prefer
   * `getPresence` for anything that reaches another user. */
  async getRawState(
    userId: string,
  ): Promise<{ online: boolean; lastSeenAt: string | null }> {
    try {
      const raw = await this.redis.hgetall(this.key(userId));
      return {
        online: raw.online === '1',
        lastSeenAt: raw.lastSeenAt ?? null,
      };
    } catch (err) {
      this.logger.warn(
        `Failed to read presence for ${userId}, reporting offline: ${(err as Error).message}`,
      );
      return { online: false, lastSeenAt: null };
    }
  }

  /** Privacy-filtered presence for exposing to another user. */
  async getPresence(userId: string): Promise<PresenceState> {
    const [profile] = await this.db
      .select({
        showOnline: profiles.showOnline,
        showLastSeen: profiles.showLastSeen,
      })
      .from(profiles)
      .where(eq(profiles.userId, userId))
      .limit(1);

    if (!profile || !profile.showOnline) {
      return { online: null, lastSeenAt: null };
    }

    const raw = await this.getRawState(userId);
    return {
      online: raw.online,
      lastSeenAt: profile.showLastSeen ? raw.lastSeenAt : null,
    };
  }

  private key(userId: string): string {
    return `presence:state:${userId}`;
  }
}
