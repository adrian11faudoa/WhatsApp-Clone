import { Injectable } from '@nestjs/common';
import { Server } from 'socket.io';
import { RealtimeEnvelope } from './realtime-envelope';

/**
 * Holds the live socket.io `Server` instance, set once by
 * MessagingGateway's `afterInit` lifecycle hook. OutboxPublisherService
 * depends on this rather than on the gateway class directly, which
 * avoids a circular dependency (Gateway -> MessagesService ->
 * OutboxPublisherService -> Gateway would otherwise be a cycle).
 */
@Injectable()
export class RealtimeServerRegistryService {
  private server: Server | null = null;

  setServer(server: Server): void {
    this.server = server;
  }

  isReady(): boolean {
    return this.server !== null;
  }

  emitToConversation(conversationId: string, envelope: RealtimeEnvelope): void {
    if (!this.server) {
      throw new Error('Realtime server is not initialized yet.');
    }
    this.server
      .to(this.conversationRoom(conversationId))
      .emit('event', envelope);
  }

  emitToUser(userId: string, envelope: RealtimeEnvelope): void {
    if (!this.server) {
      throw new Error('Realtime server is not initialized yet.');
    }
    this.server.to(this.userRoom(userId)).emit('event', envelope);
  }

  conversationRoom(conversationId: string): string {
    return `conversation:${conversationId}`;
  }

  userRoom(userId: string): string {
    return `user:${userId}`;
  }
}
