import { Inject, Injectable, Logger } from '@nestjs/common';
import Redis from 'ioredis';
import { REDIS_CLIENT } from '../redis/redis.module';

interface ConnectionInfo {
  userId: string;
  deviceId: string;
  sessionId: string;
  connectedAt: number;
}

const PRESENCE_TTL_SECONDS = 60;

/**
 * Tracks which sockets belong to which authenticated user.
 *
 * Actual message routing uses the **in-memory** map: this process holds
 * the live socket.io Server instance, so it is the only thing that can
 * actually deliver to a given connection, and this milestone runs a
 * single backend instance (no socket.io Redis adapter for
 * cross-instance fan-out yet — see README "Known limitations").
 *
 * The **Redis** mirror exists for observability and as the extension
 * point a later horizontal-scaling milestone needs (a Redis adapter
 * would replace the in-memory map with cross-instance pub/sub, but the
 * presence keys already exist for it to build on). Redis writes are
 * best-effort: failures are logged, never thrown, since presence
 * tracking must not be able to break message delivery.
 */
@Injectable()
export class PresenceRegistryService {
  private readonly logger = new Logger(PresenceRegistryService.name);
  private readonly socketsByUser = new Map<string, Set<string>>();
  private readonly connectionInfo = new Map<string, ConnectionInfo>();

  constructor(@Inject(REDIS_CLIENT) private readonly redis: Redis) {}

  async registerConnection(
    socketId: string,
    info: ConnectionInfo,
  ): Promise<void> {
    if (!this.socketsByUser.has(info.userId)) {
      this.socketsByUser.set(info.userId, new Set());
    }
    this.socketsByUser.get(info.userId)!.add(socketId);
    this.connectionInfo.set(socketId, info);

    try {
      await this.redis
        .multi()
        .hset(`presence:conn:${socketId}`, {
          userId: info.userId,
          deviceId: info.deviceId,
          sessionId: info.sessionId,
          connectedAt: info.connectedAt,
        })
        .expire(`presence:conn:${socketId}`, PRESENCE_TTL_SECONDS)
        .sadd(`presence:user:${info.userId}`, socketId)
        .expire(`presence:user:${info.userId}`, PRESENCE_TTL_SECONDS)
        .exec();
    } catch (err) {
      this.logger.warn(
        `Redis presence registration failed for socket ${socketId}: ${(err as Error).message}`,
      );
    }
  }

  async refreshHeartbeat(socketId: string): Promise<void> {
    const info = this.connectionInfo.get(socketId);
    if (!info) return;
    try {
      await this.redis
        .multi()
        .expire(`presence:conn:${socketId}`, PRESENCE_TTL_SECONDS)
        .expire(`presence:user:${info.userId}`, PRESENCE_TTL_SECONDS)
        .exec();
    } catch (err) {
      this.logger.warn(
        `Redis presence heartbeat failed for socket ${socketId}: ${(err as Error).message}`,
      );
    }
  }

  async unregisterConnection(socketId: string): Promise<void> {
    const info = this.connectionInfo.get(socketId);
    this.connectionInfo.delete(socketId);

    if (info) {
      const set = this.socketsByUser.get(info.userId);
      set?.delete(socketId);
      if (set && set.size === 0) {
        this.socketsByUser.delete(info.userId);
      }
    }

    try {
      await this.redis
        .multi()
        .del(`presence:conn:${socketId}`)
        .srem(`presence:user:${info?.userId ?? ''}`, socketId)
        .exec();
    } catch (err) {
      this.logger.warn(
        `Redis presence cleanup failed for socket ${socketId}: ${(err as Error).message}`,
      );
    }
  }

  getSocketIdsForUser(userId: string): string[] {
    return Array.from(this.socketsByUser.get(userId) ?? []);
  }

  getConnectionInfo(socketId: string): ConnectionInfo | undefined {
    return this.connectionInfo.get(socketId);
  }

  getConnectedUserCount(): number {
    return this.socketsByUser.size;
  }
}
