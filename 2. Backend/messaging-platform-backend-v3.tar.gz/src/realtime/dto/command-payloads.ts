import {
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Min,
  MaxLength,
  MinLength,
} from 'class-validator';
import {
  CREATABLE_MESSAGE_TYPES,
  CreatableMessageType,
  MAX_MESSAGE_CONTENT_LENGTH,
} from '../../messages/dto/message.dto';

export class SendMessageCommandPayload {
  @IsUUID()
  conversationId!: string;

  @IsString()
  @MinLength(1)
  @MaxLength(128)
  clientMessageId!: string;

  @IsOptional()
  @IsIn(CREATABLE_MESSAGE_TYPES)
  type?: CreatableMessageType;

  @IsString()
  @MinLength(1)
  @MaxLength(MAX_MESSAGE_CONTENT_LENGTH)
  content!: string;

  @IsOptional()
  @IsUUID()
  replyToId?: string;
}

export class AcknowledgeCommandPayload {
  @IsUUID()
  conversationId!: string;

  @IsInt()
  @Min(0)
  upToSequence!: number;
}

export class SynchronizeCommandPayload {
  @IsUUID()
  conversationId!: string;

  @IsInt()
  @Min(0)
  afterSequence!: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  limit?: number;
}

export class TypingCommandPayload {
  @IsUUID()
  conversationId!: string;
}
