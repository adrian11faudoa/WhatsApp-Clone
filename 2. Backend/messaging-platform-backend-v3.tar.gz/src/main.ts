import { NestFactory } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { Logger } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import * as express from 'express';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    bufferLogs: true,
    // Body parsing is configured manually below so the media upload
    // route can receive raw binary bytes instead of being run through
    // the default JSON parser (which would corrupt binary data).
    bodyParser: false,
  });

  const config = app.get(ConfigService);
  const logger = new Logger('Bootstrap');

  const apiPrefix = config.get<string>('app.apiPrefix') as string;
  const isProduction = config.get<boolean>('app.isProduction');
  const corsOrigins = config.get<string[]>('cors.origins') as string[];
  const maxUploadBytes = Math.max(
    config.get<number>('media.maxImageBytes') as number,
    config.get<number>('media.maxVideoBytes') as number,
    config.get<number>('media.maxAudioBytes') as number,
    config.get<number>('media.maxDocumentBytes') as number,
  );

  // ---------------------------------------------------------------------
  // Body parsing
  // ---------------------------------------------------------------------
  // The raw-body middleware is scoped to exactly the upload path prefix
  // (registered before the general JSON parser) so only that route
  // receives an unparsed Buffer as req.body; every other route still
  // gets normal JSON parsing. Per-category size limits are enforced
  // again inside MediaService against the actual bytes — this limit is
  // just the outer ceiling so an oversized request is rejected before
  // it is fully buffered into memory.
  app.use(
    `/${apiPrefix}/media/upload`,
    express.raw({ limit: maxUploadBytes, type: () => true }),
  );
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // ---------------------------------------------------------------------
  // Security middleware
  // ---------------------------------------------------------------------
  app.use(
    helmet({
      contentSecurityPolicy: isProduction ? undefined : false,
    }),
  );

  app.enableCors({
    origin: corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'PUT', 'OPTIONS'],
  });

  app.setGlobalPrefix(apiPrefix, {
    exclude: ['health/live', 'health/ready'],
  });

  app.enableShutdownHooks();

  // ---------------------------------------------------------------------
  // API documentation
  // ---------------------------------------------------------------------
  if (!isProduction) {
    const swaggerDocument = new DocumentBuilder()
      .setTitle('WhatsApp-style Messaging Platform API')
      .setDescription(
        'Foundational accounts, auth, devices, sessions, conversations, groups, messaging, reactions, presence, media, and notifications.',
      )
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    const document = SwaggerModule.createDocument(app, swaggerDocument);
    SwaggerModule.setup(`${apiPrefix}/docs`, app, document);
  }

  const port = config.get<number>('app.port') as number;
  await app.listen(port);
  logger.log(
    `${config.get<string>('app.name')} listening on port ${port} (${config.get('app.nodeEnv')})`,
  );
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Fatal error during application bootstrap:', err);
  process.exit(1);
});
