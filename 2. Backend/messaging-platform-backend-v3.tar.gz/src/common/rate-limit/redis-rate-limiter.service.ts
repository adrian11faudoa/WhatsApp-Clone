import { Inject, Injectable, Logger } from '@nestjs/common';
import Redis from 'ioredis';
import { REDIS_CLIENT } from '../../redis/redis.module';

/**
 * A minimal fixed-window limiter for realtime (WebSocket) commands,
 * where per-route @Throttle decorators don't apply (there's no HTTP
 * route per command). Deliberately separate from the HTTP
 * ThrottlerStorageRedisService: that class implements @nestjs/throttler's
 * specific interface for the HTTP guard pipeline, while this is called
 * directly from gateway handlers with per-command limits (e.g.
 * send_message vs synchronize should not share one budget).
 *
 * Failure behavior: if Redis is unreachable, requests are allowed
 * through (fail open) rather than blocking all realtime traffic on a
 * Redis outage — durable message persistence in Postgres is the safety
 * net, not this limiter.
 */
@Injectable()
export class RedisRateLimiterService {
  private readonly logger = new Logger(RedisRateLimiterService.name);

  constructor(@Inject(REDIS_CLIENT) private readonly redis: Redis) {}

  /** Returns true if the call is allowed under the given limit/window.
   *
   * Disabled under automated tests, for the same reason
   * AppThrottlerGuard.shouldSkip is: integration tests intentionally
   * open many connections/commands in quick succession, which is not
   * the behavior this limiter exists to catch. Production/development
   * behavior is unaffected.
   */
  async consume(
    key: string,
    limit: number,
    windowMs: number,
  ): Promise<boolean> {
    if (process.env.NODE_ENV === 'test') {
      return true;
    }

    try {
      const redisKey = `ratelimit:${key}`;
      const count = await this.redis.incr(redisKey);
      if (count === 1) {
        await this.redis.pexpire(redisKey, windowMs);
      }
      return count <= limit;
    } catch (err) {
      this.logger.warn(
        `Rate limiter Redis error, failing open for key "${key}": ${(err as Error).message}`,
      );
      return true;
    }
  }
}
