import { RedisRateLimiterService } from './redis-rate-limiter.service';

describe('RedisRateLimiterService', () => {
  const originalNodeEnv = process.env.NODE_ENV;

  afterEach(() => {
    process.env.NODE_ENV = originalNodeEnv;
  });

  function buildService(redisMock: {
    incr: jest.Mock;
    pexpire: jest.Mock;
  }): RedisRateLimiterService {
    // Constructed directly (not via Nest DI) since this is a pure unit
    // test of the counting logic against a mocked Redis client.
    return new RedisRateLimiterService(redisMock as any);
  }

  it('allows requests under the limit', async () => {
    process.env.NODE_ENV = 'production';
    const redis = { incr: jest.fn().mockResolvedValue(1), pexpire: jest.fn() };
    const service = buildService(redis);

    const allowed = await service.consume('key', 5, 1000);
    expect(allowed).toBe(true);
    expect(redis.pexpire).toHaveBeenCalledWith('ratelimit:key', 1000);
  });

  it('denies requests once the count exceeds the limit', async () => {
    process.env.NODE_ENV = 'production';
    const redis = { incr: jest.fn().mockResolvedValue(6), pexpire: jest.fn() };
    const service = buildService(redis);

    const allowed = await service.consume('key', 5, 1000);
    expect(allowed).toBe(false);
  });

  it('only sets the expiry on the first increment in a window', async () => {
    process.env.NODE_ENV = 'production';
    const redis = { incr: jest.fn().mockResolvedValue(2), pexpire: jest.fn() };
    const service = buildService(redis);

    await service.consume('key', 5, 1000);
    expect(redis.pexpire).not.toHaveBeenCalled();
  });

  it('fails open when Redis errors', async () => {
    process.env.NODE_ENV = 'production';
    const redis = {
      incr: jest.fn().mockRejectedValue(new Error('connection refused')),
      pexpire: jest.fn(),
    };
    const service = buildService(redis);

    await expect(service.consume('key', 5, 1000)).resolves.toBe(true);
  });

  it('always allows under NODE_ENV=test without touching Redis', async () => {
    process.env.NODE_ENV = 'test';
    const redis = { incr: jest.fn(), pexpire: jest.fn() };
    const service = buildService(redis);

    const allowed = await service.consume('key', 1, 1000);
    expect(allowed).toBe(true);
    expect(redis.incr).not.toHaveBeenCalled();
  });
});
