import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { AccessTokenPayload } from '../token.service';
import { AuthenticatedUser } from '../../common/decorators/current-user.decorator';
import { AuthContextService } from '../auth-context.service';

/**
 * Verifies the JWT signature/expiry (handled by passport-jwt) and then
 * delegates live-state checking (session revoked/expired, account
 * disabled) to AuthContextService — the same service the realtime
 * gateway uses, so HTTP and WebSocket auth can never silently diverge.
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    config: ConfigService,
    private readonly authContext: AuthContextService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: config.get<string>('jwt.accessSecret'),
      issuer: config.get<string>('jwt.issuer'),
      audience: config.get<string>('jwt.audience'),
    });
  }

  async validate(payload: AccessTokenPayload): Promise<AuthenticatedUser> {
    return this.authContext.resolveFromPayload(payload);
  }
}
