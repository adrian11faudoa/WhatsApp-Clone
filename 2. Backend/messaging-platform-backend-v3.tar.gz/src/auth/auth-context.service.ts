import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { sessions, users } from '../database/schema';
import { AccessTokenPayload } from './token.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';

/**
 * The single place that turns a verified JWT payload into an
 * authenticated principal, by checking *live* database state (session
 * not revoked/expired, account still ACTIVE). Both the HTTP JwtStrategy
 * and the realtime WebSocket gateway route through this — there is
 * exactly one implementation of "is this token still good right now,"
 * not two that could silently drift apart.
 */
@Injectable()
export class AuthContextService {
  constructor(@Inject(DATABASE_CONNECTION) private readonly db: Database) {}

  async resolveFromPayload(
    payload: AccessTokenPayload,
  ): Promise<AuthenticatedUser> {
    const [session] = await this.db
      .select({
        id: sessions.id,
        revoked: sessions.revoked,
        expiresAt: sessions.expiresAt,
        userId: sessions.userId,
        deviceId: sessions.deviceId,
      })
      .from(sessions)
      .where(eq(sessions.id, payload.sid))
      .limit(1);

    if (!session || session.revoked || session.expiresAt < new Date()) {
      throw new UnauthorizedException('Session is no longer valid.');
    }

    const [user] = await this.db
      .select({ id: users.id, status: users.status })
      .from(users)
      .where(eq(users.id, payload.sub))
      .limit(1);

    if (!user || user.status !== 'ACTIVE') {
      throw new UnauthorizedException('Account is not active.');
    }

    return {
      userId: user.id,
      sessionId: session.id,
      deviceId: session.deviceId,
    };
  }
}
