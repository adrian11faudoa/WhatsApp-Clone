import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';

export type MediaTokenPurpose = 'media_upload' | 'media_download';

export interface MediaTokenPayload {
  typ: MediaTokenPurpose;
  mediaAssetId: string;
  storageKey: string;
  /** For downloads only — which variant this token grants access to. */
  variant?: string;
}

/**
 * Issues and verifies short-lived signed tokens for media upload/
 * download URLs — this milestone's stand-in for S3 presigned URLs (see
 * README). Reuses the JWT access-token secret rather than introducing a
 * new required secret, but is a structurally distinct token: the `typ`
 * claim and a short-lived, purpose-specific expiry prevent a media token
 * from being usable as (or confused with) a session access token, and
 * vice versa — JwtStrategy/AuthContextService never accept a token with
 * a `typ` claim, and this service always requires one.
 */
@Injectable()
export class MediaUrlSignerService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
  ) {}

  signUploadToken(
    mediaAssetId: string,
    storageKey: string,
  ): { token: string; expiresAt: Date } {
    const ttl = this.config.get<number>('media.uploadUrlTtlSeconds') as number;
    return this.sign({ typ: 'media_upload', mediaAssetId, storageKey }, ttl);
  }

  signDownloadToken(
    mediaAssetId: string,
    storageKey: string,
    variant?: string,
  ): { token: string; expiresAt: Date } {
    const ttl = this.config.get<number>(
      'media.downloadUrlTtlSeconds',
    ) as number;
    return this.sign(
      { typ: 'media_download', mediaAssetId, storageKey, variant },
      ttl,
    );
  }

  verify(token: string, expectedType: MediaTokenPurpose): MediaTokenPayload {
    const payload = this.jwtService.verify<MediaTokenPayload & { typ: string }>(
      token,
      { secret: this.config.get<string>('jwt.accessSecret') },
    );
    if (payload.typ !== expectedType) {
      throw new Error('Token purpose mismatch.');
    }
    return payload as MediaTokenPayload;
  }

  private sign(
    payload: MediaTokenPayload,
    ttlSeconds: number,
  ): { token: string; expiresAt: Date } {
    const token = this.jwtService.sign(payload, {
      secret: this.config.get<string>('jwt.accessSecret'),
      expiresIn: ttlSeconds,
    });
    return { token, expiresAt: new Date(Date.now() + ttlSeconds * 1000) };
  }
}
