import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { LocalFilesystemStorageAdapter } from './local-filesystem-storage.adapter';
import { STORAGE_ADAPTER } from './storage-adapter.interface';
import { MediaUrlSignerService } from './media-url-signer.service';

@Module({
  imports: [JwtModule.register({})],
  providers: [
    {
      provide: STORAGE_ADAPTER,
      useClass: LocalFilesystemStorageAdapter,
    },
    MediaUrlSignerService,
  ],
  exports: [STORAGE_ADAPTER, MediaUrlSignerService],
})
export class StorageModule {}
