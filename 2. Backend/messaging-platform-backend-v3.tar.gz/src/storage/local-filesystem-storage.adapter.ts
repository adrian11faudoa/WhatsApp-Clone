import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { promises as fs } from 'fs';
import * as path from 'path';
import { StorageAdapter } from './storage-adapter.interface';

const CONTENT_TYPE_SIDECAR_SUFFIX = '.content-type';

/**
 * Real, working object storage on local disk. Not a mock: files are
 * actually written to and read from `MEDIA_STORAGE_ROOT`, survive
 * process restarts, and are deleted on request. Content type is stored
 * in a small sidecar file next to the object since the filesystem has
 * no native metadata field for it.
 *
 * `key` is sanitized to a relative path before being joined with the
 * storage root and re-checked to still be inside the root afterward —
 * this is what prevents a crafted key (e.g. containing `../`) from
 * writing or reading outside the storage directory.
 */
@Injectable()
export class LocalFilesystemStorageAdapter implements StorageAdapter {
  private readonly logger = new Logger(LocalFilesystemStorageAdapter.name);
  private readonly root: string;

  constructor(config: ConfigService) {
    this.root = path.resolve(config.get<string>('media.storageRoot') as string);
  }

  async putObject(
    key: string,
    data: Buffer,
    contentType: string,
  ): Promise<void> {
    const filePath = this.resolvePath(key);
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, data);
    await fs.writeFile(
      filePath + CONTENT_TYPE_SIDECAR_SUFFIX,
      contentType,
      'utf-8',
    );
  }

  async getObject(
    key: string,
  ): Promise<{ data: Buffer; contentType: string } | null> {
    const filePath = this.resolvePath(key);
    try {
      const [data, contentType] = await Promise.all([
        fs.readFile(filePath),
        fs
          .readFile(filePath + CONTENT_TYPE_SIDECAR_SUFFIX, 'utf-8')
          .catch(() => 'application/octet-stream'),
      ]);
      return { data, contentType };
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
        return null;
      }
      throw err;
    }
  }

  async deleteObject(key: string): Promise<void> {
    const filePath = this.resolvePath(key);
    await Promise.allSettled([
      fs.unlink(filePath),
      fs.unlink(filePath + CONTENT_TYPE_SIDECAR_SUFFIX),
    ]);
  }

  async objectExists(key: string): Promise<boolean> {
    try {
      await fs.access(this.resolvePath(key));
      return true;
    } catch {
      return false;
    }
  }

  private resolvePath(key: string): string {
    const normalizedKey = path.normalize(key).replace(/^([./\\]+)/, '');
    const resolved = path.resolve(this.root, normalizedKey);
    if (!resolved.startsWith(this.root + path.sep) && resolved !== this.root) {
      throw new Error(`Refusing to access storage key outside root: ${key}`);
    }
    return resolved;
  }
}
