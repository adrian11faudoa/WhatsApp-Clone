/**
 * Object-storage boundary. The durable database owns media *metadata*
 * (see media_assets/media_variants in schema.ts); this interface owns
 * binary *content*, kept strictly separate so Postgres never holds large
 * binary blobs.
 *
 * `LocalFilesystemStorageAdapter` (this milestone's only implementation)
 * is a genuinely working adapter, not a stub — it actually writes,
 * reads, and deletes files. It exists because no S3-compatible
 * credentials or network access are available in this environment (see
 * README "Why local filesystem storage, not S3"). A production S3Adapter
 * would implement this same interface; nothing above the adapter
 * boundary (MediaService, the upload/download controllers) would need
 * to change.
 */
export interface StorageAdapter {
  putObject(key: string, data: Buffer, contentType: string): Promise<void>;
  getObject(key: string): Promise<{ data: Buffer; contentType: string } | null>;
  deleteObject(key: string): Promise<void>;
  objectExists(key: string): Promise<boolean>;
}

export const STORAGE_ADAPTER = Symbol('STORAGE_ADAPTER');
