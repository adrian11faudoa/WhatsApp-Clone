import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { ConfigModule, ConfigService } from '@nestjs/config';

export const MEDIA_PROCESSING_QUEUE = 'media-processing';
export const MEDIA_CLEANUP_QUEUE = 'media-cleanup';
export const NOTIFICATION_DELIVERY_QUEUE = 'notification-delivery';

/**
 * Shared BullMQ connection configuration. All queues in this milestone
 * (media processing, media cleanup, notification delivery) register
 * through this module rather than each constructing its own Redis
 * connection, so connection settings and failure behavior stay
 * consistent across workers.
 */
@Module({
  imports: [
    BullModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        connection: {
          // BullMQ needs its own ioredis-compatible connection options
          // (not the shared REDIS_CLIENT instance) because it manages
          // connection lifecycle/blocking commands itself.
          host: new URL(config.get<string>('redis.url') as string).hostname,
          port: Number(
            new URL(config.get<string>('redis.url') as string).port || 6379,
          ),
          maxRetriesPerRequest: null,
        },
      }),
    }),
    BullModule.registerQueue(
      { name: MEDIA_PROCESSING_QUEUE },
      { name: MEDIA_CLEANUP_QUEUE },
      { name: NOTIFICATION_DELIVERY_QUEUE },
    ),
  ],
  exports: [BullModule],
})
export class JobsModule {}
