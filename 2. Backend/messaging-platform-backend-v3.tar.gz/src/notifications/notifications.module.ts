import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import {
  NotificationPreferencesController,
  PushTokensController,
} from './notifications.controller';
import { PushTokensService } from './push-tokens.service';
import { NotificationPreferencesService } from './notification-preferences.service';
import { NotificationsService } from './notifications.service';
import { NotificationDeliveryWorker } from './jobs/notification-delivery.worker';
import { LogPushProvider } from './providers/log-push-provider';
import { PUSH_PROVIDER } from './providers/push-provider.interface';
import { JobsModule } from '../jobs/jobs.module';
import { ConversationsModule } from '../conversations/conversations.module';
import { AuditService } from '../common/audit/audit.service';

@Module({
  imports: [JobsModule, ConversationsModule, ConfigModule],
  controllers: [PushTokensController, NotificationPreferencesController],
  providers: [
    PushTokensService,
    NotificationPreferencesService,
    NotificationsService,
    NotificationDeliveryWorker,
    AuditService,
    {
      // Only 'log' is implemented in this milestone (env-validated to
      // that one value — see env.validation.ts) — the factory shape is
      // what a later milestone would extend to select a real provider.
      provide: PUSH_PROVIDER,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const provider = config.get<string>('notification.provider');
        if (provider !== 'log') {
          throw new Error(`Unsupported NOTIFICATION_PROVIDER: ${provider}`);
        }
        return new LogPushProvider();
      },
    },
  ],
  exports: [NotificationsService],
})
export class NotificationsModule {}
