import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { PushTokensService } from './push-tokens.service';
import { NotificationPreferencesService } from './notification-preferences.service';
import {
  NotificationPreferencesResponseDto,
  PushTokenResponseDto,
  RegisterPushTokenDto,
  UpdateNotificationPreferencesDto,
} from './dto/push-token.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import {
  CurrentUser,
  AuthenticatedUser,
} from '../common/decorators/current-user.decorator';

@ApiTags('push-tokens')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('push-tokens')
export class PushTokensController {
  constructor(private readonly pushTokensService: PushTokensService) {}

  @Post()
  @ApiOperation({
    summary:
      "Register (or refresh) a push token for one of the caller's devices.",
  })
  register(
    @CurrentUser() user: AuthenticatedUser,
    @Body() dto: RegisterPushTokenDto,
  ): Promise<PushTokenResponseDto> {
    return this.pushTokensService.register(user.userId, dto);
  }

  @Get()
  @ApiOperation({ summary: "List the caller's registered push tokens." })
  list(
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PushTokenResponseDto[]> {
    return this.pushTokensService.listMine(user.userId);
  }

  @Delete(':pushTokenId')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiParam({ name: 'pushTokenId', format: 'uuid' })
  @ApiOperation({
    summary: 'Invalidate a push token (e.g. on logout/uninstall).',
  })
  async invalidate(
    @CurrentUser() user: AuthenticatedUser,
    @Param('pushTokenId', ParseUUIDPipe) pushTokenId: string,
  ): Promise<void> {
    await this.pushTokensService.invalidate(user.userId, pushTokenId);
  }
}

@ApiTags('notification-preferences')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('notification-preferences')
export class NotificationPreferencesController {
  constructor(
    private readonly preferencesService: NotificationPreferencesService,
  ) {}

  @Get()
  @ApiOperation({ summary: "Get the caller's notification preferences." })
  get(
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<NotificationPreferencesResponseDto> {
    return this.preferencesService.get(user.userId);
  }

  @Patch()
  @ApiOperation({ summary: "Update the caller's notification preferences." })
  update(
    @CurrentUser() user: AuthenticatedUser,
    @Body() dto: UpdateNotificationPreferencesDto,
  ): Promise<NotificationPreferencesResponseDto> {
    return this.preferencesService.update(user.userId, dto);
  }
}
