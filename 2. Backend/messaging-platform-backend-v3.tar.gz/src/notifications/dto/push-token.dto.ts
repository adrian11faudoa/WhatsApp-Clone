import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsIn,
  IsOptional,
  IsString,
  IsUUID,
  MaxLength,
} from 'class-validator';

export const PUSH_PLATFORMS = ['IOS', 'ANDROID', 'WEB'] as const;

export class RegisterPushTokenDto {
  @ApiProperty({
    format: 'uuid',
    description: "The caller's own device (from /devices).",
  })
  @IsUUID()
  deviceId!: string;

  @ApiProperty({ enum: PUSH_PLATFORMS })
  @IsIn(PUSH_PLATFORMS)
  platform!: (typeof PUSH_PLATFORMS)[number];

  @ApiProperty({
    description: 'Opaque provider token (FCM/APNS registration token).',
  })
  @IsString()
  @MaxLength(4096)
  token!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(40)
  appVersion?: string;
}

export class PushTokenResponseDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  deviceId!: string;

  @ApiProperty()
  platform!: string;

  @ApiProperty()
  status!: string;

  @ApiProperty()
  lastUsedAt!: Date;

  @ApiProperty()
  createdAt!: Date;
}

export class UpdateNotificationPreferencesDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  messageNotifications?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  groupNotifications?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  mentionNotifications?: boolean;
}

export class NotificationPreferencesResponseDto {
  @ApiProperty()
  messageNotifications!: boolean;

  @ApiProperty()
  groupNotifications!: boolean;

  @ApiProperty()
  mentionNotifications!: boolean;
}
