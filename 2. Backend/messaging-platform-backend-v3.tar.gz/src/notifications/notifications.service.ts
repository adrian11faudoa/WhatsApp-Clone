import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { notifications, users } from '../database/schema';
import { ConversationMembershipService } from '../conversations/conversation-membership.service';
import { NotificationPreferencesService } from './notification-preferences.service';
import { NOTIFICATION_DELIVERY_QUEUE } from '../jobs/jobs.module';
import { MessageResponseDto } from '../messages/dto/message.dto';

export interface NotificationDeliveryJobPayload {
  notificationId: string;
}

/**
 * Orchestrates *intent* only — deciding who should be notified and
 * durably recording that decision. Actual provider delivery happens
 * asynchronously in NotificationDeliveryWorker, off the calling
 * request's critical path, so a slow/unavailable push provider can
 * never affect message persistence latency or success (see
 * MessagesService.createMessage, which calls this fire-and-forget).
 */
@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly membershipService: ConversationMembershipService,
    private readonly preferencesService: NotificationPreferencesService,
    @InjectQueue(NOTIFICATION_DELIVERY_QUEUE)
    private readonly deliveryQueue: Queue<NotificationDeliveryJobPayload>,
  ) {}

  /**
   * Triggered by a message_created event. Never throws into the caller
   * (MessagesService swallows/logs regardless, but this is defensive in
   * depth) — a notification-pipeline failure must never surface as a
   * message-send failure.
   */
  async notifyMessageCreated(
    message: MessageResponseDto,
    conversationType: 'DIRECT' | 'GROUP',
  ): Promise<void> {
    const memberIds = await this.membershipService.listActiveMemberIds(
      message.conversationId,
    );
    // Eligibility: never notify the actor for their own action.
    const recipientIds = memberIds.filter((id) => id !== message.senderId);

    for (const recipientId of recipientIds) {
      try {
        await this.createIntentIfEligible(
          recipientId,
          message,
          conversationType,
        );
      } catch (err) {
        this.logger.warn(
          `Failed to create notification intent for recipient ${recipientId}, message ${message.id}: ${(err as Error).message}`,
        );
      }
    }
  }

  private async createIntentIfEligible(
    recipientId: string,
    message: MessageResponseDto,
    conversationType: 'DIRECT' | 'GROUP',
  ): Promise<void> {
    const [recipient] = await this.db
      .select({ id: users.id, status: users.status })
      .from(users)
      .where(eq(users.id, recipientId))
      .limit(1);
    if (!recipient || recipient.status !== 'ACTIVE') {
      return; // ineligible: disabled/deleted account
    }

    const prefs = await this.preferencesService.getRaw(recipientId);
    const categoryEnabled =
      conversationType === 'GROUP'
        ? prefs.groupNotifications
        : prefs.messageNotifications;
    if (!categoryEnabled) {
      return; // ineligible: recipient has disabled this notification category
    }

    // Privacy: never place message content in the notification body.
    const title =
      conversationType === 'GROUP' ? 'New group message' : 'New message';
    const body = 'You have a new message.';

    const [notification] = await this.db
      .insert(notifications)
      .values({
        userId: recipientId,
        sourceEventType: 'message_created',
        sourceEventId: message.id,
        conversationId: message.conversationId,
        title,
        body,
        data: { conversationId: message.conversationId, messageId: message.id },
      })
      // Deduplication: a retried or duplicate-published message_created
      // event for the same (recipient, message) can never create a
      // second notification row — the unique index absorbs the retry
      // as a no-op rather than the app needing to detect it itself.
      .onConflictDoNothing()
      .returning({ id: notifications.id });

    if (!notification) {
      return; // deduplicated
    }

    await this.deliveryQueue.add(
      'deliver',
      { notificationId: notification.id },
      {
        jobId: `deliver-${notification.id}`,
        attempts: 3,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: true,
        removeOnFail: 100,
      },
    );
  }
}
