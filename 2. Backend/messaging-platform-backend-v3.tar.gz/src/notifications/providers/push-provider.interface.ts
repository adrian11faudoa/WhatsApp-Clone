export interface PushSendRequest {
  token: string;
  title: string;
  body: string;
  data?: Record<string, unknown>;
}

export type PushSendOutcome =
  | { result: 'sent'; providerMessageId: string }
  | { result: 'retryable_error'; error: string }
  /** The token itself is bad (uninstalled app, expired) — never retry, mark the token INVALID. */
  | { result: 'invalid_token'; error: string }
  /** No real provider is configured — see LogPushProvider. Not a failure. */
  | { result: 'skipped_no_provider' };

export const PUSH_PROVIDER = Symbol('PUSH_PROVIDER');

/**
 * The boundary the notification worker calls through. A production
 * FcmPushProvider/ApnsPushProvider would implement this same interface;
 * nothing above the boundary (NotificationsService, the delivery worker)
 * would need to change. See LogPushProvider for this milestone's only
 * implementation and why.
 */
export interface PushProvider {
  send(request: PushSendRequest): Promise<PushSendOutcome>;
}
