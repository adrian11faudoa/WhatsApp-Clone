import { Injectable, Logger } from '@nestjs/common';
import {
  PushProvider,
  PushSendOutcome,
  PushSendRequest,
} from './push-provider.interface';

/**
 * This milestone's only push provider. No APNS/FCM credentials exist in
 * this environment (see README), and this class does not pretend
 * otherwise: every call returns `skipped_no_provider`, never `sent` —
 * it never fabricates a successful delivery. It logs a structured,
 * privacy-safe record (title only, never `body`, which may carry
 * message content) so the delivery pipeline itself — job enqueue,
 * per-token fan-out, result recording, retry/backoff wiring — is
 * exercised and observable end-to-end even with no real provider
 * behind it. Swapping in a real ApnsPushProvider/FcmPushProvider means
 * implementing this same interface; nothing else in the notification
 * pipeline changes.
 */
@Injectable()
export class LogPushProvider implements PushProvider {
  private readonly logger = new Logger('LogPushProvider');

  async send(request: PushSendRequest): Promise<PushSendOutcome> {
    this.logger.log(
      `[no push provider configured] would send "${request.title}" to token ending in ...${request.token.slice(-6)}`,
    );
    return { result: 'skipped_no_provider' };
  }
}
