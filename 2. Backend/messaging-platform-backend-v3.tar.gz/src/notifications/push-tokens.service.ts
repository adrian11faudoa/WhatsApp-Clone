import { HttpStatus, Inject, Injectable } from '@nestjs/common';
import { and, desc, eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { pushTokens } from '../database/schema';
import { AppException } from '../common/errors/app.exception';
import { AppErrorCode } from '../common/errors/app-error-codes';
import { AuditService } from '../common/audit/audit.service';
import {
  PushTokenResponseDto,
  RegisterPushTokenDto,
} from './dto/push-token.dto';

@Injectable()
export class PushTokensService {
  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly auditService: AuditService,
  ) {}

  /**
   * Upsert on the token value itself (unique index): re-registering the
   * same provider token — which real clients do routinely, e.g. on
   * every app foreground — updates device/platform/lastUsedAt on the
   * existing row instead of creating a duplicate. A previously INVALID
   * token is reactivated, since a client presenting it again means the
   * provider considers it valid now.
   */
  async register(
    userId: string,
    dto: RegisterPushTokenDto,
  ): Promise<PushTokenResponseDto> {
    const [existing] = await this.db
      .select({ id: pushTokens.id })
      .from(pushTokens)
      .where(eq(pushTokens.token, dto.token))
      .limit(1);

    const now = new Date();
    let row;
    if (existing) {
      [row] = await this.db
        .update(pushTokens)
        .set({
          userId,
          deviceId: dto.deviceId,
          platform: dto.platform,
          appVersion: dto.appVersion,
          status: 'ACTIVE',
          lastUsedAt: now,
          updatedAt: now,
        })
        .where(eq(pushTokens.id, existing.id))
        .returning();
    } else {
      [row] = await this.db
        .insert(pushTokens)
        .values({
          userId,
          deviceId: dto.deviceId,
          platform: dto.platform,
          token: dto.token,
          appVersion: dto.appVersion,
        })
        .returning();
    }

    await this.auditService.record({
      type: 'PUSH_TOKEN_REGISTERED',
      userId,
      metadata: { pushTokenId: row.id, platform: dto.platform },
    });

    return this.toDto(row);
  }

  async listMine(userId: string): Promise<PushTokenResponseDto[]> {
    const rows = await this.db
      .select()
      .from(pushTokens)
      .where(eq(pushTokens.userId, userId))
      .orderBy(desc(pushTokens.lastUsedAt));
    return rows.map((r) => this.toDto(r));
  }

  async invalidate(userId: string, pushTokenId: string): Promise<void> {
    const result = await this.db
      .update(pushTokens)
      .set({ status: 'INVALID', updatedAt: new Date() })
      .where(and(eq(pushTokens.id, pushTokenId), eq(pushTokens.userId, userId)))
      .returning({ id: pushTokens.id });

    if (result.length === 0) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Push token not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    await this.auditService.record({
      type: 'PUSH_TOKEN_INVALIDATED',
      userId,
      metadata: { pushTokenId },
    });
  }

  /** Used by NotificationDeliveryWorker to mark a token dead after a
   * permanent provider error (e.g. "not registered"). */
  async markInvalidByToken(token: string): Promise<void> {
    await this.db
      .update(pushTokens)
      .set({ status: 'INVALID', updatedAt: new Date() })
      .where(eq(pushTokens.token, token));
  }

  async getActiveTokensForUser(userId: string) {
    return this.db
      .select()
      .from(pushTokens)
      .where(
        and(eq(pushTokens.userId, userId), eq(pushTokens.status, 'ACTIVE')),
      );
  }

  private toDto(row: typeof pushTokens.$inferSelect): PushTokenResponseDto {
    return {
      id: row.id,
      deviceId: row.deviceId,
      platform: row.platform,
      status: row.status,
      lastUsedAt: row.lastUsedAt,
      createdAt: row.createdAt,
    };
  }
}
