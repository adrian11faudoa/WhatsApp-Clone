import { Inject, Injectable } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import { notificationPreferences } from '../database/schema';
import {
  NotificationPreferencesResponseDto,
  UpdateNotificationPreferencesDto,
} from './dto/push-token.dto';

@Injectable()
export class NotificationPreferencesService {
  constructor(@Inject(DATABASE_CONNECTION) private readonly db: Database) {}

  async get(userId: string): Promise<NotificationPreferencesResponseDto> {
    const row = await this.getOrCreateDefault(userId);
    return this.toDto(row);
  }

  async update(
    userId: string,
    dto: UpdateNotificationPreferencesDto,
  ): Promise<NotificationPreferencesResponseDto> {
    await this.getOrCreateDefault(userId); // ensures a row exists to update

    const updates: Partial<typeof notificationPreferences.$inferInsert> = {};
    if (dto.messageNotifications !== undefined)
      updates.messageNotifications = dto.messageNotifications;
    if (dto.groupNotifications !== undefined)
      updates.groupNotifications = dto.groupNotifications;
    if (dto.mentionNotifications !== undefined)
      updates.mentionNotifications = dto.mentionNotifications;

    if (Object.keys(updates).length > 0) {
      updates.updatedAt = new Date();
      await this.db
        .update(notificationPreferences)
        .set(updates)
        .where(eq(notificationPreferences.userId, userId));
    }

    return this.get(userId);
  }

  /** Used internally by NotificationsService to evaluate eligibility. */
  async getRaw(userId: string) {
    return this.getOrCreateDefault(userId);
  }

  private async getOrCreateDefault(userId: string) {
    const [existing] = await this.db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .limit(1);
    if (existing) return existing;

    const [created] = await this.db
      .insert(notificationPreferences)
      .values({ userId })
      .onConflictDoNothing()
      .returning();

    if (created) return created;

    // Lost a race with a concurrent first-access — re-read.
    const [row] = await this.db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .limit(1);
    return row;
  }

  private toDto(
    row: typeof notificationPreferences.$inferSelect,
  ): NotificationPreferencesResponseDto {
    return {
      messageNotifications: row.messageNotifications,
      groupNotifications: row.groupNotifications,
      mentionNotifications: row.mentionNotifications,
    };
  }
}
