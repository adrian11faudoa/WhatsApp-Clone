import { Inject, Logger } from '@nestjs/common';
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { eq } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../../database/database.module';
import { notifications } from '../../database/schema';
import { NOTIFICATION_DELIVERY_QUEUE } from '../../jobs/jobs.module';
import { NotificationDeliveryJobPayload } from '../notifications.service';
import { PushTokensService } from '../push-tokens.service';
import {
  PUSH_PROVIDER,
  PushProvider,
} from '../providers/push-provider.interface';

interface DeliveryResultSummary {
  pushTokenId: string;
  platform: string;
  result: string;
}

/**
 * Fans a single notification out to every ACTIVE push token belonging
 * to its recipient (multi-device targeting) and records a durable
 * summary of the outcome per token in notifications.delivery_results.
 * An invalid-token result immediately invalidates that token (no
 * indefinite retry against a token the provider says is dead); a
 * retryable error is left for BullMQ's own attempt/backoff to retry the
 * whole job. Idempotent: re-running this job for a notification that
 * already reached a terminal status is a no-op.
 */
@Processor(NOTIFICATION_DELIVERY_QUEUE)
export class NotificationDeliveryWorker extends WorkerHost {
  private readonly logger = new Logger(NotificationDeliveryWorker.name);

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly pushTokensService: PushTokensService,
    @Inject(PUSH_PROVIDER) private readonly provider: PushProvider,
  ) {
    super();
  }

  async process(job: Job<NotificationDeliveryJobPayload>): Promise<void> {
    const { notificationId } = job.data;

    const [notification] = await this.db
      .select()
      .from(notifications)
      .where(eq(notifications.id, notificationId))
      .limit(1);

    if (!notification) {
      this.logger.warn(
        `Notification ${notificationId} no longer exists; skipping.`,
      );
      return;
    }
    if (notification.status === 'SENT' || notification.status === 'SKIPPED') {
      return; // already reached a terminal state — idempotent no-op
    }

    await this.db
      .update(notifications)
      .set({ status: 'PROCESSING', attempts: notification.attempts + 1 })
      .where(eq(notifications.id, notificationId));

    const tokens = await this.pushTokensService.getActiveTokensForUser(
      notification.userId,
    );

    if (tokens.length === 0) {
      await this.db
        .update(notifications)
        .set({ status: 'SKIPPED', processedAt: new Date() })
        .where(eq(notifications.id, notificationId));
      return;
    }

    const results: DeliveryResultSummary[] = [];
    let sentCount = 0;
    let failedCount = 0;

    for (const token of tokens) {
      const outcome = await this.provider.send({
        token: token.token,
        title: notification.title,
        body: notification.body,
        data: (notification.data as Record<string, unknown>) ?? undefined,
      });

      if (outcome.result === 'sent') {
        sentCount++;
      } else if (outcome.result === 'invalid_token') {
        failedCount++;
        await this.pushTokensService.markInvalidByToken(token.token);
      } else if (outcome.result === 'retryable_error') {
        failedCount++;
      }
      // 'skipped_no_provider' counts toward neither — see status logic below.

      results.push({
        pushTokenId: token.id,
        platform: token.platform,
        result: outcome.result,
      });
    }

    const allSkipped = results.every((r) => r.result === 'skipped_no_provider');
    const status = allSkipped
      ? 'SKIPPED'
      : sentCount > 0 && failedCount === 0
        ? 'SENT'
        : sentCount > 0 && failedCount > 0
          ? 'PARTIAL'
          : 'FAILED';

    await this.db
      .update(notifications)
      .set({
        status,
        deliveryResults: results,
        processedAt: new Date(),
      })
      .where(eq(notifications.id, notificationId));

    if (status === 'FAILED') {
      // Let BullMQ retry the whole job per the queue's configured
      // attempts/backoff rather than silently accepting total failure.
      throw new Error(
        `All ${results.length} delivery attempt(s) failed for notification ${notificationId}.`,
      );
    }
  }
}
