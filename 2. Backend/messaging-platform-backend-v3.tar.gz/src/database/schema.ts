/**
 * Drizzle ORM schema for the WhatsApp-style messaging platform backend
 * foundation (Backend Volume 1).
 *
 * Scope: accounts, profiles, devices, sessions, conversations, conversation
 * membership, group metadata, and a minimal audit log.
 *
 * Future milestones extend this schema with Message, MessageAttachment,
 * MessageReaction, MessageReceipt, MediaAsset, Notification, PushToken and
 * SearchDocument tables. Conversation is already the natural parent for a
 * future `messages` table, and `conversation_members.last_read_at` is
 * reserved for future read-receipt / unread-count features.
 */

import {
  pgTable,
  pgEnum,
  uuid,
  text,
  boolean,
  timestamp,
  jsonb,
  bigint,
  integer,
  uniqueIndex,
  index,
} from 'drizzle-orm/pg-core';
import { relations, sql } from 'drizzle-orm';

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

export const accountStatusEnum = pgEnum('account_status', [
  'ACTIVE',
  'DISABLED',
  'DELETED',
]);

export const devicePlatformEnum = pgEnum('device_platform', [
  'IOS',
  'ANDROID',
  'WEB',
  'DESKTOP',
  'UNKNOWN',
]);

export const deviceStatusEnum = pgEnum('device_status', ['ACTIVE', 'REVOKED']);

export const conversationTypeEnum = pgEnum('conversation_type', [
  'DIRECT',
  'GROUP',
]);

export const memberRoleEnum = pgEnum('member_role', [
  'OWNER',
  'ADMIN',
  'MEMBER',
]);

export const memberStatusEnum = pgEnum('member_status', [
  'ACTIVE',
  'LEFT',
  'REMOVED',
]);

export const auditEventTypeEnum = pgEnum('audit_event_type', [
  'AUTH_LOGIN_SUCCESS',
  'AUTH_LOGIN_FAILURE',
  'AUTH_REGISTER',
  'AUTH_LOGOUT',
  'AUTH_TOKEN_REFRESH',
  'SESSION_REVOKED',
  'SESSION_REVOKED_ALL',
  'ACCOUNT_DISABLED',
  'CONVERSATION_CREATED',
  'GROUP_CREATED',
  'MEMBERSHIP_ROLE_CHANGED',
  'MEMBERSHIP_REMOVED',
  'MESSAGE_DELETED',
  'REACTION_ADDED',
  'REACTION_REMOVED',
  'MEDIA_UPLOAD_INITIATED',
  'MEDIA_READY',
  'MEDIA_DELETED',
  'PUSH_TOKEN_REGISTERED',
  'PUSH_TOKEN_INVALIDATED',
]);

export const messageTypeEnum = pgEnum('message_type', [
  'TEXT',
  // Reserved for future milestones — accepted by the type system today
  // so the column never needs a breaking migration, but no code path in
  // this milestone creates them.
  'IMAGE',
  'VIDEO',
  'AUDIO',
  'DOCUMENT',
  'SYSTEM',
]);

export const outboxStatusEnum = pgEnum('outbox_status', [
  'PENDING',
  'PUBLISHED',
  'FAILED',
]);

export const mediaCategoryEnum = pgEnum('media_category', [
  'IMAGE',
  'VIDEO',
  'AUDIO',
  'DOCUMENT',
]);

export const mediaStatusEnum = pgEnum('media_status', [
  'INITIATED',
  'UPLOADED',
  'VALIDATING',
  'PROCESSING',
  'READY',
  'FAILED',
  'DELETED',
]);

export const mediaVariantKindEnum = pgEnum('media_variant_kind', [
  'ORIGINAL',
  'THUMBNAIL',
  'PREVIEW',
]);

export const storageProviderEnum = pgEnum('storage_provider', [
  // LOCAL is the only provider actually implemented in this milestone
  // (see StorageModule / LocalFilesystemStorageAdapter). S3 is modeled
  // now so a later infrastructure milestone can add it without a
  // migration, but no S3 adapter exists yet — see README.
  'LOCAL',
  'S3',
]);

export const pushTokenStatusEnum = pgEnum('push_token_status', [
  'ACTIVE',
  'INVALID',
]);

export const notificationStatusEnum = pgEnum('notification_status', [
  'PENDING',
  'PROCESSING',
  'SENT',
  'PARTIAL',
  'FAILED',
  'SKIPPED',
]);

// ---------------------------------------------------------------------------
// Users / Profiles
// ---------------------------------------------------------------------------

export const users = pgTable(
  'users',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    email: text('email').notNull(),
    passwordHash: text('password_hash').notNull(),
    status: accountStatusEnum('status').notNull().default('ACTIVE'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    emailUnique: uniqueIndex('users_email_unique').on(
      sql`lower(${table.email})`,
    ),
    statusIdx: index('users_status_idx').on(table.status),
  }),
);

export const profiles = pgTable(
  'profiles',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: 'cascade' }),
    username: text('username').notNull(),
    displayName: text('display_name').notNull(),
    avatarUrl: text('avatar_url'),
    about: text('about'),
    showLastSeen: boolean('show_last_seen').notNull().default(true),
    showOnline: boolean('show_online').notNull().default(true),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    usernameUnique: uniqueIndex('profiles_username_unique').on(
      sql`lower(${table.username})`,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Devices / Sessions
// ---------------------------------------------------------------------------

export const devices = pgTable(
  'devices',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    platform: devicePlatformEnum('platform').notNull().default('UNKNOWN'),
    name: text('name'),
    appVersion: text('app_version'),
    status: deviceStatusEnum('status').notNull().default('ACTIVE'),
    lastActiveAt: timestamp('last_active_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    userIdx: index('devices_user_idx').on(table.userId),
    userStatusIdx: index('devices_user_status_idx').on(
      table.userId,
      table.status,
    ),
  }),
);

/**
 * Durable session record backing refresh-token issuance & revocation.
 * The refresh token itself is never stored — only a SHA-256 hash of it —
 * so a leaked database dump cannot be replayed as a valid refresh token.
 */
export const sessions = pgTable(
  'sessions',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    deviceId: uuid('device_id')
      .notNull()
      .references(() => devices.id, { onDelete: 'cascade' }),
    refreshTokenHash: text('refresh_token_hash').notNull().unique(),
    revoked: boolean('revoked').notNull().default(false),
    revokedAt: timestamp('revoked_at', { withTimezone: true }),
    expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
    lastUsedAt: timestamp('last_used_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    userIdx: index('sessions_user_idx').on(table.userId),
    userRevokedIdx: index('sessions_user_revoked_idx').on(
      table.userId,
      table.revoked,
    ),
    deviceIdx: index('sessions_device_idx').on(table.deviceId),
    expiresIdx: index('sessions_expires_idx').on(table.expiresAt),
  }),
);

// ---------------------------------------------------------------------------
// Conversations / Membership / Groups
// ---------------------------------------------------------------------------

export const conversations = pgTable(
  'conversations',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    type: conversationTypeEnum('type').notNull(),
    /**
     * Deterministic key used only for DIRECT conversations: the two
     * participant user IDs, sorted and joined. A unique index on this
     * column is what makes "at most one direct conversation per pair of
     * users" a database-enforced invariant rather than an
     * application-level, race-prone precheck. Always null for GROUP
     * conversations.
     */
    directKey: text('direct_key'),
    createdById: uuid('created_by_id')
      .notNull()
      .references(() => users.id),
    /**
     * Server-authoritative, monotonically increasing per-conversation
     * message counter. Incremented atomically (`UPDATE ... SET
     * last_sequence = last_sequence + 1 RETURNING last_sequence`) inside
     * the same transaction that inserts a message, so sequence
     * assignment is race-free under concurrent sends without a
     * distributed lock. Never assigned from a client-supplied value.
     */
    lastSequence: bigint('last_sequence', { mode: 'number' })
      .notNull()
      .default(0),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    directKeyUnique: uniqueIndex('conversations_direct_key_unique').on(
      table.directKey,
    ),
    typeIdx: index('conversations_type_idx').on(table.type),
  }),
);

export const groupProfiles = pgTable('group_profiles', {
  id: uuid('id').defaultRandom().primaryKey(),
  conversationId: uuid('conversation_id')
    .notNull()
    .unique()
    .references(() => conversations.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  description: text('description'),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const conversationMembers = pgTable(
  'conversation_members',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    role: memberRoleEnum('role').notNull().default('MEMBER'),
    status: memberStatusEnum('status').notNull().default('ACTIVE'),
    /**
     * Read/delivery are tracked as per-member checkpoints against the
     * conversation's monotonic sequence, rather than one row per
     * message per recipient — this keeps a 1,000-message group chat's
     * receipt state at one row per member, not one row per
     * message-times-member, while still letting the server compute
     * "delivered/read up to sequence N" precisely.
     */
    lastDeliveredSequence: bigint('last_delivered_sequence', {
      mode: 'number',
    })
      .notNull()
      .default(0),
    lastReadSequence: bigint('last_read_sequence', { mode: 'number' })
      .notNull()
      .default(0),
    lastReadAt: timestamp('last_read_at', { withTimezone: true }),
    joinedAt: timestamp('joined_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    leftAt: timestamp('left_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    conversationUserUnique: uniqueIndex(
      'conversation_members_conversation_user_unique',
    ).on(table.conversationId, table.userId),
    userStatusIdx: index('conversation_members_user_status_idx').on(
      table.userId,
      table.status,
    ),
    conversationStatusIdx: index(
      'conversation_members_conversation_status_idx',
    ).on(table.conversationId, table.status),
  }),
);

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------

export const messages = pgTable(
  'messages',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    senderId: uuid('sender_id')
      .notNull()
      .references(() => users.id),
    /**
     * Client-generated idempotency key. The (conversation_id, sender_id,
     * client_message_id) unique index is what makes retried sends safe:
     * a retried insert hits the constraint instead of creating a second
     * row, and the service layer re-reads and returns the original.
     */
    clientMessageId: text('client_message_id').notNull(),
    /**
     * Server-authoritative per-conversation order, assigned atomically
     * from conversations.last_sequence in the same transaction as the
     * insert. This — not created_at — is the field clients reconstruct
     * history and detect gaps from; created_at is informational only.
     */
    sequence: bigint('sequence', { mode: 'number' }).notNull(),
    type: messageTypeEnum('type').notNull().default('TEXT'),
    // Nullable as of Volume 3: an attachment-only message (media with no
    // caption) has no text content. CreateMessageDto still requires at
    // least one of content/attachments — see messages.service.ts.
    content: text('content'),
    replyToId: uuid('reply_to_id'),
    editedAt: timestamp('edited_at', { withTimezone: true }),
    deletedAt: timestamp('deleted_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    clientMessageUnique: uniqueIndex('messages_client_message_unique').on(
      table.conversationId,
      table.senderId,
      table.clientMessageId,
    ),
    conversationSequenceUnique: uniqueIndex(
      'messages_conversation_sequence_unique',
    ).on(table.conversationId, table.sequence),
    conversationSequenceIdx: index('messages_conversation_sequence_idx').on(
      table.conversationId,
      table.sequence,
    ),
    conversationCreatedIdx: index('messages_conversation_created_idx').on(
      table.conversationId,
      table.createdAt,
    ),
    senderCreatedIdx: index('messages_sender_created_idx').on(
      table.senderId,
      table.createdAt,
    ),
    replyToIdx: index('messages_reply_to_idx').on(table.replyToId),
  }),
);

/**
 * Transactional outbox: written in the same transaction as the message
 * insert/update/delete it describes, so an event is never lost to a
 * crash between "message persisted" and "event published." A background
 * processor (see OutboxProcessorService) picks up PENDING rows,
 * publishes them to connected WebSocket clients, and marks them
 * PUBLISHED — retrying with backoff on failure rather than losing the
 * event.
 */
export const messageOutbox = pgTable(
  'message_outbox',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    aggregateType: text('aggregate_type').notNull().default('message'),
    aggregateId: uuid('aggregate_id').notNull(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    eventType: text('event_type').notNull(),
    eventVersion: integer('event_version').notNull().default(1),
    payload: jsonb('payload').notNull(),
    status: outboxStatusEnum('status').notNull().default('PENDING'),
    attempts: integer('attempts').notNull().default(0),
    lastError: text('last_error'),
    publishedAt: timestamp('published_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    statusCreatedIdx: index('message_outbox_status_created_idx').on(
      table.status,
      table.createdAt,
    ),
    conversationIdx: index('message_outbox_conversation_idx').on(
      table.conversationId,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Reactions
// ---------------------------------------------------------------------------

/**
 * One active reaction per user per message (WhatsApp's actual model):
 * picking a new emoji replaces the previous one rather than stacking.
 * The unique index on (message_id, user_id) is what makes "add" an
 * upsert and makes duplicate/concurrent add requests converge safely.
 */
export const messageReactions = pgTable(
  'message_reactions',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    value: text('value').notNull(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    messageUserUnique: uniqueIndex('message_reactions_message_user_unique').on(
      table.messageId,
      table.userId,
    ),
    messageIdx: index('message_reactions_message_idx').on(table.messageId),
    conversationIdx: index('message_reactions_conversation_idx').on(
      table.conversationId,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Media
// ---------------------------------------------------------------------------

/**
 * Durable metadata only — binary content lives in object storage (see
 * StorageModule), never in Postgres. storageKey is an internal
 * reference, never returned to clients directly (see media DTOs);
 * clients get short-lived signed access URLs instead.
 */
export const mediaAssets = pgTable(
  'media_assets',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    ownerId: uuid('owner_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    category: mediaCategoryEnum('category').notNull(),
    status: mediaStatusEnum('status').notNull().default('INITIATED'),
    storageProvider: storageProviderEnum('storage_provider')
      .notNull()
      .default('LOCAL'),
    storageKey: text('storage_key').notNull(),
    declaredContentType: text('declared_content_type').notNull(),
    /** Detected from actual file bytes after upload — never trusted from the client alone. See MediaService.validateUploadedObject. */
    detectedContentType: text('detected_content_type'),
    declaredSizeBytes: bigint('declared_size_bytes', {
      mode: 'number',
    }).notNull(),
    actualSizeBytes: bigint('actual_size_bytes', { mode: 'number' }),
    checksumSha256: text('checksum_sha256'),
    originalFilename: text('original_filename'),
    widthPx: integer('width_px'),
    heightPx: integer('height_px'),
    durationSeconds: integer('duration_seconds'),
    failureReason: text('failure_reason'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    deletedAt: timestamp('deleted_at', { withTimezone: true }),
  },
  (table) => ({
    ownerIdx: index('media_assets_owner_idx').on(table.ownerId),
    statusIdx: index('media_assets_status_idx').on(table.status),
  }),
);

export const mediaVariants = pgTable(
  'media_variants',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    mediaAssetId: uuid('media_asset_id')
      .notNull()
      .references(() => mediaAssets.id, { onDelete: 'cascade' }),
    kind: mediaVariantKindEnum('kind').notNull(),
    storageKey: text('storage_key').notNull(),
    contentType: text('content_type').notNull(),
    widthPx: integer('width_px'),
    heightPx: integer('height_px'),
    sizeBytes: bigint('size_bytes', { mode: 'number' }).notNull(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    mediaAssetKindUnique: uniqueIndex('media_variants_asset_kind_unique').on(
      table.mediaAssetId,
      table.kind,
    ),
  }),
);

/** Links a durable message to a ready media asset. A message may have
 * text, attachments, or both — see messages.content (nullable). */
export const messageAttachments = pgTable(
  'message_attachments',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    mediaAssetId: uuid('media_asset_id')
      .notNull()
      .references(() => mediaAssets.id),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    messageIdx: index('message_attachments_message_idx').on(table.messageId),
    mediaAssetUnique: uniqueIndex('message_attachments_media_asset_unique').on(
      table.mediaAssetId,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Push tokens / Notifications
// ---------------------------------------------------------------------------

export const pushTokens = pgTable(
  'push_tokens',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    deviceId: uuid('device_id')
      .notNull()
      .references(() => devices.id, { onDelete: 'cascade' }),
    platform: devicePlatformEnum('platform').notNull(),
    token: text('token').notNull(),
    status: pushTokenStatusEnum('status').notNull().default('ACTIVE'),
    appVersion: text('app_version'),
    lastUsedAt: timestamp('last_used_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    tokenUnique: uniqueIndex('push_tokens_token_unique').on(table.token),
    userIdx: index('push_tokens_user_idx').on(table.userId),
    userStatusIdx: index('push_tokens_user_status_idx').on(
      table.userId,
      table.status,
    ),
  }),
);

export const notificationPreferences = pgTable('notification_preferences', {
  userId: uuid('user_id')
    .primaryKey()
    .references(() => users.id, { onDelete: 'cascade' }),
  messageNotifications: boolean('message_notifications')
    .notNull()
    .default(true),
  groupNotifications: boolean('group_notifications').notNull().default(true),
  mentionNotifications: boolean('mention_notifications')
    .notNull()
    .default(true),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/**
 * Notification intent + outcome in one row (no separate per-device
 * delivery table in this milestone — deliveryResults is a small JSON
 * summary of the fan-out to that user's devices, kept here rather than
 * normalized to bound this milestone's schema surface; see README).
 * The unique index on (user_id, source_event_type, source_event_id) is
 * the deduplication mechanism: a retried or duplicate-published event
 * for the same recipient can never create a second notification row.
 */
export const notifications = pgTable(
  'notifications',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    sourceEventType: text('source_event_type').notNull(),
    sourceEventId: text('source_event_id').notNull(),
    conversationId: uuid('conversation_id').references(() => conversations.id, {
      onDelete: 'set null',
    }),
    title: text('title').notNull(),
    body: text('body').notNull(),
    data: jsonb('data'),
    status: notificationStatusEnum('status').notNull().default('PENDING'),
    attempts: integer('attempts').notNull().default(0),
    lastError: text('last_error'),
    deliveryResults: jsonb('delivery_results'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    processedAt: timestamp('processed_at', { withTimezone: true }),
  },
  (table) => ({
    dedupUnique: uniqueIndex('notifications_dedup_unique').on(
      table.userId,
      table.sourceEventType,
      table.sourceEventId,
    ),
    userStatusIdx: index('notifications_user_status_idx').on(
      table.userId,
      table.status,
    ),
    statusCreatedIdx: index('notifications_status_created_idx').on(
      table.status,
      table.createdAt,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Audit
// ---------------------------------------------------------------------------

export const auditEvents = pgTable(
  'audit_events',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    type: auditEventTypeEnum('type').notNull(),
    userId: uuid('user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    ip: text('ip'),
    userAgent: text('user_agent'),
    metadata: jsonb('metadata'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    userIdx: index('audit_events_user_idx').on(table.userId),
    typeIdx: index('audit_events_type_idx').on(table.type),
    createdAtIdx: index('audit_events_created_at_idx').on(table.createdAt),
  }),
);

// ---------------------------------------------------------------------------
// Relations (used for Drizzle's relational query API)
// ---------------------------------------------------------------------------

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  devices: many(devices),
  sessions: many(sessions),
  conversationMemberships: many(conversationMembers),
  createdConversations: many(conversations),
  auditEvents: many(auditEvents),
}));

export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, { fields: [profiles.userId], references: [users.id] }),
}));

export const devicesRelations = relations(devices, ({ one, many }) => ({
  user: one(users, { fields: [devices.userId], references: [users.id] }),
  sessions: many(sessions),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, { fields: [sessions.userId], references: [users.id] }),
  device: one(devices, {
    fields: [sessions.deviceId],
    references: [devices.id],
  }),
}));

export const conversationsRelations = relations(
  conversations,
  ({ one, many }) => ({
    createdBy: one(users, {
      fields: [conversations.createdById],
      references: [users.id],
    }),
    members: many(conversationMembers),
    group: one(groupProfiles, {
      fields: [conversations.id],
      references: [groupProfiles.conversationId],
    }),
  }),
);

export const groupProfilesRelations = relations(groupProfiles, ({ one }) => ({
  conversation: one(conversations, {
    fields: [groupProfiles.conversationId],
    references: [conversations.id],
  }),
}));

export const conversationMembersRelations = relations(
  conversationMembers,
  ({ one }) => ({
    conversation: one(conversations, {
      fields: [conversationMembers.conversationId],
      references: [conversations.id],
    }),
    user: one(users, {
      fields: [conversationMembers.userId],
      references: [users.id],
    }),
  }),
);

export const auditEventsRelations = relations(auditEvents, ({ one }) => ({
  user: one(users, { fields: [auditEvents.userId], references: [users.id] }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
  sender: one(users, { fields: [messages.senderId], references: [users.id] }),
  replyTo: one(messages, {
    fields: [messages.replyToId],
    references: [messages.id],
  }),
}));

export const messageOutboxRelations = relations(messageOutbox, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messageOutbox.conversationId],
    references: [conversations.id],
  }),
}));

export const messageReactionsRelations = relations(
  messageReactions,
  ({ one }) => ({
    message: one(messages, {
      fields: [messageReactions.messageId],
      references: [messages.id],
    }),
    user: one(users, {
      fields: [messageReactions.userId],
      references: [users.id],
    }),
  }),
);

export const mediaAssetsRelations = relations(mediaAssets, ({ one, many }) => ({
  owner: one(users, { fields: [mediaAssets.ownerId], references: [users.id] }),
  variants: many(mediaVariants),
}));

export const mediaVariantsRelations = relations(mediaVariants, ({ one }) => ({
  mediaAsset: one(mediaAssets, {
    fields: [mediaVariants.mediaAssetId],
    references: [mediaAssets.id],
  }),
}));

export const messageAttachmentsRelations = relations(
  messageAttachments,
  ({ one }) => ({
    message: one(messages, {
      fields: [messageAttachments.messageId],
      references: [messages.id],
    }),
    mediaAsset: one(mediaAssets, {
      fields: [messageAttachments.mediaAssetId],
      references: [mediaAssets.id],
    }),
  }),
);

export const pushTokensRelations = relations(pushTokens, ({ one }) => ({
  user: one(users, { fields: [pushTokens.userId], references: [users.id] }),
  device: one(devices, {
    fields: [pushTokens.deviceId],
    references: [devices.id],
  }),
}));

export const notificationPreferencesRelations = relations(
  notificationPreferences,
  ({ one }) => ({
    user: one(users, {
      fields: [notificationPreferences.userId],
      references: [users.id],
    }),
  }),
);

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
  conversation: one(conversations, {
    fields: [notifications.conversationId],
    references: [conversations.id],
  }),
}));
