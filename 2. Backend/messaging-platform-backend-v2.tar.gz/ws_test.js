const { io } = require("socket.io-client");
const fs = require("fs");

const alice = JSON.parse(fs.readFileSync("/tmp/alice2.json"));
const bob = JSON.parse(fs.readFileSync("/tmp/bob2.json"));
const convoId = "2ea585a2-b17b-45f2-867f-efdd8d92ad80";

const aliceSocket = io("http://localhost:3000", {
  path: "/realtime",
  auth: { token: alice.tokens.accessToken },
  transports: ["websocket"],
});
const bobSocket = io("http://localhost:3000", {
  path: "/realtime",
  auth: { token: bob.tokens.accessToken },
  transports: ["websocket"],
});

let bobReceivedEvent = null;

bobSocket.on("connect", () => console.log("bob connected", bobSocket.id));
aliceSocket.on("connect", () => console.log("alice connected", aliceSocket.id));

bobSocket.on("event", (envelope) => {
  console.log("BOB RECEIVED EVENT:", JSON.stringify(envelope));
  bobReceivedEvent = envelope;
});

aliceSocket.on("connect_error", (err) => console.log("alice connect_error", err.message));
bobSocket.on("connect_error", (err) => console.log("bob connect_error", err.message));

setTimeout(() => {
  aliceSocket.emit("send_message", {
    conversationId: convoId,
    clientMessageId: "ws-msg-1",
    content: "Hello via WebSocket!",
  }, (ack) => {
    console.log("SEND_MESSAGE ACK:", JSON.stringify(ack));
  });
}, 1000);

setTimeout(() => {
  console.log("bobReceivedEvent is null?", bobReceivedEvent === null);
  process.exit(bobReceivedEvent ? 0 : 1);
}, 3000);
