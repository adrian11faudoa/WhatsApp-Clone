import { HttpStatus, Inject, Injectable, Logger } from '@nestjs/common';
import { and, asc, desc, eq, gt, lt, sql } from 'drizzle-orm';
import { DATABASE_CONNECTION, Database } from '../database/database.module';
import {
  conversationMembers,
  conversations,
  messageOutbox,
  messages,
} from '../database/schema';
import { AppException } from '../common/errors/app.exception';
import { AppErrorCode } from '../common/errors/app-error-codes';
import { ConversationMembershipService } from '../conversations/conversation-membership.service';
import {
  CreateMessageDto,
  EditMessageDto,
  MessageResponseDto,
} from './dto/message.dto';
import { ConversationReceiptStateDto } from './dto/receipt.dto';
import { RealtimeEventType } from '../realtime/realtime-envelope';
import { OutboxPublisherService } from '../realtime/outbox-publisher.service';

const MAX_HISTORY_PAGE_SIZE = 100;
const DEFAULT_HISTORY_PAGE_SIZE = 30;
const MAX_SYNC_PAGE_SIZE = 200;
const DEFAULT_SYNC_PAGE_SIZE = 100;

export interface MessagePage {
  items: MessageResponseDto[];
  nextCursor: number | null;
  hasMore: boolean;
}

@Injectable()
export class MessagesService {
  private readonly logger = new Logger(MessagesService.name);

  constructor(
    @Inject(DATABASE_CONNECTION) private readonly db: Database,
    private readonly membershipService: ConversationMembershipService,
    private readonly outboxPublisher: OutboxPublisherService,
  ) {}

  /**
   * Implements the full message-creation flow: authorization, payload
   * validation (DTO-level, already done by this point), idempotency,
   * transactional persistence with an atomically-assigned sequence, and
   * an outbox row in the same transaction — then a best-effort
   * immediate publish attempt outside the transaction (the outbox
   * poller is the durability backstop if that attempt fails or the
   * process crashes before it runs).
   */
  async createMessage(
    senderId: string,
    conversationId: string,
    dto: CreateMessageDto,
  ): Promise<MessageResponseDto> {
    await this.membershipService.assertActiveMember(senderId, conversationId);

    if (dto.replyToId) {
      await this.assertReplyTargetInConversation(conversationId, dto.replyToId);
    }

    let outboxRowId: string;
    let message: MessageResponseDto;

    try {
      const result = await this.db.transaction(async (tx) => {
        const [conversation] = await tx
          .update(conversations)
          .set({
            lastSequence: sql`${conversations.lastSequence} + 1`,
            updatedAt: new Date(),
          })
          .where(eq(conversations.id, conversationId))
          .returning({ lastSequence: conversations.lastSequence });

        const [inserted] = await tx
          .insert(messages)
          .values({
            conversationId,
            senderId,
            clientMessageId: dto.clientMessageId,
            sequence: conversation.lastSequence,
            type: dto.type ?? 'TEXT',
            content: dto.content,
            replyToId: dto.replyToId,
          })
          .returning();

        const dtoRow = this.toResponseDto(inserted);

        const [outboxRow] = await tx
          .insert(messageOutbox)
          .values({
            aggregateType: 'message',
            aggregateId: inserted.id,
            conversationId,
            eventType: RealtimeEventType.MESSAGE_CREATED,
            payload: dtoRow,
          })
          .returning({ id: messageOutbox.id });

        return { dtoRow, outboxRowId: outboxRow.id };
      });

      message = result.dtoRow;
      outboxRowId = result.outboxRowId;
    } catch (err) {
      if (this.isUniqueViolation(err, 'messages_client_message_unique')) {
        // Idempotent retry: return the message that was already created
        // for this (conversation, sender, clientMessageId) rather than
        // erroring — this is what makes a client's retry-after-timeout
        // safe.
        const existing = await this.findByClientMessageId(
          conversationId,
          senderId,
          dto.clientMessageId,
        );
        if (existing) {
          return existing;
        }
      }
      throw err;
    }

    // Best-effort immediate fan-out; the outbox poller retries this row
    // if it fails or the process doesn't get to run it (e.g. crash right
    // after commit).
    this.outboxPublisher.tryPublishImmediately(outboxRowId).catch((err) => {
      this.logger.warn(
        `Immediate outbox publish failed for row ${outboxRowId}, will be retried by the poller: ${(err as Error).message}`,
      );
    });

    return message;
  }

  async getMessage(
    userId: string,
    conversationId: string,
    messageId: string,
  ): Promise<MessageResponseDto> {
    await this.membershipService.assertActiveMember(userId, conversationId);

    const [row] = await this.db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.id, messageId),
          eq(messages.conversationId, conversationId),
        ),
      )
      .limit(1);

    if (!row) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Message not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    return this.toResponseDto(row);
  }

  /**
   * Browsing pagination: most recent first, paged backwards via
   * `beforeSequence`. Cursor is simply the oldest sequence returned so
   * far — sequence is already a per-conversation-unique, monotonic,
   * server-assigned integer, so no opaque encoding is needed (unlike
   * the createdAt+id cursor used for conversation listing, which has no
   * single unique sortable column).
   */
  async listHistory(
    userId: string,
    conversationId: string,
    beforeSequence: number | undefined,
    limit: number | undefined,
  ): Promise<MessagePage> {
    await this.membershipService.assertActiveMember(userId, conversationId);

    const pageSize = this.resolveLimit(
      limit,
      DEFAULT_HISTORY_PAGE_SIZE,
      MAX_HISTORY_PAGE_SIZE,
    );

    const conditions = [eq(messages.conversationId, conversationId)];
    if (beforeSequence !== undefined) {
      conditions.push(lt(messages.sequence, beforeSequence));
    }

    const rows = await this.db
      .select()
      .from(messages)
      .where(and(...conditions))
      .orderBy(desc(messages.sequence))
      .limit(pageSize + 1);

    const hasMore = rows.length > pageSize;
    const page = rows.slice(0, pageSize);
    const last = page[page.length - 1];

    return {
      items: page.map((row) => this.toResponseDto(row)),
      nextCursor: hasMore && last ? last.sequence : null,
      hasMore,
    };
  }

  /**
   * Synchronization / catch-up pagination: oldest-first, strictly after
   * a client-supplied checkpoint. Used by both the REST sync endpoint
   * and the WebSocket `synchronize` command — one implementation for
   * both transports. Bounded regardless of how far behind the client
   * is; a client far behind simply calls this repeatedly until
   * `hasMore` is false, which is also how a "sequence gap" resolves:
   * since Postgres retains full history in this milestone (nothing is
   * pruned), there is no unrecoverable gap, only more pages to fetch.
   */
  async listSince(
    userId: string,
    conversationId: string,
    afterSequence: number,
    limit: number | undefined,
  ): Promise<MessagePage> {
    await this.membershipService.assertActiveMember(userId, conversationId);

    const pageSize = this.resolveLimit(
      limit,
      DEFAULT_SYNC_PAGE_SIZE,
      MAX_SYNC_PAGE_SIZE,
    );

    const rows = await this.db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.conversationId, conversationId),
          gt(messages.sequence, afterSequence),
        ),
      )
      .orderBy(asc(messages.sequence))
      .limit(pageSize + 1);

    const hasMore = rows.length > pageSize;
    const page = rows.slice(0, pageSize);
    const last = page[page.length - 1];

    return {
      items: page.map((row) => this.toResponseDto(row)),
      nextCursor: hasMore && last ? last.sequence : null,
      hasMore,
    };
  }

  async editMessage(
    actorId: string,
    conversationId: string,
    messageId: string,
    dto: EditMessageDto,
  ): Promise<MessageResponseDto> {
    await this.membershipService.assertActiveMember(actorId, conversationId);

    const [existing] = await this.db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.id, messageId),
          eq(messages.conversationId, conversationId),
        ),
      )
      .limit(1);

    if (!existing) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Message not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    // Only the original sender may edit their own message — the product
    // authorization model for this milestone does not grant group
    // admins/owners edit rights over others' messages.
    if (existing.senderId !== actorId) {
      throw new AppException({
        code: AppErrorCode.FORBIDDEN,
        message: 'Only the sender can edit this message.',
        status: HttpStatus.FORBIDDEN,
      });
    }

    if (existing.deletedAt) {
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: 'Cannot edit a deleted message.',
        status: HttpStatus.BAD_REQUEST,
      });
    }

    const { dtoRow, outboxRowId } = await this.db.transaction(async (tx) => {
      const now = new Date();
      const [updated] = await tx
        .update(messages)
        .set({ content: dto.content, editedAt: now, updatedAt: now })
        .where(eq(messages.id, messageId))
        .returning();

      const row = this.toResponseDto(updated);

      const [outboxRow] = await tx
        .insert(messageOutbox)
        .values({
          aggregateType: 'message',
          aggregateId: messageId,
          conversationId,
          eventType: RealtimeEventType.MESSAGE_UPDATED,
          payload: row,
        })
        .returning({ id: messageOutbox.id });

      return { dtoRow: row, outboxRowId: outboxRow.id };
    });

    this.outboxPublisher.tryPublishImmediately(outboxRowId).catch((err) => {
      this.logger.warn(
        `Immediate outbox publish failed for row ${outboxRowId}: ${(err as Error).message}`,
      );
    });

    return dtoRow;
  }

  /**
   * Deletes a message "for everyone" — the only deletion mode
   * implemented in this milestone (see README for the explicit scope
   * decision). Idempotent: deleting an already-deleted message is a
   * no-op success rather than an error, since two near-simultaneous
   * delete taps from the same user's multiple devices are an expected
   * case, not a conflict.
   */
  async deleteMessage(
    actorId: string,
    conversationId: string,
    messageId: string,
  ): Promise<void> {
    await this.membershipService.assertActiveMember(actorId, conversationId);

    const [existing] = await this.db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.id, messageId),
          eq(messages.conversationId, conversationId),
        ),
      )
      .limit(1);

    if (!existing) {
      throw new AppException({
        code: AppErrorCode.NOT_FOUND,
        message: 'Message not found.',
        status: HttpStatus.NOT_FOUND,
      });
    }

    if (existing.senderId !== actorId) {
      throw new AppException({
        code: AppErrorCode.FORBIDDEN,
        message: 'Only the sender can delete this message.',
        status: HttpStatus.FORBIDDEN,
      });
    }

    if (existing.deletedAt) {
      return; // already deleted — idempotent no-op
    }

    const outboxRowId = await this.db.transaction(async (tx) => {
      const now = new Date();
      // Content stays in the row (the column is NOT NULL) — deletion is
      // represented purely by deleted_at, and toResponseDto() masks
      // content to null for any row where deleted_at is set. This keeps
      // "logical delete" simple without a schema change, while the API
      // never exposes deleted content to clients.
      await tx
        .update(messages)
        .set({ deletedAt: now, updatedAt: now })
        .where(eq(messages.id, messageId));

      const [outboxRow] = await tx
        .insert(messageOutbox)
        .values({
          aggregateType: 'message',
          aggregateId: messageId,
          conversationId,
          eventType: RealtimeEventType.MESSAGE_DELETED,
          payload: {
            id: messageId,
            conversationId,
            deletedAt: now.toISOString(),
          },
        })
        .returning({ id: messageOutbox.id });

      return outboxRow.id;
    });

    this.outboxPublisher.tryPublishImmediately(outboxRowId).catch((err) => {
      this.logger.warn(
        `Immediate outbox publish failed for row ${outboxRowId}: ${(err as Error).message}`,
      );
    });
  }

  /**
   * Delivery/read are per-member sequence checkpoints, not per-message
   * rows — see schema.ts for the reasoning. GREATEST() makes moving the
   * checkpoint backwards impossible and the whole operation naturally
   * idempotent (re-acking the same or an older sequence is a no-op).
   */
  async acknowledgeDelivery(
    userId: string,
    conversationId: string,
    upToSequence: number,
  ): Promise<void> {
    await this.membershipService.assertActiveMember(userId, conversationId);
    await this.bumpCheckpoint(
      userId,
      conversationId,
      'lastDeliveredSequence',
      upToSequence,
    );
    await this.publishReceiptEvent(
      RealtimeEventType.MESSAGE_DELIVERED,
      userId,
      conversationId,
      upToSequence,
    );
  }

  async acknowledgeRead(
    userId: string,
    conversationId: string,
    upToSequence: number,
  ): Promise<void> {
    await this.membershipService.assertActiveMember(userId, conversationId);
    // Reading implies delivery, so bump both checkpoints together.
    await this.bumpCheckpoint(
      userId,
      conversationId,
      'lastDeliveredSequence',
      upToSequence,
    );
    await this.bumpCheckpoint(
      userId,
      conversationId,
      'lastReadSequence',
      upToSequence,
    );
    await this.publishReceiptEvent(
      RealtimeEventType.MESSAGE_READ,
      userId,
      conversationId,
      upToSequence,
    );
  }

  async getReceiptState(
    userId: string,
    conversationId: string,
  ): Promise<ConversationReceiptStateDto[]> {
    await this.membershipService.assertActiveMember(userId, conversationId);

    return this.db
      .select({
        userId: conversationMembers.userId,
        lastDeliveredSequence: conversationMembers.lastDeliveredSequence,
        lastReadSequence: conversationMembers.lastReadSequence,
      })
      .from(conversationMembers)
      .where(
        and(
          eq(conversationMembers.conversationId, conversationId),
          eq(conversationMembers.status, 'ACTIVE'),
        ),
      );
  }

  // ---------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------

  private async bumpCheckpoint(
    userId: string,
    conversationId: string,
    column: 'lastDeliveredSequence' | 'lastReadSequence',
    upToSequence: number,
  ): Promise<void> {
    const field =
      column === 'lastDeliveredSequence'
        ? conversationMembers.lastDeliveredSequence
        : conversationMembers.lastReadSequence;

    await this.db
      .update(conversationMembers)
      .set({
        [column]: sql`GREATEST(${field}, ${upToSequence})`,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(conversationMembers.conversationId, conversationId),
          eq(conversationMembers.userId, userId),
        ),
      );
  }

  private async publishReceiptEvent(
    eventType: RealtimeEventType,
    userId: string,
    conversationId: string,
    upToSequence: number,
  ): Promise<void> {
    const [outboxRow] = await this.db
      .insert(messageOutbox)
      .values({
        aggregateType: 'receipt',
        aggregateId: conversationId,
        conversationId,
        eventType,
        payload: { userId, conversationId, upToSequence },
      })
      .returning({ id: messageOutbox.id });

    this.outboxPublisher.tryPublishImmediately(outboxRow.id).catch((err) => {
      this.logger.warn(
        `Immediate outbox publish failed for row ${outboxRow.id}: ${(err as Error).message}`,
      );
    });
  }

  private async assertReplyTargetInConversation(
    conversationId: string,
    replyToId: string,
  ): Promise<void> {
    const [target] = await this.db
      .select({ id: messages.id })
      .from(messages)
      .where(
        and(
          eq(messages.id, replyToId),
          eq(messages.conversationId, conversationId),
        ),
      )
      .limit(1);

    if (!target) {
      throw new AppException({
        code: AppErrorCode.VALIDATION_FAILED,
        message: 'replyToId must reference a message in the same conversation.',
        status: HttpStatus.BAD_REQUEST,
      });
    }
  }

  private async findByClientMessageId(
    conversationId: string,
    senderId: string,
    clientMessageId: string,
  ): Promise<MessageResponseDto | null> {
    const [row] = await this.db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.conversationId, conversationId),
          eq(messages.senderId, senderId),
          eq(messages.clientMessageId, clientMessageId),
        ),
      )
      .limit(1);

    return row ? this.toResponseDto(row) : null;
  }

  private resolveLimit(
    limit: number | undefined,
    defaultSize: number,
    maxSize: number,
  ): number {
    if (!limit || limit < 1) return defaultSize;
    return Math.min(limit, maxSize);
  }

  private toResponseDto(row: typeof messages.$inferSelect): MessageResponseDto {
    return {
      id: row.id,
      conversationId: row.conversationId,
      senderId: row.senderId,
      clientMessageId: row.clientMessageId,
      sequence: row.sequence,
      type: row.type,
      content: row.deletedAt ? null : row.content,
      replyToId: row.replyToId,
      editedAt: row.editedAt,
      deletedAt: row.deletedAt,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    };
  }

  private isUniqueViolation(err: unknown, constraintName: string): boolean {
    const pgErr = this.extractPgError(err);
    return pgErr?.code === '23505' && pgErr?.constraint === constraintName;
  }

  private extractPgError(
    err: unknown,
  ): { code?: string; constraint?: string } | undefined {
    if (!err || typeof err !== 'object') return undefined;
    const candidate = err as {
      code?: string;
      constraint?: string;
      cause?: unknown;
    };
    if (candidate.code && candidate.constraint) return candidate;
    if (candidate.cause) return this.extractPgError(candidate.cause);
    return undefined;
  }
}
