import { Module } from '@nestjs/common';
import { PresenceRegistryService } from './presence-registry.service';
import { RealtimeServerRegistryService } from './realtime-server-registry.service';
import { OutboxPublisherService } from './outbox-publisher.service';
import { OutboxProcessorService } from './outbox-processor.service';
import { RedisRateLimiterService } from '../common/rate-limit/redis-rate-limiter.service';

/**
 * Core realtime infrastructure with no dependency on MessagesModule —
 * MessagingGateway (which does depend on MessagesService) lives inside
 * MessagesModule instead of here, specifically to avoid a
 * RealtimeModule <-> MessagesModule import cycle.
 */
@Module({
  providers: [
    PresenceRegistryService,
    RealtimeServerRegistryService,
    OutboxPublisherService,
    OutboxProcessorService,
    RedisRateLimiterService,
  ],
  exports: [
    PresenceRegistryService,
    RealtimeServerRegistryService,
    OutboxPublisherService,
    RedisRateLimiterService,
  ],
})
export class RealtimeModule {}
