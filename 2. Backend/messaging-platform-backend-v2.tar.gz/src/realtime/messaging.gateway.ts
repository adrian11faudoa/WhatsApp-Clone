import { Logger, UnauthorizedException } from '@nestjs/common';
import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { TokenService } from '../auth/token.service';
import { AuthContextService } from '../auth/auth-context.service';
import { ConversationMembershipService } from '../conversations/conversation-membership.service';
import { MessagesService } from '../messages/messages.service';
import { PresenceRegistryService } from './presence-registry.service';
import { RealtimeServerRegistryService } from './realtime-server-registry.service';
import { RedisRateLimiterService } from '../common/rate-limit/redis-rate-limiter.service';
import {
  AcknowledgeCommandPayload,
  SendMessageCommandPayload,
  SynchronizeCommandPayload,
} from './dto/command-payloads';
import { RealtimeErrorCode } from './realtime-envelope';
import { AppException } from '../common/errors/app.exception';

interface AuthenticatedSocketData {
  userId: string;
  sessionId: string;
  deviceId: string;
}

/**
 * Authenticated realtime gateway. Connection-level auth derives identity
 * from a verified access token (via AuthContextService — the same live
 * session/account check the HTTP path uses), never from anything the
 * client claims about itself. Each command handler re-derives
 * authorization from that server-established identity, never from
 * fields in the payload.
 */
@WebSocketGateway({
  // Socket.io's CORS handshake is configured independently of the HTTP
  // CORS in main.ts because @WebSocketGateway's options are evaluated at
  // class-definition time, before ConfigModule has loaded .env — so it
  // cannot read CORS_ORIGINS here. `origin: true` reflects the
  // requesting origin (i.e. allows any origin with credentials), which
  // is broader than the HTTP CORS policy; tightening this to reuse
  // CORS_ORIGINS is a natural follow-up for the infrastructure
  // milestone, not implemented here to avoid a fragile config-timing
  // workaround.
  cors: { origin: true, credentials: true },
  path: '/realtime',
})
export class MessagingGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(MessagingGateway.name);

  constructor(
    private readonly tokenService: TokenService,
    private readonly authContext: AuthContextService,
    private readonly membershipService: ConversationMembershipService,
    private readonly messagesService: MessagesService,
    private readonly presence: PresenceRegistryService,
    private readonly registry: RealtimeServerRegistryService,
    private readonly rateLimiter: RedisRateLimiterService,
  ) {}

  afterInit(server: Server) {
    this.registry.setServer(server);

    // Socket.io handshake middleware runs to completion BEFORE the
    // 'connection' event fires and before any command packet is
    // processed — unlike doing this work in handleConnection (an
    // ordinary async event handler), which the client's own 'connect'
    // event does not wait for, creating a window where a command could
    // arrive before authentication has actually finished. Using
    // middleware here closes that window: auth is guaranteed complete
    // before the client can emit anything, and a rejection here surfaces
    // to the client as a proper 'connect_error', not a connect-then-
    // immediate-disconnect.
    server.use((socket, next) => {
      this.authenticateHandshake(socket)
        .then(() => next())
        .catch((err) =>
          next(err instanceof Error ? err : new Error(String(err))),
        );
    });

    this.logger.log('Realtime gateway initialized.');
  }

  private async authenticateHandshake(client: Socket): Promise<void> {
    const ip = client.handshake.address;
    const connectionAllowed = await this.rateLimiter.consume(
      `ws:connect:${ip}`,
      20,
      60_000,
    );
    if (!connectionAllowed) {
      throw new Error('Too many connection attempts.');
    }

    const token = this.extractToken(client);
    if (!token) {
      throw new Error('Missing authentication token.');
    }

    let payload;
    try {
      payload = this.tokenService.verifyAccessToken(token);
    } catch {
      throw new Error('Invalid or expired token.');
    }

    const authenticated = await this.authContext.resolveFromPayload(payload);
    const data: AuthenticatedSocketData = {
      userId: authenticated.userId,
      sessionId: authenticated.sessionId,
      deviceId: authenticated.deviceId,
    };
    client.data = data;
  }

  async handleConnection(client: Socket) {
    // By the time this runs, authenticateHandshake (above) has already
    // completed successfully — the middleware would have rejected the
    // connection before 'connection'/handleConnection ever fires
    // otherwise. client.data is therefore guaranteed to be set here.
    try {
      const user = client.data as AuthenticatedSocketData;

      await client.join(this.registry.userRoom(user.userId));

      const conversationIds =
        await this.membershipService.listActiveConversationIdsForUser(
          user.userId,
        );
      await Promise.all(
        conversationIds.map((id) =>
          client.join(this.registry.conversationRoom(id)),
        ),
      );

      await this.presence.registerConnection(client.id, {
        userId: user.userId,
        deviceId: user.deviceId,
        sessionId: user.sessionId,
        connectedAt: Date.now(),
      });

      this.logger.log(
        `Socket ${client.id} connected for user ${user.userId} (${conversationIds.length} conversation room(s)).`,
      );
    } catch (err) {
      this.logger.warn(
        `Connection setup failed for socket ${client.id}: ${(err as Error).message}`,
      );
      client.disconnect(true);
    }
  }

  async handleDisconnect(client: Socket) {
    await this.presence.unregisterConnection(client.id);
  }

  @SubscribeMessage('heartbeat')
  async handleHeartbeat(@ConnectedSocket() client: Socket) {
    await this.presence.refreshHeartbeat(client.id);
    return { ok: true };
  }

  @SubscribeMessage('send_message')
  async handleSendMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: unknown,
  ) {
    const user = this.requireUser(client);

    const allowed = await this.rateLimiter.consume(
      `ws:send_message:user:${user.userId}`,
      20,
      10_000,
    );
    if (!allowed) {
      return this.errorAck(RealtimeErrorCode.RATE_LIMITED, 'Sending too fast.');
    }

    const payload = await this.validatePayload(SendMessageCommandPayload, body);
    if ('error' in payload) return payload.error;

    try {
      const message = await this.messagesService.createMessage(
        user.userId,
        payload.value.conversationId,
        {
          clientMessageId: payload.value.clientMessageId,
          type: payload.value.type,
          content: payload.value.content,
          replyToId: payload.value.replyToId,
        },
      );
      return { ok: true, message };
    } catch (err) {
      return this.fromAppException(err);
    }
  }

  @SubscribeMessage('acknowledge_delivery')
  async handleAcknowledgeDelivery(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: unknown,
  ) {
    return this.handleAcknowledge(client, body, 'delivery');
  }

  @SubscribeMessage('acknowledge_read')
  async handleAcknowledgeRead(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: unknown,
  ) {
    return this.handleAcknowledge(client, body, 'read');
  }

  @SubscribeMessage('synchronize')
  async handleSynchronize(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: unknown,
  ) {
    const user = this.requireUser(client);

    const allowed = await this.rateLimiter.consume(
      `ws:synchronize:user:${user.userId}`,
      10,
      10_000,
    );
    if (!allowed) {
      return this.errorAck(
        RealtimeErrorCode.RATE_LIMITED,
        'Synchronizing too frequently.',
      );
    }

    const payload = await this.validatePayload(SynchronizeCommandPayload, body);
    if ('error' in payload) return payload.error;

    try {
      const page = await this.messagesService.listSince(
        user.userId,
        payload.value.conversationId,
        payload.value.afterSequence,
        payload.value.limit,
      );
      return { ok: true, ...page };
    } catch (err) {
      return this.fromAppException(err);
    }
  }

  // ---------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------

  private async handleAcknowledge(
    client: Socket,
    body: unknown,
    kind: 'delivery' | 'read',
  ) {
    const user = this.requireUser(client);

    const allowed = await this.rateLimiter.consume(
      `ws:acknowledge_${kind}:user:${user.userId}`,
      30,
      10_000,
    );
    if (!allowed) {
      return this.errorAck(
        RealtimeErrorCode.RATE_LIMITED,
        'Acknowledging too frequently.',
      );
    }

    const payload = await this.validatePayload(AcknowledgeCommandPayload, body);
    if ('error' in payload) return payload.error;

    try {
      if (kind === 'delivery') {
        await this.messagesService.acknowledgeDelivery(
          user.userId,
          payload.value.conversationId,
          payload.value.upToSequence,
        );
      } else {
        await this.messagesService.acknowledgeRead(
          user.userId,
          payload.value.conversationId,
          payload.value.upToSequence,
        );
      }
      return { ok: true };
    } catch (err) {
      return this.fromAppException(err);
    }
  }

  private requireUser(client: Socket): AuthenticatedSocketData {
    const data = client.data as AuthenticatedSocketData | undefined;
    if (!data?.userId) {
      throw new UnauthorizedException('Connection is not authenticated.');
    }
    return data;
  }

  private extractToken(client: Socket): string | null {
    const authToken = client.handshake.auth?.token as string | undefined;
    if (authToken) {
      return authToken.replace(/^Bearer\s+/i, '');
    }
    const headerAuth = client.handshake.headers.authorization;
    if (typeof headerAuth === 'string') {
      return headerAuth.replace(/^Bearer\s+/i, '');
    }
    return null;
  }

  private async validatePayload<T extends object>(
    cls: new () => T,
    body: unknown,
  ): Promise<{ value: T } | { error: ReturnType<typeof this.errorAck> }> {
    if (typeof body !== 'object' || body === null) {
      return {
        error: this.errorAck(
          RealtimeErrorCode.VALIDATION_FAILED,
          'Command payload must be an object.',
        ),
      };
    }
    const instance = plainToInstance(cls, body);
    const errors = await validate(instance, {
      whitelist: true,
      forbidNonWhitelisted: true,
    });
    if (errors.length > 0) {
      return {
        error: this.errorAck(
          RealtimeErrorCode.VALIDATION_FAILED,
          errors
            .flatMap((e) => Object.values(e.constraints ?? {}))
            .join('; ') || 'Invalid command payload.',
        ),
      };
    }
    return { value: instance };
  }

  private errorAck(code: RealtimeErrorCode, message: string) {
    return { ok: false, error: { code, message } };
  }

  private fromAppException(err: unknown) {
    if (err instanceof AppException) {
      return this.errorAck(this.mapAppErrorCode(err.code), err.message);
    }
    this.logger.error(
      `Unhandled error in realtime command handler: ${
        err instanceof Error ? err.stack : String(err)
      }`,
    );
    return this.errorAck(
      RealtimeErrorCode.INTERNAL_ERROR,
      'An unexpected error occurred.',
    );
  }

  private mapAppErrorCode(code: string): RealtimeErrorCode {
    switch (code) {
      case 'NOT_FOUND':
        return RealtimeErrorCode.NOT_FOUND;
      case 'FORBIDDEN':
        return RealtimeErrorCode.FORBIDDEN;
      case 'VALIDATION_FAILED':
        return RealtimeErrorCode.VALIDATION_FAILED;
      default:
        return RealtimeErrorCode.INTERNAL_ERROR;
    }
  }
}
