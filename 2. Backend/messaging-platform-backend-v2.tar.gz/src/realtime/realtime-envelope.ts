import { randomUUID } from 'crypto';

/**
 * The project's canonical realtime envelope. Every command sent by a
 * client and every event pushed by the server uses this exact shape —
 * no per-feature envelope variants — so client code has one parser.
 */
export interface RealtimeEnvelope<TPayload = unknown> {
  eventId: string;
  type: string;
  version: number;
  timestamp: string;
  conversationId?: string;
  correlationId?: string;
  payload: TPayload;
}

export function buildEnvelope<TPayload>(
  type: string,
  payload: TPayload,
  options: { conversationId?: string; correlationId?: string } = {},
): RealtimeEnvelope<TPayload> {
  return {
    eventId: randomUUID(),
    type,
    version: 1,
    timestamp: new Date().toISOString(),
    conversationId: options.conversationId,
    correlationId: options.correlationId,
    payload,
  };
}

/** Server -> client event type names (also stored as outbox.event_type). */
export enum RealtimeEventType {
  MESSAGE_CREATED = 'message_created',
  MESSAGE_UPDATED = 'message_updated',
  MESSAGE_DELETED = 'message_deleted',
  MESSAGE_DELIVERED = 'message_delivered',
  MESSAGE_READ = 'message_read',
  SYNCHRONIZATION_REQUIRED = 'synchronization_required',
}

/** Client -> server command names, handled by MessagingGateway. */
export enum RealtimeCommandType {
  SEND_MESSAGE = 'send_message',
  ACKNOWLEDGE_DELIVERY = 'acknowledge_delivery',
  ACKNOWLEDGE_READ = 'acknowledge_read',
  SYNCHRONIZE = 'synchronize',
}

/** Stable error codes returned on the 'error' event / command ack. */
export enum RealtimeErrorCode {
  UNAUTHENTICATED = 'UNAUTHENTICATED',
  FORBIDDEN = 'FORBIDDEN',
  VALIDATION_FAILED = 'VALIDATION_FAILED',
  NOT_FOUND = 'NOT_FOUND',
  RATE_LIMITED = 'RATE_LIMITED',
  INTERNAL_ERROR = 'INTERNAL_ERROR',
}

export interface RealtimeErrorPayload {
  code: RealtimeErrorCode;
  message: string;
}
