/**
 * Drizzle ORM schema for the WhatsApp-style messaging platform backend
 * foundation (Backend Volume 1).
 *
 * Scope: accounts, profiles, devices, sessions, conversations, conversation
 * membership, group metadata, and a minimal audit log.
 *
 * Future milestones extend this schema with Message, MessageAttachment,
 * MessageReaction, MessageReceipt, MediaAsset, Notification, PushToken and
 * SearchDocument tables. Conversation is already the natural parent for a
 * future `messages` table, and `conversation_members.last_read_at` is
 * reserved for future read-receipt / unread-count features.
 */

import {
  pgTable,
  pgEnum,
  uuid,
  text,
  boolean,
  timestamp,
  jsonb,
  bigint,
  integer,
  uniqueIndex,
  index,
} from 'drizzle-orm/pg-core';
import { relations, sql } from 'drizzle-orm';

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

export const accountStatusEnum = pgEnum('account_status', [
  'ACTIVE',
  'DISABLED',
  'DELETED',
]);

export const devicePlatformEnum = pgEnum('device_platform', [
  'IOS',
  'ANDROID',
  'WEB',
  'DESKTOP',
  'UNKNOWN',
]);

export const deviceStatusEnum = pgEnum('device_status', ['ACTIVE', 'REVOKED']);

export const conversationTypeEnum = pgEnum('conversation_type', [
  'DIRECT',
  'GROUP',
]);

export const memberRoleEnum = pgEnum('member_role', [
  'OWNER',
  'ADMIN',
  'MEMBER',
]);

export const memberStatusEnum = pgEnum('member_status', [
  'ACTIVE',
  'LEFT',
  'REMOVED',
]);

export const auditEventTypeEnum = pgEnum('audit_event_type', [
  'AUTH_LOGIN_SUCCESS',
  'AUTH_LOGIN_FAILURE',
  'AUTH_REGISTER',
  'AUTH_LOGOUT',
  'AUTH_TOKEN_REFRESH',
  'SESSION_REVOKED',
  'SESSION_REVOKED_ALL',
  'ACCOUNT_DISABLED',
  'CONVERSATION_CREATED',
  'GROUP_CREATED',
  'MEMBERSHIP_ROLE_CHANGED',
  'MEMBERSHIP_REMOVED',
  'MESSAGE_DELETED',
]);

export const messageTypeEnum = pgEnum('message_type', [
  'TEXT',
  // Reserved for future milestones — accepted by the type system today
  // so the column never needs a breaking migration, but no code path in
  // this milestone creates them.
  'IMAGE',
  'VIDEO',
  'AUDIO',
  'DOCUMENT',
  'SYSTEM',
]);

export const outboxStatusEnum = pgEnum('outbox_status', [
  'PENDING',
  'PUBLISHED',
  'FAILED',
]);

// ---------------------------------------------------------------------------
// Users / Profiles
// ---------------------------------------------------------------------------

export const users = pgTable(
  'users',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    email: text('email').notNull(),
    passwordHash: text('password_hash').notNull(),
    status: accountStatusEnum('status').notNull().default('ACTIVE'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    emailUnique: uniqueIndex('users_email_unique').on(
      sql`lower(${table.email})`,
    ),
    statusIdx: index('users_status_idx').on(table.status),
  }),
);

export const profiles = pgTable(
  'profiles',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: 'cascade' }),
    username: text('username').notNull(),
    displayName: text('display_name').notNull(),
    avatarUrl: text('avatar_url'),
    about: text('about'),
    showLastSeen: boolean('show_last_seen').notNull().default(true),
    showOnline: boolean('show_online').notNull().default(true),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    usernameUnique: uniqueIndex('profiles_username_unique').on(
      sql`lower(${table.username})`,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Devices / Sessions
// ---------------------------------------------------------------------------

export const devices = pgTable(
  'devices',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    platform: devicePlatformEnum('platform').notNull().default('UNKNOWN'),
    name: text('name'),
    appVersion: text('app_version'),
    status: deviceStatusEnum('status').notNull().default('ACTIVE'),
    lastActiveAt: timestamp('last_active_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    userIdx: index('devices_user_idx').on(table.userId),
    userStatusIdx: index('devices_user_status_idx').on(
      table.userId,
      table.status,
    ),
  }),
);

/**
 * Durable session record backing refresh-token issuance & revocation.
 * The refresh token itself is never stored — only a SHA-256 hash of it —
 * so a leaked database dump cannot be replayed as a valid refresh token.
 */
export const sessions = pgTable(
  'sessions',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    deviceId: uuid('device_id')
      .notNull()
      .references(() => devices.id, { onDelete: 'cascade' }),
    refreshTokenHash: text('refresh_token_hash').notNull().unique(),
    revoked: boolean('revoked').notNull().default(false),
    revokedAt: timestamp('revoked_at', { withTimezone: true }),
    expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
    lastUsedAt: timestamp('last_used_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    userIdx: index('sessions_user_idx').on(table.userId),
    userRevokedIdx: index('sessions_user_revoked_idx').on(
      table.userId,
      table.revoked,
    ),
    deviceIdx: index('sessions_device_idx').on(table.deviceId),
    expiresIdx: index('sessions_expires_idx').on(table.expiresAt),
  }),
);

// ---------------------------------------------------------------------------
// Conversations / Membership / Groups
// ---------------------------------------------------------------------------

export const conversations = pgTable(
  'conversations',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    type: conversationTypeEnum('type').notNull(),
    /**
     * Deterministic key used only for DIRECT conversations: the two
     * participant user IDs, sorted and joined. A unique index on this
     * column is what makes "at most one direct conversation per pair of
     * users" a database-enforced invariant rather than an
     * application-level, race-prone precheck. Always null for GROUP
     * conversations.
     */
    directKey: text('direct_key'),
    createdById: uuid('created_by_id')
      .notNull()
      .references(() => users.id),
    /**
     * Server-authoritative, monotonically increasing per-conversation
     * message counter. Incremented atomically (`UPDATE ... SET
     * last_sequence = last_sequence + 1 RETURNING last_sequence`) inside
     * the same transaction that inserts a message, so sequence
     * assignment is race-free under concurrent sends without a
     * distributed lock. Never assigned from a client-supplied value.
     */
    lastSequence: bigint('last_sequence', { mode: 'number' })
      .notNull()
      .default(0),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    directKeyUnique: uniqueIndex('conversations_direct_key_unique').on(
      table.directKey,
    ),
    typeIdx: index('conversations_type_idx').on(table.type),
  }),
);

export const groupProfiles = pgTable('group_profiles', {
  id: uuid('id').defaultRandom().primaryKey(),
  conversationId: uuid('conversation_id')
    .notNull()
    .unique()
    .references(() => conversations.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  description: text('description'),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const conversationMembers = pgTable(
  'conversation_members',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    role: memberRoleEnum('role').notNull().default('MEMBER'),
    status: memberStatusEnum('status').notNull().default('ACTIVE'),
    /**
     * Read/delivery are tracked as per-member checkpoints against the
     * conversation's monotonic sequence, rather than one row per
     * message per recipient — this keeps a 1,000-message group chat's
     * receipt state at one row per member, not one row per
     * message-times-member, while still letting the server compute
     * "delivered/read up to sequence N" precisely.
     */
    lastDeliveredSequence: bigint('last_delivered_sequence', {
      mode: 'number',
    })
      .notNull()
      .default(0),
    lastReadSequence: bigint('last_read_sequence', { mode: 'number' })
      .notNull()
      .default(0),
    lastReadAt: timestamp('last_read_at', { withTimezone: true }),
    joinedAt: timestamp('joined_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    leftAt: timestamp('left_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    conversationUserUnique: uniqueIndex(
      'conversation_members_conversation_user_unique',
    ).on(table.conversationId, table.userId),
    userStatusIdx: index('conversation_members_user_status_idx').on(
      table.userId,
      table.status,
    ),
    conversationStatusIdx: index(
      'conversation_members_conversation_status_idx',
    ).on(table.conversationId, table.status),
  }),
);

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------

export const messages = pgTable(
  'messages',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    senderId: uuid('sender_id')
      .notNull()
      .references(() => users.id),
    /**
     * Client-generated idempotency key. The (conversation_id, sender_id,
     * client_message_id) unique index is what makes retried sends safe:
     * a retried insert hits the constraint instead of creating a second
     * row, and the service layer re-reads and returns the original.
     */
    clientMessageId: text('client_message_id').notNull(),
    /**
     * Server-authoritative per-conversation order, assigned atomically
     * from conversations.last_sequence in the same transaction as the
     * insert. This — not created_at — is the field clients reconstruct
     * history and detect gaps from; created_at is informational only.
     */
    sequence: bigint('sequence', { mode: 'number' }).notNull(),
    type: messageTypeEnum('type').notNull().default('TEXT'),
    content: text('content').notNull(),
    replyToId: uuid('reply_to_id'),
    editedAt: timestamp('edited_at', { withTimezone: true }),
    deletedAt: timestamp('deleted_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    clientMessageUnique: uniqueIndex('messages_client_message_unique').on(
      table.conversationId,
      table.senderId,
      table.clientMessageId,
    ),
    conversationSequenceUnique: uniqueIndex(
      'messages_conversation_sequence_unique',
    ).on(table.conversationId, table.sequence),
    conversationSequenceIdx: index('messages_conversation_sequence_idx').on(
      table.conversationId,
      table.sequence,
    ),
    conversationCreatedIdx: index('messages_conversation_created_idx').on(
      table.conversationId,
      table.createdAt,
    ),
    senderCreatedIdx: index('messages_sender_created_idx').on(
      table.senderId,
      table.createdAt,
    ),
    replyToIdx: index('messages_reply_to_idx').on(table.replyToId),
  }),
);

/**
 * Transactional outbox: written in the same transaction as the message
 * insert/update/delete it describes, so an event is never lost to a
 * crash between "message persisted" and "event published." A background
 * processor (see OutboxProcessorService) picks up PENDING rows,
 * publishes them to connected WebSocket clients, and marks them
 * PUBLISHED — retrying with backoff on failure rather than losing the
 * event.
 */
export const messageOutbox = pgTable(
  'message_outbox',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    aggregateType: text('aggregate_type').notNull().default('message'),
    aggregateId: uuid('aggregate_id').notNull(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    eventType: text('event_type').notNull(),
    eventVersion: integer('event_version').notNull().default(1),
    payload: jsonb('payload').notNull(),
    status: outboxStatusEnum('status').notNull().default('PENDING'),
    attempts: integer('attempts').notNull().default(0),
    lastError: text('last_error'),
    publishedAt: timestamp('published_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    statusCreatedIdx: index('message_outbox_status_created_idx').on(
      table.status,
      table.createdAt,
    ),
    conversationIdx: index('message_outbox_conversation_idx').on(
      table.conversationId,
    ),
  }),
);

// ---------------------------------------------------------------------------
// Audit
// ---------------------------------------------------------------------------

export const auditEvents = pgTable(
  'audit_events',
  {
    id: uuid('id').defaultRandom().primaryKey(),
    type: auditEventTypeEnum('type').notNull(),
    userId: uuid('user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    ip: text('ip'),
    userAgent: text('user_agent'),
    metadata: jsonb('metadata'),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    userIdx: index('audit_events_user_idx').on(table.userId),
    typeIdx: index('audit_events_type_idx').on(table.type),
    createdAtIdx: index('audit_events_created_at_idx').on(table.createdAt),
  }),
);

// ---------------------------------------------------------------------------
// Relations (used for Drizzle's relational query API)
// ---------------------------------------------------------------------------

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  devices: many(devices),
  sessions: many(sessions),
  conversationMemberships: many(conversationMembers),
  createdConversations: many(conversations),
  auditEvents: many(auditEvents),
}));

export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, { fields: [profiles.userId], references: [users.id] }),
}));

export const devicesRelations = relations(devices, ({ one, many }) => ({
  user: one(users, { fields: [devices.userId], references: [users.id] }),
  sessions: many(sessions),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, { fields: [sessions.userId], references: [users.id] }),
  device: one(devices, {
    fields: [sessions.deviceId],
    references: [devices.id],
  }),
}));

export const conversationsRelations = relations(
  conversations,
  ({ one, many }) => ({
    createdBy: one(users, {
      fields: [conversations.createdById],
      references: [users.id],
    }),
    members: many(conversationMembers),
    group: one(groupProfiles, {
      fields: [conversations.id],
      references: [groupProfiles.conversationId],
    }),
  }),
);

export const groupProfilesRelations = relations(groupProfiles, ({ one }) => ({
  conversation: one(conversations, {
    fields: [groupProfiles.conversationId],
    references: [conversations.id],
  }),
}));

export const conversationMembersRelations = relations(
  conversationMembers,
  ({ one }) => ({
    conversation: one(conversations, {
      fields: [conversationMembers.conversationId],
      references: [conversations.id],
    }),
    user: one(users, {
      fields: [conversationMembers.userId],
      references: [users.id],
    }),
  }),
);

export const auditEventsRelations = relations(auditEvents, ({ one }) => ({
  user: one(users, { fields: [auditEvents.userId], references: [users.id] }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
  sender: one(users, { fields: [messages.senderId], references: [users.id] }),
  replyTo: one(messages, {
    fields: [messages.replyToId],
    references: [messages.id],
  }),
}));

export const messageOutboxRelations = relations(messageOutbox, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messageOutbox.conversationId],
    references: [conversations.id],
  }),
}));
