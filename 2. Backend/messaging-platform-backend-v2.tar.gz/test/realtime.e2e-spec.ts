import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { io, Socket } from 'socket.io-client';
import { Pool } from 'pg';
import { AppModule } from '../src/app.module';
import { DATABASE_POOL } from '../src/database/database.module';
import { truncateAll } from './db-test-helper';

describe('Realtime gateway (e2e)', () => {
  let app: INestApplication;
  let pool: Pool;
  let baseUrl: string;
  const sockets: Socket[] = [];

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    await app.init();
    await app.listen(0);
    const address = app.getHttpServer().address() as { port: number };
    baseUrl = `http://127.0.0.1:${address.port}`;
    pool = app.get(DATABASE_POOL);
  });

  afterAll(async () => {
    await app.close();
  });

  afterEach(() => {
    for (const socket of sockets) {
      socket.removeAllListeners();
      socket.disconnect();
    }
    sockets.length = 0;
  });

  beforeEach(async () => {
    await truncateAll(pool);
  });

  async function registerUser(email: string, username: string) {
    const res = await request(app.getHttpServer())
      .post('/auth/register')
      .send({
        email,
        password: 'correct-horse-battery',
        username,
        displayName: username,
      })
      .expect(201);
    return {
      userId: res.body.user.id as string,
      accessToken: res.body.tokens.accessToken as string,
    };
  }

  async function createDirectConversation(
    accessToken: string,
    otherUserId: string,
  ) {
    const res = await request(app.getHttpServer())
      .post('/conversations/direct')
      .set('Authorization', `Bearer ${accessToken}`)
      .send({ userId: otherUserId })
      .expect(201);
    return res.body.id as string;
  }

  function connect(accessToken: string): Promise<Socket> {
    return new Promise((resolve, reject) => {
      const socket = io(baseUrl, {
        path: '/realtime',
        auth: { token: accessToken },
        transports: ['websocket'],
        reconnection: false,
        forceNew: true,
      });
      sockets.push(socket);
      socket.on('connect', () => resolve(socket));
      socket.on('connect_error', (err) => reject(err));
      setTimeout(() => reject(new Error('connect timeout')), 5000);
    });
  }

  function waitForConnectError(accessToken: string | undefined): Promise<void> {
    return new Promise((resolve, reject) => {
      const socket = io(baseUrl, {
        path: '/realtime',
        auth: accessToken ? { token: accessToken } : {},
        transports: ['websocket'],
        reconnection: false,
        forceNew: true,
      });
      sockets.push(socket);
      socket.on('connect', () => {
        reject(
          new Error('expected connection to be rejected but it succeeded'),
        );
      });
      // Rejecting in the socket.io handshake middleware (see
      // MessagingGateway.afterInit) surfaces to the client as
      // 'connect_error' — the connection never completes, so 'connect'
      // never fires and no command could ever race ahead of it.
      socket.on('connect_error', () => resolve());
      setTimeout(
        () => reject(new Error('expected connect_error within timeout')),
        5000,
      );
    });
  }

  describe('connection authentication', () => {
    it('accepts a connection with a valid access token', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const socket = await connect(alice.accessToken);
      expect(socket.connected).toBe(true);
    });

    it('rejects a connection with no token', async () => {
      await waitForConnectError(undefined);
    });

    it('rejects a connection with a garbage token', async () => {
      await waitForConnectError('not-a-real-token');
    });

    it('rejects a connection whose session has been revoked', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      await request(app.getHttpServer())
        .post('/auth/logout-all')
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(204);

      await waitForConnectError(alice.accessToken);
    });
  });

  describe('send_message command', () => {
    it('persists a message and acks it back to the sender', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const conversationId = await createDirectConversation(
        alice.accessToken,
        bob.userId,
      );

      const aliceSocket = await connect(alice.accessToken);

      const ack = await new Promise<any>((resolve) => {
        aliceSocket.emit(
          'send_message',
          {
            conversationId,
            clientMessageId: 'ws-1',
            content: 'hello over websocket',
          },
          (response: any) => resolve(response),
        );
      });

      expect(ack.ok).toBe(true);
      expect(ack.message.content).toBe('hello over websocket');
      expect(ack.message.sequence).toBe(1);
    });

    it('fans the message out to another connected member in realtime', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const conversationId = await createDirectConversation(
        alice.accessToken,
        bob.userId,
      );

      const aliceSocket = await connect(alice.accessToken);
      const bobSocket = await connect(bob.accessToken);

      const eventPromise = new Promise<any>((resolve) => {
        bobSocket.on('event', (envelope) => resolve(envelope));
      });

      aliceSocket.emit('send_message', {
        conversationId,
        clientMessageId: 'ws-fanout-1',
        content: 'can you see this?',
      });

      const envelope = await eventPromise;
      expect(envelope.type).toBe('message_created');
      expect(envelope.conversationId).toBe(conversationId);
      expect(envelope.payload.content).toBe('can you see this?');
    });

    it('rejects sending to a conversation the socket is not a member of', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      await registerUser('carol@example.com', 'carol');
      const conversationId = await createDirectConversation(
        alice.accessToken,
        bob.userId,
      );

      const carol = await request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: 'carol@example.com', password: 'correct-horse-battery' })
        .expect(200);
      const carolSocket = await connect(carol.body.tokens.accessToken);

      const ack = await new Promise<any>((resolve) => {
        carolSocket.emit(
          'send_message',
          { conversationId, clientMessageId: 'sneaky', content: 'sneaky' },
          (response: any) => resolve(response),
        );
      });

      expect(ack.ok).toBe(false);
      expect(ack.error.code).toBe('NOT_FOUND');
    });

    it('rejects an invalid payload', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const socket = await connect(alice.accessToken);

      const ack = await new Promise<any>((resolve) => {
        socket.emit(
          'send_message',
          { conversationId: 'not-a-uuid', clientMessageId: 'x', content: '' },
          (response: any) => resolve(response),
        );
      });

      expect(ack.ok).toBe(false);
      expect(ack.error.code).toBe('VALIDATION_FAILED');
    });
  });

  describe('acknowledge and synchronize commands', () => {
    it('acknowledges delivery and read over the socket', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const conversationId = await createDirectConversation(
        alice.accessToken,
        bob.userId,
      );

      await request(app.getHttpServer())
        .post(`/conversations/${conversationId}/messages`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .send({ clientMessageId: 'm1', content: 'hi' })
        .expect(201);

      const bobSocket = await connect(bob.accessToken);

      const deliveredAck = await new Promise<any>((resolve) => {
        bobSocket.emit(
          'acknowledge_delivery',
          { conversationId, upToSequence: 1 },
          (response: any) => resolve(response),
        );
      });
      expect(deliveredAck.ok).toBe(true);

      const readAck = await new Promise<any>((resolve) => {
        bobSocket.emit(
          'acknowledge_read',
          { conversationId, upToSequence: 1 },
          (response: any) => resolve(response),
        );
      });
      expect(readAck.ok).toBe(true);

      const state = await request(app.getHttpServer())
        .get(`/conversations/${conversationId}/receipts`)
        .set('Authorization', `Bearer ${alice.accessToken}`)
        .expect(200);
      const bobState = state.body.find(
        (s: { userId: string }) => s.userId === bob.userId,
      );
      expect(bobState.lastReadSequence).toBe(1);
    });

    it('synchronizes messages after a checkpoint over the socket', async () => {
      const alice = await registerUser('alice@example.com', 'alice');
      const bob = await registerUser('bob@example.com', 'bob');
      const conversationId = await createDirectConversation(
        alice.accessToken,
        bob.userId,
      );

      for (let i = 1; i <= 3; i++) {
        await request(app.getHttpServer())
          .post(`/conversations/${conversationId}/messages`)
          .set('Authorization', `Bearer ${alice.accessToken}`)
          .send({ clientMessageId: `m${i}`, content: `message ${i}` })
          .expect(201);
      }

      const bobSocket = await connect(bob.accessToken);

      const syncAck = await new Promise<any>((resolve) => {
        bobSocket.emit(
          'synchronize',
          { conversationId, afterSequence: 1 },
          (response: any) => resolve(response),
        );
      });

      expect(syncAck.ok).toBe(true);
      expect(syncAck.items.map((m: any) => m.sequence)).toEqual([2, 3]);
      expect(syncAck.hasMore).toBe(false);
    });
  });
});
